#!/usr/bin/env bash

DIST_FILE_NAME="*.jar"

PROJECT_DIR="usercluster_explore"

START_SCRIPT="./start_env/${PROJECT_DIR}/deploy.sh"

SYNC_DATA_OPERATIONS="
# rsync -avl worker@10.103.17.21:~/_deployment ~
# cp -r ~/_deployment/news-recommender/hutils start_env
"

DEST_FILE_NAME="usercluster-explore*.jar"

DEST_FILE_PATH="start_env/${PROJECT_DIR}/bin"

BASE_IMAGE="docker2.yidian.com:5000/centos/compile-jdk8:20150720"

MAINTAINER="wangzhiqian \"wangzhiqian@yidian-inc.com\""

HOME_DIR="/home/services"

LOG_DIRS="
${HOME_DIR}/${PROJECT_DIR}/logs
"

DATA_DIRS="
${HOME_DIR}/${PROJECT_DIR}/data
"
