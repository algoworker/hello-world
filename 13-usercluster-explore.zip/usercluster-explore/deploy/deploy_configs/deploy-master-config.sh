#!/usr/bin/env bash

# Start commands for each container, one cmd a line
START_CMDS="
cd /home/services/usercluster_explore && ${start_cmd}
"

# Container names for each container, one name a line, same order with $start_cmds
CONTAINER_NAMES="
usercluster-explore-${env}
"

# Port maps for each container, one map a line, same order with $start_cmds
DOCKER_PORT_MAPS="
8606:8606
"

# This is for changing container name, remove old containers when deploy new one
OLD_CONTAINER_NAMES="
usercluster-explore-${env}
"

# Volumn maps for each container, one map a line, same order with $start_cmds
DOCKER_VOLUMN_MAPS="
~/_logs/usercluster-explore-${env}-${CONTAINER_PORT}:/home/services/usercluster_explore/logs ~/_data/usercluster-explore-${env}-${CONTAINER_PORT}/data:/home/services/usercluster_explore/data
"

# Other docker run options
DOCKER_RUN_OPTIONS="--net=host"
# Image name
IMAGE_NAME="docker2.yidian.com:5000/publish/usercluster-explore-video-${COMMIT_NUMBER}-image"
# This is for stopping container, kill sepicify process inside the container before 'docker stop' and 'docker rm'
DOCKER_PRESTOP_CMD=''
# Service port for "--net=host"
SERVICE_PORT="8606"
# Service port inside container
ORIGIN_SERVICE_PORT="8606"

DEPLOY_BATCH_INTERVAL=20
