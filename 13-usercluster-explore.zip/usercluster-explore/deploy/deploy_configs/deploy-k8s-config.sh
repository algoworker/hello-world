#!/usr/bin/env bash

QA_PRE_START_CMD=""                                     #用于测试环境在START_CMDS执行之前执行，一般用来去掉服务启动时候的内存要求。

SERVICE_DIR="usercluster_explore"
START_CMDS="/home/services/usercluster_explore/deploy.sh"    #进入docker container以后的服务启动命令
DOCKER_VOLUMN_MAPS="/home/services/usercluster_explore/logs"			#宿主机目录和container内部的目录映射关系

DOCKER_PRESTOP_CMD="sleep 2"						    #停止容器之前，执行的一些清理操作
SERVICE_PORT="8606"								#服务的端口
DONT_CHECK_PORT='false'                                             #如果服务不启动端口，那么这个设置为false

IMAGE_NAME="docker2.yidian.com:5000/publish/usercluster-explore-video-${COMMIT_ID}-image"
GLUSTERFS_PATH="/home/services/usercluster_explore/data"
NET="1000Mb"
CPU_NUM="6"
MEM_NUM="18Gi"
InitialDelaySeconds="300"