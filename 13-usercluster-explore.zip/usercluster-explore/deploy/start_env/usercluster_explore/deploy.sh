rm -f logs/start_script.done
cd /home/services/recipe/$1 && sh *.rule || exit 1
cd /home/services/usercluster_explore/bin

export USERCF_ENV_TAG=$2

sh start.sh

port=8606
while true; do
    s=`netstat -ntl | grep ":$port " -c`
    echo $s
    if [ "X$s" != "X" ] && [ "$s" != "0" ]; then
        break
    fi
    sleep 5;
done

sleep 1
sh post_validation.sh
ret=$?
if [ "$ret" -ne 0 ]; then
    exit $ret
fi
cd ..

touch logs/start_script.done
