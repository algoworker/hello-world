package com.yidian.explore.task;

import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.constant.LogManager;
import lombok.extern.log4j.Log4j;

import java.util.Date;

@Log4j
public class Model2newsExpireTask extends Thread{
    private long delay;
    private static IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

    public Model2newsExpireTask(int delayInSeconds) {
        this.delay = delayInSeconds;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(delay * 1000);
                exploreExploitPools.model2newsExpire();
                Date next = new Date(System.currentTimeMillis() + delay * 1000);
                LogManager.EXPIRE.info("Model2news expire task is done and next expire task will be executed at " + next.toString());
            } catch (InterruptedException e) {
                log.error("Schedule exploreExploitVideoPools model2news expire task exception:", e);
            }
        }
    }
}