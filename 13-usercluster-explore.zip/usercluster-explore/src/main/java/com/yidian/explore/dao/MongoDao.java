package com.yidian.explore.dao;

import com.mongodb.*;
import lombok.Data;
import org.apache.log4j.Logger;
import com.yidian.explore.utils.MongoUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xin on 18/05/22 19:48.
 */
@Data
public class MongoDao {
    private static final Logger logger = Logger.getLogger(MongoDao.class);
    private static volatile MongoDao instance = null;

    /**
     * 入库后需要进行explore的视频库
     */
    private DBCollection videoExplore;

    /**
     * explore回收的需要进行exploit的视频库
     */
    private DBCollection videoExploit;

    /**
     * explore回收的需要进行exploit的小视频库
     */
    private DBCollection microVideoExploit;

    /**
     * 需要保量的mcn/ugc/douyin源小视频库
     */
    private DBCollection vasourceMicroVideoExplore;

    /**
     * 入库24h后高点击低曝光的视频库
     */
    private DBCollection boostViewVideoMongo;

    /**
     * 服务重启之前将内存中的视频池backup到mongo
     * backup到morpheus存在超时问题
     */
    private DBCollection clusterDocumentsPoolMongo;

    /**
     * 存储试探expire的视频,存储90天,用于case跟进
     */
    private DBCollection videoExploreExpireMongo;

    public static MongoDao getInstance() {
        synchronized (MongoDao.class) {
            if (instance == null) {
                instance = new MongoDao();
            }
        }
        return instance;
    }

    private MongoDao() {
        Mongo mongo = MongoUtil.getMongoConnection("10.103.17.137,10.103.17.138,10.103.17.139");
        DB db = mongo.getDB("interest2news");
        videoExplore = db.getCollection("latest_m2n_explore");
        videoExploit = db.getCollection("latest_m2n_exploit");
        microVideoExploit = db.getCollection("m2n_micro_exploit");
        vasourceMicroVideoExplore = db.getCollection("m2n_vasource_micro_explore");
        boostViewVideoMongo = db.getCollection("latest_boost_view_video");
        clusterDocumentsPoolMongo = db.getCollection("video_explore_exploit_backup");
        videoExploreExpireMongo = db.getCollection("video_explore_expire");

        videoExplore.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 24 * 60 * 60));  // 24h
        videoExploit.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 15 * 24 * 60 * 60));  // 15d
        microVideoExploit.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 15 * 24 * 60 * 60));  // 15d
        vasourceMicroVideoExplore.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 30 * 24 * 60 * 60));  // 30d
        boostViewVideoMongo.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 30 * 24 * 60 * 60));  // 30d
        clusterDocumentsPoolMongo.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 30 * 60));  // 30min
        videoExploreExpireMongo.createIndex(new BasicDBObject("date", 1), new BasicDBObject("expireAfterSeconds", 90 * 24 * 60 * 60));  // 90d
    }

    public void write(Map<String, Object> data, DBCollection dbCollection) {
        if (data != null && dbCollection != null) {
            dbCollection.save(new BasicDBObject(data));
        }
    }

    public void exploreRemover(String docid) {
        videoExplore.remove(new BasicDBObject("_id", docid));
    }

    public void exploitRemover(String docid) {
        videoExploit.remove(new BasicDBObject("_id", docid));
    }

    public static void remove(DBCollection dbCollection, String docid) {
        if (dbCollection != null && docid != null) {
            dbCollection.remove(new BasicDBObject("_id", docid));
        }
    }

    public Boolean isInMongo(DBCollection dbCollection, String docid) {
        DBObject dbObject = dbCollection.findOne(new BasicDBObject("_id", docid));
        if (dbObject != null) {
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Map<String, Object> data = new HashMap<>();
        data.put("_id", "123");
        data.put("date", "2018-05-20");
        data.put("ts", "1111111");
        if (getInstance().isInMongo(getInstance().videoExplore, "V_01duRJDa")) {
            System.out.println("yes");
        } else {
            System.out.println("no");
        }
    }
}
