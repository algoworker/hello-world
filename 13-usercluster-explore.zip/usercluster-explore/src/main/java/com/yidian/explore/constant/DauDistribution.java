package com.yidian.explore.constant;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Create by xin
 * @version oppobrowser dau distribution by hours depend on dragon data of 2019-02-21
 * @Date 2019-02-22 16:00
 */
public class DauDistribution {
    private static Map<Integer, Double> oppobrowserDauDistribution = new HashMap<>();

    /**
     * dau distribution percentage
     * 00:00 0.03
     * 01:00 0.02
     * 02:00 0.01
     * 03:00 0.01
     * 04:00 0.01
     * 05:00 0.01
     * 06:00 0.02
     * 07:00 0.04
     * 08:00 0.04
     * 09:00 0.04
     * 10:00 0.04
     * 11:00 0.05
     * 12:00 0.05
     * 13:00 0.05
     * 14:00 0.05
     * 15:00 0.05
     * 16:00 0.05
     * 17:00 0.05
     * 18:00 0.06
     * 19:00 0.06
     * 20:00 0.07
     * 21:00 0.08
     * 22:00 0.07
     * 23:00 0.05
     */
    private static final List<Double> distribution = Arrays.asList(0.03, 0.02, 0.01, 0.01, 0.01, 0.01, 0.02, 0.04, 0.04, 0.04, 0.04, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.06, 0.06, 0.07, 0.08, 0.07, 0.05);

    static {
        for (int i = 0; i <= 23; i++) {
            oppobrowserDauDistribution.put(i, distribution.get(i));
        }
    }

    private DauDistribution() {

    }

    public static Map<Integer, Double> getOppobrowserDauDistribution() {
        return oppobrowserDauDistribution;
    }

    public static void main(String[] args) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();
        String currentDate = simpleDateFormat.format(now);
        int currentHour = Integer.parseInt(currentDate.substring(11, 13));
        System.out.println(currentHour);
        System.out.println(DauDistribution.oppobrowserDauDistribution.get(currentHour));
    }
}


