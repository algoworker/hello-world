package com.yidian.explore.task;

import com.yidian.explore.filter.DocumentFilter;
import com.yidian.explore.filter.FastTextFilter;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.utils.KafkaConsumer;
import com.yidian.serving.index.metrics.Metrics;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.message.MessageAndMetadata;
import kafka.utils.ZkUtils;
import lombok.extern.log4j.Log4j;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

@Log4j
public class ExploreDocCollect extends Thread {
    private DocumentFilter documentFilter = null;
    private String topic = "null";

    public ExploreDocCollect(String topic, DocumentFilter documentFilter) {
        this.topic = topic;
        this.documentFilter = documentFilter;
    }

    @Override
    public void run() {
        super.run();
        this.setName("ExploreDocCollect-thread-" + topic);
        Properties props = new Properties();
        try {
            FileInputStream fs = new FileInputStream("kafka.properties");
            props.load(fs);
            log.info("reading kafka.properties");
        } catch (FileNotFoundException e) {
            log.error("kafka.properties is missing!");
            log.error(e);
            System.exit(-1);
        } catch (IOException e) {
            log.error("read kafka.properties failed!");
            log.error(e);
            System.exit(-1);
        }
        String metricPrefix = "usercluster_ee_docCollect_" + topic;
        String hostName = "usercluster-ee";
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("The hostname cannot be resolved", e);
            throw new RuntimeException(e);
        }
        props.setProperty("group.id", hostName);
        String zkUrl = props.getProperty("zookeeper.connect").replace("/violet", "");
        ZkUtils.maybeDeletePath(zkUrl, "/violet/consumers/" + hostName + "/offsets/" + topic);
        IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();
        ConsumerConfig config = new ConsumerConfig(props);
        KafkaConsumer consumer = new KafkaConsumer(config);

        KafkaStream<byte[], byte[]> stream = consumer.createMessageStream(topic);
        Iterator<MessageAndMetadata<byte[], byte[]>> iter = stream.iterator();
        while (iter.hasNext()) {
            MessageAndMetadata<byte[], byte[]> msg = iter.next();
            String data = new String(msg.message());
            Metrics.simple().qps(metricPrefix + "_log_process");
            Optional<DocumentFeature> documentFeatureOpt = documentFilter.filter(data);
            documentFeatureOpt.ifPresent(exploreExploitPools::addDocument);
        }
    }

    public static void main(String[] args) {
        ExploreDocCollect edc = new ExploreDocCollect("indata_str_documents_info", FastTextFilter.getInstance());
        edc.run();
    }
}
