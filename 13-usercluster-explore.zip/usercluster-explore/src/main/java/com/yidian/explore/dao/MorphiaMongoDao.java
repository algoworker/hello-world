package com.yidian.explore.dao;

import com.yidian.explore.core.DocumentInfo;
import com.mongodb.Mongo;
import com.mongodb.WriteConcern;
import com.yidian.explore.utils.MongoUtil;
import lombok.extern.log4j.Log4j;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;
import org.mongodb.morphia.query.Query;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @version mongo写入工具, 主要负责将DocumentInfo对象直接写入mongo
 * @date 2019-05-29 12:50
 */
@Log4j
public class MorphiaMongoDao {
    private static volatile MorphiaMongoDao instance = null;
    private Morphia morphia;
    private Datastore datastore;

    public static MorphiaMongoDao getInstance() {
        if (instance == null) {
            synchronized (MorphiaMongoDao.class) {
                if (instance == null) {
                    instance = new MorphiaMongoDao();
                }
            }
        }
        return instance;
    }

    private MorphiaMongoDao() {
        morphia = new Morphia();
        morphia.map(DocumentInfo.class);
        Mongo mongo = MongoUtil.getMongoConnection("10.103.17.137,10.103.17.138,10.103.17.139");
        datastore = morphia.createDatastore(mongo, "interest2news");
        datastore.ensureIndexes();
    }

    public void write(Object object) {
        datastore.save(object, WriteConcern.SAFE);
    }

    public void writeAll(Iterable<DocumentInfo> collection) {
        datastore.save(collection);
    }

    public Optional<DocumentInfo> readByDocid(String docid) {
        Query<DocumentInfo> query = datastore.createQuery(DocumentInfo.class).field("_id").equal(docid);
        return Optional.ofNullable(query.get());
    }

    public List<DocumentInfo> readBySource(String source, String date) {
        List<DocumentInfo> sourceData = new ArrayList<>();
        try {
            SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date startDate = simpleFormat.parse(date + " 00:00:00");
            Date endDate = simpleFormat.parse(date + " 23:59:59");
            Iterator<DocumentInfo> query = datastore.createQuery(DocumentInfo.class)
                    .field("source").equal(source)
                    .field("insertTime").greaterThanOrEq(startDate)
                    .field("insertTime").lessThanOrEq(endDate)
                    .iterator();
            while (query.hasNext()) {
                sourceData.add(query.next());
            }
        } catch (Exception e) {
            log.error("Read explore video of source " + source + " from mongo exception:", e);
        }
        return sourceData;
    }

    public Map<String, Optional<DocumentInfo>> get(Iterable<? extends String> docids) {
        Map<String, Optional<DocumentInfo>> docs = new HashMap<>();
        for (String docid : docids) {
            docs.put(docid, Optional.empty());
        }

        List<String> subList = new ArrayList<>();
        for (String docId : docids) {
            if (subList.size() == 1000) {
                Query<DocumentInfo> query = datastore.createQuery(DocumentInfo.class).field("_id").in(subList);
                for (DocumentInfo doc : query) {
                    docs.put(doc.getDocid(), Optional.ofNullable(doc));
                }
                subList.clear();
            }
            subList.add(docId);
        }
        if (!subList.isEmpty()) {
            Query<DocumentInfo> query = datastore.createQuery(DocumentInfo.class).field("_id").in(subList);
            for (DocumentInfo doc : query) {
                docs.put(doc.getDocid(), Optional.ofNullable(doc));
            }
        }
        return docs;
    }

    public static void main(String[] args) {
        DocumentInfo documentInfo1 = new DocumentInfo("O_031grVN3", "你太有才了", "黄金牛角包", 2, 0, new Date(), "pipline");
        DocumentInfo documentInfo2 = new DocumentInfo("O_03JyjsK7", "你太有才了", "体坛经纪人", 2, 0, new Date(), "pipline");
        List<DocumentInfo> list = new ArrayList<>();
        list.add(documentInfo1);
        list.add(documentInfo2);
        // MorphiaMongoDao.getInstance().writeAll(list);
        List<DocumentInfo> documentInfoList = MorphiaMongoDao.getInstance().readBySource("一点UGC", "2019-07-21");
        for (DocumentInfo documentInfo : documentInfoList) {
            System.out.println(documentInfo.getDocid() + '\t' + documentInfo.getSource() + '\t' + documentInfo.getDate());
        }
        System.out.println(documentInfoList.size());
    }
}
