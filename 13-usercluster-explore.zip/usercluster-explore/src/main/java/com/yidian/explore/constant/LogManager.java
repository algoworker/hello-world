package com.yidian.explore.constant;

import org.apache.log4j.Logger;

public class LogManager {
    public static final Logger EXPIRE = Logger.getLogger("expire");
    public static final Logger COLLECT = Logger.getLogger("collect");
    public static final Logger DUMP = Logger.getLogger("dump");
    public static final Logger TAG = Logger.getLogger("tag");
    public static final Logger FEEDBACK = Logger.getLogger("feedback");
    public static final Logger DEDUPLICATE = Logger.getLogger("deduplicate");

    private LogManager() {

    }
}
