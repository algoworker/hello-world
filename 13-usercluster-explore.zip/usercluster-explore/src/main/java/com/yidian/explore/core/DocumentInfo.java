package com.yidian.explore.core;

import com.google.common.base.Optional;
import com.google.common.collect.Maps;
import com.yidian.algo.dao.ExternProfileDao;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.constant.LogManager;
import com.yidian.explore.constant.MetricsNameEnum;
import com.yidian.explore.dao.MorphiaMongoDao;
import com.yidian.explore.utils.ApolloConfigUtil;
import com.yidian.explore.utils.ExploreExploitFeatureUtil;
import com.yidian.explore.utils.MonMetricsUtil;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.serving.index.docfeature.core.common.data.Scope;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import lombok.Data;
import lombok.ToString;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.mongodb.morphia.annotations.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Data
@Log4j
@ToString(exclude = {"frameVector", "expireTime", "expireReason", "exploitFeature", "thumbUps", "shareDocs", "likes", "comments"})
@Entity(value = "video_explore_expire", noClassnameStored = true)
public class DocumentInfo implements Cloneable {
    @Id
    protected String docid = "null";
    protected volatile int clicks = 0;
    protected volatile int views = 0;
    protected float baseScore = 0;
    protected double rankScore = 0;
    protected String source = "null";
    protected String titleWords = "null";
    protected String refer = "pipline";
    protected int tier = 0;
    @Property("insertTime")
    protected Date date = new Date();
    @Transient
    protected static ObjectMapper mapper = new ObjectMapper();
    @Transient
    protected float[] frameVector = null;
    protected boolean micro = false;
    protected boolean passAudit = false;
    protected Date expireTime = null;  // for explore video only
    protected String expireReason = null;  // for explore video only
    @Property("s_exploit")
    protected String exploitFeature = null;  // s_exploit feature after explore

    /**
     * 优质视频评价指标:点赞/分享/收藏/评论
     * 点赞:小视频特有
     * 收藏:短视频特有
     */
    @Transient
    protected volatile int thumbUps = 0;
    @Transient
    protected volatile int shareDocs = 0;
    @Transient
    protected volatile int likes = 0;
    @Transient
    protected volatile int comments = 0;

    private static final SimpleMetrics metrics = Metrics.simple();

    public DocumentInfo() {

    }

    public DocumentInfo(String docid, String titleWords, String source, int tier, float baseScore, Date date, String refer) {
        this.docid = docid;
        this.titleWords = titleWords;
        this.source = source;
        this.tier = tier;
        this.baseScore = baseScore;
        this.date = date;
        this.refer = refer;
    }

    public double getUCBScore(float totalExploreTimes) {
        rankScore = baseScore + clicks * 4.0 * Math.log(views + 3.0D) / (views + 1) + Math.sqrt(Math.log(totalExploreTimes + 1) / (views + 4));
        return rankScore;
    }

    public double getPoolRankingScore(){
        return baseScore + Math.exp(views / 1000D) * (thumbUps + shareDocs * 2.0 + likes * 4.0 + comments * 8.0) / (clicks + 1);
    }

    void incVideoEvent(String event) {
        synchronized (this) {
            if (event.startsWith("play")) {
                this.clicks += 1;
            } else if ("view".equals(event)) {
                this.views += 1;
            } else if ("thumbUp".equals(event)) {
                this.thumbUps += 1;
            } else if ("shareDoc".equals(event)) {
                this.shareDocs += 1;
            } else if ("like".equals(event)) {
                this.likes += 1;
            } else if ("addComment".equals(event)) {
                this.comments += 1;
            }
        }
    }

    public boolean deserialize(JsonNode root) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            if (root.has("clicks")) {
                clicks = root.get("clicks").asInt(0);
            }
            if (root.has("views")) {
                views = root.get("views").asInt(0);
            }
            if (root.has("baseScore")) {
                baseScore = (float) root.get("baseScore").asDouble();
            }
            if (root.has("docid")) {
                docid = root.get("docid").asText();
            }
            if (root.has("source")) {
                source = root.get("source").asText();
            }
            if (root.has("titleWords")) {
                titleWords = root.get("titleWords").asText();
            }
            if (root.has("refer")) {  // exploit-pool复用标记
                refer = root.get("refer").asText();
                if (ExploreExploitConfig.defaultConfig().isGlobalExploitReuse()) {
                    if (refer.contains("global")) {
                        refer = refer.replace("global", "reuse");
                    }
                    refer = refer.replaceAll("\\d+", ExploreExploitConfig.defaultConfig().getExploreClusterNumber());
                }
            }
            if (root.has("tier")) {
                tier = root.get("tier").asInt(0);
            }
            if (root.has("date")) {
                String dateString = root.get("date").asText();
                date = new Date();
                try {
                    date = simpleDateFormat.parse(dateString);
                } catch (ParseException e) {
                    log.error("Parse date string to Date exception:", e);
                }
            }
            if (root.has("thumbUps")) {
                thumbUps = root.get("thumbUps").asInt(0);
            }
            if (root.has("shareDocs")) {
                shareDocs = root.get("shareDocs").asInt(0);
            }
            if (root.has("likes")) {
                likes = root.get("likes").asInt(0);
            }
            if (root.has("comments")) {
                comments = root.get("comments").asInt(0);
            }
            if (root.has("micro")) {
                micro = root.get("micro").asBoolean();
            }
            if (root.has("passAudit")) {
                passAudit = root.get("passAudit").asBoolean();
            }
            if (root.has("expireTime")) {
                String dateString = root.get("expireTime").asText();
                try {
                    expireTime = simpleDateFormat.parse(dateString);
                } catch (ParseException e) {
                    log.error("Parse expireTime string to Date exception:", e);
                }
            }
            if (root.has("expireReason")) {
                expireReason = root.get("expireReason").asText();
            }
        } catch (Exception e) {
            log.error("DocumentInfo deserialize exception:", e);
            return false;
        }
        return true;
    }

    public Map<String, Object> serialize() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ret.put("clicks", clicks);
        ret.put("views", views);
        ret.put("baseScore", baseScore);
        ret.put("docid", docid);
        ret.put("source", source);
        ret.put("titleWords", titleWords);
        ret.put("refer", refer);
        ret.put("tier", tier);
        ret.put("date", Constants.simpleDateFormat.format(date));
        ret.put("thumbUps", thumbUps);
        ret.put("shareDocs", shareDocs);
        ret.put("likes", likes);
        ret.put("comments", comments);
        ret.put("micro", micro);
        ret.put("passAudit", passAudit);
        if (expireTime != null) {
            ret.put("expireTime", simpleDateFormat.format(expireTime));
        }
        if (expireReason != null) {
            ret.put("expireReason", expireReason);
        }
        return ret;
    }

    @Override
    public Object clone() {
        DocumentInfo documentInfo = null;
        try {
            documentInfo = (DocumentInfo) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return documentInfo;
    }

    public Map<String, Object> getDebugInfo(long totalExploreTimes) {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Optional<NewsDocument> ndOpt = DocumentDataDAO.getInstance().getDocumentOpt(docid);
        ret.put("docid", docid);
        if (ndOpt.isPresent()) {
            NewsDocument nd = ndOpt.get();
            ret.put("title", nd.getTitle());
            ret.put("source", nd.getSource());
            Scope scope = nd.getScope();
            if (scope != null) {
                ret.put("scope", scope.name());
            }
            double dwell = nd.getDwellClickRate();
            double punish = 1.0;
            if (dwell < 100) {
                punish = -0.05 * dwell + 6;
            }
            double rankingScore = getUCBScore(totalExploreTimes) / punish;
            ret.put("dwell", dwell);
            ret.put("dw_punish", punish);
            ret.put("rankScore", rankingScore);
        }
        ret.put("clicks", clicks);
        // ret.put("thumbUps", thumbUps);
        // ret.put("shareDocs", shareDocs);
        // ret.put("likes", likes);
        // ret.put("comments", comments);
        ret.put("exploreTimes", views);
        ret.put("baseScore", baseScore);
        if (0 == views) {
            ret.put("ctr", 0.0);
        } else {
            ret.put("ctr", clicks * 1.0 / views);
        }
        // ret.put("ctr_weight", 4.0 * Math.log(views + 3));
        // ret.put("variance", Math.sqrt(Math.log(totalExploreTimes + 1.0D) / (views + 4)));
        ret.put("ucb_score", getUCBScore(totalExploreTimes));
        ret.put("tier", tier);
        ret.put("source", source);
        String ts = "null";
        if (date != null) {
            ts = simpleFormat.format(date);
        }
        ret.put("date", ts);
        ret.put("refer", refer);
        ret.put("micro", micro);
        ret.put("passAudit", passAudit);
        if (expireTime != null) {
            ts = simpleFormat.format(expireTime);
            ret.put("expireTime", ts);
        }
        if (expireReason != null) {
            ret.put("expireReason", expireReason);
        }
        return ret;
    }

    public boolean isExploitVideo() {
        return (this.exploreLevelEvaluator() != null) && (Constants.ExploreFeedback.EXCELLENT.name().equals(this.exploreLevelEvaluator()) || Constants.ExploreFeedback.GOOD.name().equals(this.exploreLevelEvaluator()));
    }

    /**
     * Return if video needs to re-tag.
     * 1.外部分发好的&&一点试探效果不好的视频召回.
     * 2."terrible" s_exploit feature video and micro video do not need to re-tag.
     * 3.小视频召回数量较少,"bad"以上s_exploit feature全部召回不分时间段;短视频只在7:00~19:00这个时间段召回"bad" s_exploit feature.
     */
    public boolean isRetagVideo(int hour) {
        String exploitFea = this.exploreLevelEvaluator();
        try {
            com.yidian.algo.feature.proto.VideoFeature externVideoFeature = ExternProfileDao.getInstance().get(this.docid);
            Metrics.simple().ratio("read_empty_videoExternalFeature", externVideoFeature == null);
            if (externVideoFeature != null && externVideoFeature.hasPublishTime() && externVideoFeature.hasUpdateTime() && externVideoFeature.hasWatchCount()) {
                long externPublishTime = externVideoFeature.getPublishTime();
                long yidianUpdateTime = externVideoFeature.getUpdateTime();
                if (yidianUpdateTime == 0) {
                    if (externVideoFeature.hasInsertTime()) {
                        yidianUpdateTime = externVideoFeature.getInsertTime();
                    } else {
                        yidianUpdateTime = this.getDate().getTime();
                    }
                }
                int externWatchCount = externVideoFeature.getWatchCount();
                if (externPublishTime < yidianUpdateTime) {
                    float day = (float) (yidianUpdateTime - externPublishTime) / (3600 * 24);
                    if (day >= 1.0f) {
                        float dailyWatchCount = externWatchCount / day;
                        boolean needRetag = (dailyWatchCount >= ApolloConfigUtil.getInstance().getRetagDailyWatchCount());
                        Random random = new Random();
                        // 未完成试探的视频重新打标签
                        if ((needRetag && this.expireReason != null && (this.expireReason.startsWith("[pool size expire]") || this.expireReason.startsWith("[explore lifetime expire]")))) {
                            Metrics.simple().qps("Retrieve_reTag_ExploreVideo_by_expireReason_success");
                            if (random.nextInt(10) < 2) {  // exp:20%不返回打标签
                                LogManager.TAG.info("[filter external feature retag] docid=" + this.docid + ",dailyWatchCount=" + dailyWatchCount + ",title=" + this.titleWords + ",expireReason=" + this.expireReason);
                                return false;
                            } else {  // base:80%返回打标签
                                LogManager.TAG.info("[return external feature retag] docid=" + this.docid + ",dailyWatchCount=" + dailyWatchCount + ",title=" + this.titleWords + ",expireReason=" + this.expireReason);
                                return true;
                            }
                        }
                        // 完成试探但试探效果不好的视频重新打标签
                        if (needRetag && exploitFea != null && (Constants.ExploreFeedback.TERRIBLE.name().equals(exploitFea) || Constants.ExploreFeedback.BAD.name().equals(exploitFea) || Constants.ExploreFeedback.GENERAL.name().equals(exploitFea))) {
                            Metrics.simple().qps("Retrieve_reTag_ExploreVideo_by_exploitFeature_success");
                            if (random.nextInt(10) < 2) {  // exp:20%不返回打标签
                                LogManager.TAG.info("[filter external feature retag] docid=" + this.docid + ",dailyWatchCount=" + dailyWatchCount + ",title=" + this.titleWords + ",s_exploit=" + exploitFea);
                                return false;
                            } else {  // base:80%返回打标签
                                LogManager.TAG.info("[return external feature retag] docid=" + this.docid + ",dailyWatchCount=" + dailyWatchCount + ",title=" + this.titleWords + ",s_exploit=" + exploitFea);
                                return true;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Get " + this.toString() + " external feature exception:", e);
        }
        if (exploitFea == null || Constants.ExploreFeedback.TERRIBLE.name().equals(exploitFea)) {
            return false;
        }
        return (this.isMicro()) || (hour >= 7 && hour <= 19) || (!Constants.ExploreFeedback.BAD.name().equals(exploitFea));
    }

    public boolean isInferiorVideo() {
        return (views >= 200 && 10 * clicks < views) || (views >= 50 && clicks == 0);
    }

    /**
     * Returns s_exploit feature which depends on explore video's feedback details.
     * Feature value will contain "EXCELLENT" "GOOD" "GENERAL" "BAD" "TERRIBLE".
     * Special feature "EXPLOSIVE" means explore many times in a short time suddenly.
     */
    public String exploreLevelEvaluator() {
        if (expireReason != null && expireReason.startsWith("[feedback view expire]")) {
            return Constants.ExploreFeedback.EXPLOSIVE.name();
        }
        if (views >= Constants.EXPLORE_TIME) {  // 充分完成试探
            float exploreCtr = (float) clicks / (float) views;
            if (exploreCtr > 0.25) {
                return Constants.ExploreFeedback.EXCELLENT.name();
            } else if ((exploreCtr > 0.15) && (exploreCtr <= 0.25)) {
                return Constants.ExploreFeedback.GOOD.name();
            } else if ((exploreCtr > 0.1) && (exploreCtr <= 0.15)) {
                return Constants.ExploreFeedback.GENERAL.name();
            } else if ((exploreCtr > 0.05) && (exploreCtr <= 0.1)) {
                return (views > Constants.EXPLOSIVE_TIME) ? Constants.ExploreFeedback.EXPLOSIVE.name() : Constants.ExploreFeedback.BAD.name();
            } else if ((exploreCtr >= 0) && (exploreCtr <= 0.05)) {
                return (views > Constants.EXPLOSIVE_TIME) ? Constants.ExploreFeedback.EXPLOSIVE.name() : Constants.ExploreFeedback.TERRIBLE.name();
            }
        } else if (views >= 200 && views < Constants.EXPLORE_TIME) {  // 试探多次后无足够click提前停止试探
            float exploreCtr = (float) clicks / (float) views;
            if ((exploreCtr > 0.05) && (exploreCtr <= 0.1)) {
                return Constants.ExploreFeedback.BAD.name();
            } else if ((exploreCtr >= 0) && (exploreCtr <= 0.05)) {
                return Constants.ExploreFeedback.TERRIBLE.name();
            }
        }
        if ((views >= 100) && ((float) clicks / (float) views > 0.3)) {  // 试探100次ctr>30%足够证明是优质视频
            return Constants.ExploreFeedback.EXCELLENT.name();
        }
        if ((views >= 50) && (clicks == 0)) {  // 试探超过50次0点击提前停止试探
            return Constants.ExploreFeedback.TERRIBLE.name();
        }
        return null;
    }

    /**
     * comparator for model2newsMicroVideoExploitPool
     */
    public static final Comparator<DocumentInfo> m2nMicroVideoDocumentInfoComparator = Comparator.comparing(DocumentInfo::getBaseScore)
            .thenComparing(DocumentInfo::getTier)
            .thenComparing(DocumentInfo::getDate).reversed();

    /**
     * comparator for ugcVideoExplorePool
     */
    public static final Comparator<DocumentInfo> ugcDocumentInfoComparator = Comparator.comparing(DocumentInfo::getRankScore)
            .thenComparing(DocumentInfo::getBaseScore)
            .thenComparing(DocumentInfo::getViews)
            .thenComparing(DocumentInfo::getClicks)
            .thenComparing(DocumentInfo::getDate).reversed();


    public void updateExploitFeature() {
        try {
            String sExploit = this.exploreLevelEvaluator();
            if (sExploit != null) {
                this.setExploitFeature(sExploit.toLowerCase());
                ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(this.docid, Constants.S_EXPLOIT, sExploit.toLowerCase());
                metrics.qps("model2newsVideoExplore_feedback_exploitFeature_" + sExploit);
            }
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackExplosiveFeature, Constants.ExploreFeedback.EXPLOSIVE.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackExcellentFeature, Constants.ExploreFeedback.EXCELLENT.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackGoodFeature, Constants.ExploreFeedback.GOOD.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackGeneralFeature, Constants.ExploreFeedback.GENERAL.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackBadFeature, Constants.ExploreFeedback.BAD.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackTerribleFeature, Constants.ExploreFeedback.TERRIBLE.name().equals(sExploit));
            MonMetricsUtil.ratio(MonMetricsUtil.MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.feedbackNullFeature, sExploit == null);
        } catch (Exception e) {
            log.error("Write s_exploit feature for " + this.toString() + " exception:", e);
        }
    }

    public Object generateExploitDocumentInfo() {
        DocumentInfo video = (DocumentInfo) this.clone();
        video.setRefer(String.format("%s_%s_%s_exploit", this.getRefer(), Constants.MODEL2NEWS, Constants.MODEL2NEWS_VIDEO_POOL));
        video.setBaseScore((this.getViews() == 0) ? 0 : (float) this.getClicks() / this.getViews());  // set explore ctr as exploit video baseScore
        video.setFrameVector(this.getFrameVector());
        return video;
    }

    public static void main(String[] args) {
        DocumentInfo documentInfo = new DocumentInfo("V_031grVN3", "你太有才了", "黄金牛角包", 2, 0, new Date(), "pipline");
        documentInfo.setClicks(0);
        documentInfo.setViews(0);
        documentInfo.setExpireTime(new Date());
        documentInfo.setExpireReason("[explore lifetime expire] insertTime=1,475,lifeTime=1,440");
        MorphiaMongoDao.getInstance().write(documentInfo);
        java.util.Optional<DocumentInfo> documentInfo1 = MorphiaMongoDao.getInstance().readByDocid("V_031o1Itl");
        System.out.println(documentInfo1);
        List<DocumentInfo> documentInfos = MorphiaMongoDao.getInstance().readBySource("一点UGC", null);
        System.out.println(documentInfos);
    }
}