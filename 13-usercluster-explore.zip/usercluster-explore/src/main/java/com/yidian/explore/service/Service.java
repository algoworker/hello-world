package com.yidian.explore.service;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.collect.Maps;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClientConfig;
import com.ning.http.client.providers.jdk.JDKAsyncHttpProvider;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.filter.*;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.dao.CentroidsDao;
import com.yidian.explore.task.*;
import com.yidian.explore.timer.*;
import com.yidian.explore.utils.MongoUtil;
import com.yidian.explore.utils.VideoEmbedding;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.metrics.MBootstrap;
import com.yidian.serving.metrics.MetricsFactory;
import com.yidian.serving.metrics.MetricsFactoryUtil;
import com.yidian.serving.metrics.OnDemandMetricsFactory;
import com.yidian.serving.metrics.core.Gauge;
import com.yidian.serving.metrics.reporter.opentsdb.HttpOpenTsdbClient;
import com.yidian.serving.metrics.reporter.opentsdb.OpenTsdbClient;
import lombok.extern.log4j.Log4j;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.PropertyConfigurator;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.server.handler.*;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.resource.JarResource;
import org.eclipse.jetty.util.thread.QueuedThreadPool;
import org.joda.time.DateTime;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.*;

@Log4j
public class Service implements Runnable {
    private static final String DEFAULT_LOG_PATH = "../logs";
    private static final int DEFAULT_LOG_RETENTION_DAYS = 15;
    @Parameter(names = "-port")
    private int port = 8000;
    @Parameter(names = "-config")
    private String beanConfig;

    @Override
    public void run() {
        Config usercfConfig = ConfigFactory.load().getConfig("usercluster-explore");
        initServingMetrics(usercfConfig, getLocalHost());
        cleanLogs();
        initService();

        if (ExploreExploitConfig.defaultConfig().getEnv().equals("prod")) {
            DocumentFilter filter = FastTextFilter.getInstance();
            ExploreDocCollect exploreDocCollect = new ExploreDocCollect(ExploreExploitConfig.defaultConfig().getCollectTopic(), filter);
            exploreDocCollect.start();
            ExploreDocCollect exploreVertDocCollect = new ExploreDocCollect("indata_str_vertical_documents", filter);
            exploreVertDocCollect.start();
        } else if (ExploreExploitConfig.defaultConfig().getEnv().equals("video")) {
            DocumentFilter filter = VideoFilter.getInstance();
            ExploreVideoCollect exploreVideoCollect = new ExploreVideoCollect(filter, "indata_str_vertical_documents");
            exploreVideoCollect.start();
        }

        ExploreFeedback exploreFeedBack = new ExploreFeedback(ExploreExploitConfig.defaultConfig().getFeedbackTopic());
        // UserClusterExpireTask clusterExpireTask = new UserClusterExpireTask(Constants.USERCLUSTER_EXPIRE_FREQUENCY);
        Model2newsExpireTask model2newsExpireTask = new Model2newsExpireTask(Constants.MODEL2NEWS_EXPIRE_FREQUENCY);

        exploreFeedBack.start();
        // clusterExpireTask.start();
        model2newsExpireTask.start();

        // 启动定时任务
        MicroExploitVideoPoolExpireTimer.getInstance();
        FrameVectorEmbedTimer.getInstance();
        MorpheusVectorRefreshTimer.getInstance();
        PoolsDumpTimer.getInstance();  // 定时dump视频池
        // SelectedVideoExploreTimer.getInstance();  // 暂停精选视频试探
        AllInVideoPoolExpireTimer.getInstance();
        RetagVideoCountRefreshTimer.getInstance();

        QueuedThreadPool threadPool = new QueuedThreadPool();
        threadPool.setMinThreads(threadPool.getMinThreads() * 4);
        threadPool.setMaxThreads(threadPool.getMaxThreads() * 4);
        Server server = new Server(threadPool);
        ServerConnector connector = new ServerConnector(server);
        connector.setPort(port);
        server.setConnectors(new Connector[]{connector});
        threadPoolMornitor(threadPool);

        log.warn("Use port = " + port);
        ServletContextHandler service = new ServletContextHandler(ServletContextHandler.SESSIONS);
        {
            service.setContextPath("/usercluster-explore");
            if (ExploreExploitConfig.defaultConfig().getEnv().equals("prod")) {
                service.addServlet(new ServletHolder(new ClusterExploreServlet()), "/explore");
                service.addServlet(new ServletHolder(new ClusterExploitServlet()), "/exploit");
            } else {
                service.addServlet(new ServletHolder(new VideoClusterExploreServlet()), "/video-explore");
                service.addServlet(new ServletHolder(new VideoKnnExploreServlet()), "/video-knnexplore");
                service.addServlet(new ServletHolder(new VideoClusterExploitServlet()), "/video-exploit");
                service.addServlet(new ServletHolder(new VideoClusterCacheServlet()), "/video-cache");
                service.addServlet(new ServletHolder(new VideoGlobalExploitPoolServlet()), "/video-selected");
                service.addServlet(new ServletHolder(new VideoClusterDocumentsPoolServlet()), "/video-clusterpool");
                service.addServlet(new ServletHolder(new ExploreInferiorVideoServlet()), "/inferior");
                service.addServlet(new ServletHolder(new VideoExploreDebugServlet()), "/video-explore-debug");
            }
            service.addServlet(new ServletHolder(new VideoPoolAppendServlet()), "/append");
            service.addServlet(new ServletHolder(new ClusterOperateServlet()), "/operate");
            service.addServlet(new ServletHolder(new ClusterDebugServlet()), "/debug");
            service.addServlet(new ServletHolder(new NotifyServlet()), "/notify");
        }
        ServletContextHandler root = new ServletContextHandler(ServletContextHandler.SESSIONS);
        {
            root.setContextPath("/");
        }
        ContextHandler pages = new ContextHandler();
        {
            pages.setContextPath("/static");
            ResourceHandler handler = new ResourceHandler();
            handler.setDirectoriesListed(true);
            handler.setBaseResource(JarResource.newClassPathResource("."));
            pages.setHandler(handler);
        }
        // RequestLogHandler requestLogHandler = startRequestLogServices();
        ContextHandlerCollection contexts = new ContextHandlerCollection();
        {
            contexts.addHandler(service);
            contexts.addHandler(pages);
            contexts.addHandler(root);
        }
        HandlerCollection handlers = new HandlerCollection();
        handlers.setHandlers(new Handler[]{contexts, new DefaultHandler()});
        // handlers.setHandlers(new Handler[]{contexts, new DefaultHandler(), requestLogHandler});
        server.setHandler(handlers);
        try {
            server.start();
        } catch (Exception e) {
            log.error("Start server exception:", e);
        }
        log.info("Service Started");
        try {
            server.join();
        } catch (InterruptedException e) {
            log.error("Join server exception:", e);
            Thread.currentThread().interrupt();
        }
        log.info("Service End");
    }

    private void initService() {
        CentroidsDao.defaultDAO();
        // DocEmbedding.defaultInstance();
        VideoEmbedding.defaultInstance();
        DocumentDataDAO.getInstance();
        ExploreExploitPoolFactory.getExplorePool();
    }

    private RequestLogHandler startRequestLogServices() {
        RequestLogHandler requestLogHandler = new RequestLogHandler();
        String logPath = System.getenv("jetty.logs");
        if (logPath == null) {
            logPath = DEFAULT_LOG_PATH;
        }
        NCSARequestLog requestLog = new NCSARequestLog(logPath + "/jetty-yyyy_MM_dd.request.log");
        requestLog.setFilenameDateFormat("yyyy_MM_dd");
        requestLog.setLogTimeZone("GMT+8");
        requestLog.setAppend(true);
        requestLog.setExtended(false);
        requestLog.setLogLatency(true);
        requestLog.setLogDateFormat("dd/MMM/yyyy:HH:mm:ss:SSS Z");
        requestLogHandler.setRequestLog(requestLog);
        return requestLogHandler;
    }

    private static void initServingMetrics(Config config, String hostName) {
        Config servingMetricsConfig;
        try {
            servingMetricsConfig = config.getConfig("serving-metrics");
        } catch (Exception e) {
            log.info("serving-metrics config is not found, will not send serving metrics");
            return;
        }
        String openTsdbAddr = servingMetricsConfig.getString("opentsdb.address");

        Map<String, String> tags = Maps.newHashMap();
        tags.put("env", servingMetricsConfig.getString("env"));
        tags.put("component", "usercluster-explore-video");
        tags.put("host", hostName);

        AsyncHttpClient asyncHttpClient = new AsyncHttpClient(new JDKAsyncHttpProvider(new AsyncHttpClientConfig.Builder().build()));
        OpenTsdbClient openTsdbClient = new HttpOpenTsdbClient(asyncHttpClient, openTsdbAddr);
        MetricsFactory metricsFactory = new OnDemandMetricsFactory(tags, openTsdbClient);
        MetricsFactoryUtil.register(metricsFactory);
        MBootstrap.startup();
    }

    private static String getLocalHost() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("The hostname cannot be resolved", e);
            throw new RuntimeException(e);
        }
    }

    private static void threadPoolMornitor(QueuedThreadPool threadPool) {
        Gauge<Integer> threadsGauge = new Gauge<Integer>("usercluster-ee.video.thread.num") {
            @Override
            public Integer getValue() {
                return threadPool.getThreads();
            }
        };
        MetricsFactoryUtil.getRegisteredFactory().register(threadsGauge);
        Gauge<Integer> jobsGauge = new Gauge<Integer>("usercluster-ee.video.job.num") {
            @Override
            public Integer getValue() {
                return threadPool.getQueueSize();
            }
        };
        MetricsFactoryUtil.getRegisteredFactory().register(jobsGauge);
    }

    private void cleanLogs() {
        log.info("log-retention-days is " + DEFAULT_LOG_RETENTION_DAYS);
        String logPath = getLogPath();
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(
                () -> {
                    try {
                        DateTime dateTime = DateTime.now().minusDays(DEFAULT_LOG_RETENTION_DAYS);
                        List<String> dateFormats = Arrays.asList(
                                dateTime.toString("yyyy-MM-dd"),
                                dateTime.toString("yyyyMMdd"),
                                dateTime.toString("yyyy_MM_dd"));
                        String glob = "glob:*{" + StringUtils.join(dateFormats, ",") + "}*";
                        log.info("start to do log clean job");
                        cleanLogs(logPath, glob);
                    } catch (IOException e) {
                        log.error("clean log failed...");
                    }
                }, 0, 1, TimeUnit.DAYS);
    }

    private String getLogPath() {
        String logPath = System.getenv("jetty.logs");
        if (logPath == null) {
            logPath = DEFAULT_LOG_PATH;
        }
        return logPath;
    }

    private void cleanLogs(String logPath, String glob) throws IOException {
        final PathMatcher pathMatcher = FileSystems.getDefault().getPathMatcher(glob);
        Files.walkFileTree(Paths.get(logPath), new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (pathMatcher.matches(file.getFileName())) {
                    log.info("log_retention, delete file:" + file.toAbsolutePath());
                    Files.delete(file);
                }
                return FileVisitResult.CONTINUE;
            }
            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                return FileVisitResult.CONTINUE;
            }
        });
    }

    public static void main(String[] args) {
        File logConfig = new File("log4j.properties");
        if (logConfig.exists()) {
            System.out.println("User config " + logConfig.toString());
            PropertyConfigurator.configure(logConfig.toString());
        }
        Service service = new Service();
        JCommander jcommander = new JCommander(service);
        jcommander.parse(args);
        service.run();
    }
}
