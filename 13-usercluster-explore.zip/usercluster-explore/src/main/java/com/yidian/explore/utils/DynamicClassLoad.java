package com.yidian.explore.utils;


import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

class TestDynamicClass{
//    private  TestDynamicClass(){
//        System.out.println("empty parameter");
//    }
    public TestDynamicClass(String parameter){
        System.out.println("parameter: " + parameter);
    }
}
public class DynamicClassLoad {
    public static void main(String [] args){
        String cName = TestDynamicClass.class.getName();
        try {
            Class c = Class.forName(cName);
//            c.newInstance();
            Constructor con = c.getConstructor(String.class);
            con.newInstance("hahah");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
