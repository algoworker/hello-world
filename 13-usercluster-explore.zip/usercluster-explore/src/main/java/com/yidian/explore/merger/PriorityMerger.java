package com.yidian.explore.merger;

import com.google.common.collect.Lists;
import com.yidian.explore.core.DocumentInfo;

import java.util.List;

public class PriorityMerger implements DocumentsMerger {
    @Override
    public List<DocumentInfo> merge(List<List<DocumentInfo>> documentsLst) {
        List<DocumentInfo> ret = Lists.newArrayList();
        for(List<DocumentInfo> documents: documentsLst){
            ret.addAll(documents);
        }
        return ret;
    }
}
