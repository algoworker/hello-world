package com.yidian.explore.core;

import com.yidian.explore.cache.CacheVideoFeature;

import java.util.List;
import java.util.Map;

public interface IExplorePools {
    void loadExploreExploitData();

    void dumpExploreExploitData();

    void expire();

    void addDocument(DocumentFeature doc);

    void userclusterUpdateExploreStatus(String uid, String docid, String event, String mashtype, String appid);

    List<DocumentInfo> explore(String uid, int topn, String appid);

    List<DocumentInfo> exploit(String scope, String uid, int topn);

    void addVideo(Map<String, CacheVideoFeature> morpheusVectors);

    void model2newsUpdateExploreStatus(String uid, String docid, String event, String mashtype, String appid);

    void model2newsExpire();

    void model2newsMicroExpire();

    void viewsAssuranceUpdateExploreStatus(String cid, String uid, String docid, String event, String mashtype, String appid);

}
