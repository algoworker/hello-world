package com.yidian.explore.core;

import lombok.Data;

@Data
public class DocItem {
    public String docid;
    public float score;
    public String date;
    public String title;
    public Float distance;
    public String src;
    public Integer tier;
}
