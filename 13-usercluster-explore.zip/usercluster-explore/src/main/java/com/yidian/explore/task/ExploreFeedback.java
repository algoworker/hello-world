package com.yidian.explore.task;

import com.google.common.collect.Lists;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.utils.KafkaConsumer;
import com.yidian.explore.utils.MailSender;
import com.yidian.explore.utils.StringTools;
import com.yidian.explore.utils.TaskPoolFactory;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.utils.ZkUtils;
import kafka.message.MessageAndMetadata;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@Log4j
public class ExploreFeedback extends Thread {
    private String topic = "null";
    private Date lastNotify = new Date();
    private int threadNum = Constants.FEEDBACK_THREAD_NUM;
    private volatile long abnormalNum = 0;
    private static final SimpleMetrics metrics = Metrics.simple();
    private static Set<String> vfactors = new HashSet<>();

    static {
        // wifi
        vfactors.add("video-m2nExplore");
        vfactors.add("video-ucExplore");
        vfactors.add("microvideo-viewsassurance_dy");
        vfactors.add("microvideo-viewsassurance_mcn");
        vfactors.add("microvideo-viewsassurance_ugc");
        vfactors.add("microvideo-viewsassurance_momo");
        vfactors.add("microvideo-ugcpool");
        // 4g
        vfactors.add("video-m2nExplore-4g");
        vfactors.add("video-ucExplore-4g");
        vfactors.add("microvideo-viewsassurance_dy-4g");
        vfactors.add("microvideo-viewsassurance_mcn-4g");
        vfactors.add("microvideo-viewsassurance_ugc-4g");
        vfactors.add("microvideo-viewsassurance_momo-4g");
        vfactors.add("microvideo-ugcpool-4g");
    }

    private static String getOrDefault(JsonNode root, String field, String def) {
        if (root.has(field)) {
            return root.get(field).getValueAsText();
        }
        return def;
    }

    public ExploreFeedback(String topic) {
        this.topic = topic;
    }

    private synchronized void recordAbnormal(int delta) {
        abnormalNum += delta;
        if (abnormalNum < 0) {
            abnormalNum = 0;
        } else if (abnormalNum > 1e6) {
            abnormalNum = (long) 1e6;
        }
        if (abnormalNum > 10000) {
            Date now = new Date();
            long delt = now.getTime() - lastNotify.getTime();
            int minutes = (int) (delt / (1000 * 60));
            if (minutes > 120) {
                MailSender.getInstance().sendMail(
                        "clusterExploreExploit@yidian-inc.com",
                        new String[]{"xinfeixiang@yidian-inc.com"},
                        "[video explore][server] video explore feedback warning",
                        "feedback time delta is abnormal and abnormalNum=" + abnormalNum
                );
                abnormalNum = 0;
                lastNotify = now;
            }
        }
    }

    @Override
    public void run() {
        super.run();
        this.setName("ExploreFeedBack-thread");
        Properties props = new Properties();

        try {
            FileInputStream fs = new FileInputStream("kafka.properties");
            props.load(fs);
            log.info("reading kafka.properties");
        } catch (FileNotFoundException e) {
            log.error("kafka.properties is missing:", e);
            System.exit(-1);
        } catch (IOException e) {
            log.error("read kafka.properties exception:", e);
            System.exit(-1);
        }

        String env = ExploreExploitConfig.defaultConfig().getEnv();
        String hostName = "usercluster-ee";
        String metricPrefix = "videoExploreFeedback";
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("The hostname cannot be resolved", e);
            throw new RuntimeException(e);
        }

        props.setProperty("group.id", hostName);
        String zkUrl = props.getProperty("zookeeper.connect").replace("/violet", "");
        ZkUtils.maybeDeletePath(zkUrl, "/violet/consumers/" + hostName + "/offsets/" + topic);

        IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

        ConsumerConfig config = new ConsumerConfig(props);
        KafkaConsumer consumer = new KafkaConsumer(config);
        List<Future<?>> list = Lists.newArrayList();
        List<KafkaStream<byte[], byte[]>> streamList = consumer.createMessageStreams(topic, threadNum);

        for (KafkaStream<byte[], byte[]> stream : streamList) {
            Iterator<MessageAndMetadata<byte[], byte[]>> iter = stream.iterator();
            list.add(TaskPoolFactory.feedbackTaskPool.submit(() -> {
                SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                ObjectMapper mapper = new ObjectMapper();
                while (iter.hasNext()) {
                    MessageAndMetadata<byte[], byte[]> msg = iter.next();
                    String data = new String(msg.message());
                    metrics.qps(metricPrefix + "_read_process");
                    metrics.qps(metricPrefix + "_kafka_partition_" + msg.partition());
                    Date now = new Date();
                    try {
                        JsonNode root = mapper.readTree(data);
                        String docid = getOrDefault(root, "docid", "null");
                        String uid = getOrDefault(root, "userid", "null");
                        String logDate = getOrDefault(root, "date", "null");
                        String event = getOrDefault(root, "event", "null");
                        String mashtype = getOrDefault(root, "mashtype", "null");
                        String appid = getOrDefault(root, "appid", "null");
                        String factor = null;
                        if (env != null && env.equals("video")) {
                            factor = getOrDefault(root, "vfactor", "null");
                        } else {
                            factor = getOrDefault(root, "factor", "null");
                        }
                        if (docid.equals("null") || uid.equals("null") || logDate.equals("null") || event.equals("null")) {
                            log.info(data + " missing key field!");
                            continue;
                        }
                        if (env != null && env.equals("video")) {
                            if (!vfactors.contains(factor)) {
                                continue;
                            }
                        } else {
                            if (!mashtype.equals("newsexplore") || !factor.equals("usercluster")) {
                                continue;
                            }
                        }

                        if (factor.startsWith("video-m2nExplore")) {
                            exploreExploitPools.model2newsUpdateExploreStatus(uid, docid, event, mashtype, appid);
                        } else if (factor.startsWith("video-ucExplore")) {
                            exploreExploitPools.userclusterUpdateExploreStatus(uid, docid, event, mashtype, appid);
                        } else if (factor.startsWith("microvideo-viewsassurance_dy")) {
                            exploreExploitPools.viewsAssuranceUpdateExploreStatus(Constants.DOUYIN, uid, docid, event, mashtype, appid);
                        } else if (factor.startsWith("microvideo-viewsassurance_mcn")) {
                            exploreExploitPools.viewsAssuranceUpdateExploreStatus(Constants.MCN, uid, docid, event, mashtype, appid);
                        } else if (factor.startsWith("microvideo-viewsassurance_ugc") || factor.startsWith("microvideo-ugcpool")) {
                            exploreExploitPools.viewsAssuranceUpdateExploreStatus(Constants.UGC, uid, docid, event, mashtype, appid);
                        } else if (factor.startsWith("microvideo-viewsassurance_momo")) {
                            exploreExploitPools.viewsAssuranceUpdateExploreStatus(Constants.MOMO, uid, docid, event, mashtype, appid);
                        }

                        try {
                            Date recvDate = simpleFormat.parse(logDate);
                            long delt = now.getTime() - recvDate.getTime();
                            int sec = (int) (delt / (1000));
                            if (sec > 600) {
                                recordAbnormal(1);
                            } else if (sec < 60) {
                                recordAbnormal(-1);
                            }
                            metrics.latency(metricPrefix + "_time_delta_" + appid, sec);
                        } catch (ParseException | NumberFormatException e) {
                            log.error("Process cjv feedback time delta exception:", e);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        log.error("feedback log parse error " + data);
                    }
                }
            }));
        }
        for (Future<?> future : list) {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                log.error(StringTools.LogExceptionStack(e));
            }
        }
    }

    public static void main(String[] args) {
        ExploreFeedback exploreFeedback = new ExploreFeedback("indata_str_usercluster_explore_video_feedback");
        exploreFeedback.run();
    }
}