package com.yidian.explore.filter;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hipu.util.TokenUtil;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.constant.LogManager;
import lombok.extern.log4j.Log4j;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.apache.http.entity.StringEntity;

import java.nio.charset.Charset;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Log4j
@Deprecated
public class FastTextFilter implements DocumentFilter {
    private static HttpClient client;
    private static String dedupServiceAddr = "http://10.111.0.20:9080/simdoc?minScore=0.4&minOutScore=2.0&fmt=json&newsid=";
    private static String JudgeServiceAddr = "http://10.120.170.9:9090/service/docJudge/judge";
    private static Gson gson = new Gson();
    private static HashSet<Integer> tpcBlackList = new HashSet<>();
    private static HashSet<String> srcBlackList = new HashSet<>();
    private static String metricPrefix = "usercluster-ee.docCollect";
    private static ObjectMapper mapper = new ObjectMapper();
    private static volatile FastTextFilter instance = null;
    private static String stopWords = "/ 。 ~ | ） （ 。。。 ... 「 」 + - — #. ： : 丨 【 】 、 \" 的 了 是 着 在 ， , ! ！ “ ” 《 》 ( ) … ? ？ # . ？· ' ?· 。。。　．．．　「　」　＋　－　—　＃　．　：　：　丨　【　】　、　的　了　是　着　在　，　，　！　！　“　”　《　》　（　）　…　？　？·　＂　＇";
    private static Set<String> stopWordsSet = new HashSet<>();

    static {
        PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager();
        connectionManager.setMaxTotal(100);
        connectionManager.setDefaultMaxPerRoute(100);
        client = new DefaultHttpClient(connectionManager);
        client.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5 * 10);
        client.getParams().setIntParameter(CoreConnectionPNames.SO_TIMEOUT, 150);
        tpcBlackList.add(5625);
        tpcBlackList.add(5);
        tpcBlackList.add(522);
        tpcBlackList.add(5219);
        tpcBlackList.add(6205);
        tpcBlackList.add(3435);
        tpcBlackList.add(1120);
        tpcBlackList.add(7902);
        tpcBlackList.add(8903);
        srcBlackList.add("北青网");
        for (String str : stopWords.split(" ")) {
            if (str.length() > 0) {
                stopWordsSet.add(str);
            }
        }
    }

    public static FastTextFilter getInstance() {
        if (instance == null) {
            synchronized (FastTextFilter.class) {
                if (instance == null) {
                    instance = new FastTextFilter();
                }
            }
        }
        return instance;
    }

    private FastTextFilter() {

    }

    public static boolean needTpcFilter(JsonNode jsonNode) {
        if (jsonNode == null) {
            return false;
        }
        try {
            JsonNode ltpcNode = jsonNode.get("ltpc");
            for (int i = 0; i < ltpcNode.size(); ++i) {
                int ltpc = ltpcNode.get(i).asInt();
                if (tpcBlackList.contains(ltpc)) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
        }
        return false;
    }

    public static boolean needDedup(String docid) {
        if (docid == null) {
            return false;
        }
        HttpGet get = new HttpGet(dedupServiceAddr + docid);
        try {
            HttpResponse response = client.execute(get);
            String respJsonStr = EntityUtils.toString(response.getEntity(), "UTF-8");
            if (respJsonStr == null) {
                return false;
            }

            Map<String, Object> retMap = gson.fromJson(respJsonStr, new TypeToken<Map<String, Object>>() {
            }.getType());

            if (retMap.containsKey("simnews") && retMap.get("simnews") != null) {
                Map<String, Object> simNewsMap = (Map<String, Object>) retMap.get("simnews");
                if (simNewsMap.size() > 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
        }
        return false;
    }

    public static boolean fastTextJudgeBad(String content) {
        if (content == null) {
            return false;
        }
        HttpPost post = new HttpPost(JudgeServiceAddr);
        StringEntity entity = new StringEntity(content, Charset.forName("utf8"));
        post.setEntity(entity);
        try {
            HttpResponse response = client.execute(post);
            String respJsonStr = EntityUtils.toString(response.getEntity(), "UTF-8");
            if (respJsonStr == null) {
                return false;
            }
            Map<String, Object> retMap = gson.fromJson(respJsonStr, new TypeToken<Map<String, Object>>() {
            }.getType());
            if (retMap.containsKey("result") && retMap.get("result") != null) {
                Map<String, Object> resultMap = (Map<String, Object>) retMap.get("result");
                String label = (String) resultMap.get("label");
                double probability = (double) resultMap.get("probability");
                if (label != null && label.equals("__label__bad") && probability > 0.9) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error(e);
            e.printStackTrace();
        }
        return false;
    }

    public Map<String, Double> getKeywords(JsonNode root) {
        List<List<Object>> keyword_list = Lists.newArrayList();
        for (int i = 0; i < root.size(); i++) {
            JsonNode one = root.get(i);
            List<Object> lst = Lists.newArrayList();
            if (one.size() != 2) {
                continue;
            }
            try {
                lst.add(one.get(0).asText());
                lst.add(one.get(1).asDouble());
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
            keyword_list.add(lst);
        }
        Map<String, Double> keywords = Maps.newHashMap();
        double max = 0d;
        for (List<Object> obj : keyword_list) {
            if (obj.size() == 2) {
                Number val = (Number) obj.get(1);
                max = Math.max(max, val.doubleValue());
            }
        }
        if (max > 1e-8) {
            for (List<Object> obj : keyword_list) {
                if (obj.size() == 2) {
                    String key = TokenUtil.token((String) obj.get(0));
                    Number val = (Number) obj.get(1);
                    keywords.put(key, val.doubleValue() / max);
                }
            }
        }
        return keywords;
    }

    private static String getOrDefault(JsonNode root, String field, String def) {
        if (root.has(field)) {
            return root.get(field).asText();
        }
        return def;
    }

    @Override
    public Optional<DocumentFeature> filter(String data) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            JsonNode root = mapper.readTree(data);
            String docid = getOrDefault(root, "_id", "null");
            String segTitle = getOrDefault(root, "seg_title", "null");
            String source = getOrDefault(root, "source", "null");
            String date = getOrDefault(root, "date", "null");
            String insert_time = getOrDefault(root, "insert_time", "null");
            String sig = getOrDefault(root, "signature", "null");
            String ctype = getOrDefault(root, "ctype", "news");

            if (!ctype.equals("news") && !ctype.equals("wenda")) {
                return Optional.empty();
            }

            int tier = -1;
            if (root.has("source_tier")) {
                tier = root.get("source_tier").asInt(-1);
            }

            int image_count = 8;
            if (root.has("image_count")) {
                image_count = root.get("image_count").asInt(8);
            }

            String docDetail = " doc docid: " + docid + " title: " + segTitle + " source: " + source + " date: " + date;

            if (ctype.equals("wenda")) {
                if (!docid.startsWith("K_")) {
                    return Optional.empty();
                }
                if (segTitle.replaceAll("\\s", "").length() > 20) {
                    LogManager.COLLECT.info("titleLengthfilter" + docDetail);
                    return Optional.empty();
                }
                if (image_count <= 0) {
                    LogManager.COLLECT.info("imageCountFilter" + docDetail);
                    return Optional.empty();
                }
                if (root.has("score_up")) {
                    tier = root.get("score_up").asInt(0);
                }
            }
            Date now = new Date();
            Date pubTime = now;
            Date insertTime = now;
            try {
                insertTime = simpleFormat.parse(insert_time);
            } catch (ParseException e) {
                log.error(e);
                e.printStackTrace();
            }

            if (srcBlackList.contains(source)) {
                LogManager.COLLECT.info("srcBlacklistfilter" + docDetail);
                return Optional.empty();
            }
            try {
                pubTime = simpleFormat.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            long delt = now.getTime() - pubTime.getTime();
            int minutes = (int) (delt / (1000 * 60));
            if (minutes > 4320) {
                LogManager.COLLECT.info("longtimefilter" + docDetail);
                return Optional.empty();
            }
            if (root.has("simdate") && root.has("date_long") && tier < 5) {
                long simdate = root.get("simdate").asLong(0);
                long date_long = root.get("date_long").asLong(0);
                date_long /= 1000;
                if (date_long - simdate > 7200) {
                    LogManager.COLLECT.info("simdatefilter" + docDetail);
                    return Optional.empty();
                }
            }
            if (tier < 4) {
                LogManager.COLLECT.info("tierfilter" + docDetail);
                return Optional.empty();
            }
            int bait = 0;
            if (root.has("bait")) {
                bait = root.get("bait").asInt(0);
            }
            if (bait > 1) {
                LogManager.COLLECT.info("baitfilter" + docDetail);
                return Optional.empty();
            }
            double sc_local = 0;
            if (root.has("sc_local")) {
                sc_local = root.get("sc_local").asDouble(0);
            }
            if (sc_local > 0.5) {
                LogManager.COLLECT.info("localfilter" + docDetail);
                return Optional.empty();
            }
            if (root.has("cat_class")) {
                JsonNode cat_class = root.get("cat_class");
                boolean flag = false;
                for (JsonNode node : cat_class) {
                    if (node.asText().equals("搞笑")) {
                        flag = true;
                        break;
                    }
                }
                if (flag) {
                    LogManager.COLLECT.info("catclassfilter" + docDetail);
                    return Optional.empty();
                }
            }
            if (docid.equals("null") || data.equals("null")) {
                log.info(data + " missing key field!");
                LogManager.COLLECT.info("keyfieldfilter" + docDetail);
                return Optional.empty();
            }
            if (needTpcFilter(root)) {
                LogManager.COLLECT.info("tpcfilter" + docDetail);
                return Optional.empty();
            }
            if (tier <= 4 && needDedup(docid)) {
                LogManager.COLLECT.info("dedup" + docDetail);
                return Optional.empty();
            }
            double sc_indepth = 1;
            if (root.has("sc_indepth")) {
                sc_indepth = root.get("sc_indepth").asDouble(1.0);
            }
            String seg_content = "";
            if (root.has("seg_content")) {
                seg_content = root.get("seg_content").asText();
            }
            List<String> clean_words = Lists.newArrayList();
            for (String word : segTitle.replaceAll("\\s+", " ").split(" ")) {
                if (stopWordsSet.contains(word)) {
                    continue;
                }
                clean_words.add(String.format("t_%s", word));
            }
            clean_words.add(String.format("src_%s", source.replaceAll("\\s+", "")));
            for (String word : seg_content.replaceAll("\\s+", " ").split(" ")) {
                if (stopWordsSet.contains(word)) {
                    continue;
                }
                clean_words.add(word);
            }
            String clean_sentence = Joiner.on(" ").join(clean_words);
            if (sc_indepth < 0.5 && image_count < 8 && !source.equals("知乎专栏") && fastTextJudgeBad(clean_sentence)) {
                LogManager.COLLECT.info("fastTextFilter" + docDetail);
                return Optional.empty();
            }
            if (docid.startsWith("K_") && fastTextJudgeBad(clean_sentence)) {
                LogManager.COLLECT.info("fastTextFilter" + docDetail);
                return Optional.empty();
            }
            Map<String, Double> keywords = Maps.newHashMap();
            if (root.has("keyword_list")) {
                keywords = getKeywords(root.get("keyword_list"));
            }
            DocumentFeature documentFeature = new DocumentFeature(docid, segTitle, source, insert_time, "pipline");
            documentFeature.setSig(sig);
            documentFeature.setTier(tier);
            documentFeature.setKeywords(keywords);
            return Optional.of(documentFeature);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("explore doc collect log parse error " + data);
        }
        return Optional.empty();
    }

    public static void main(String[] args) {
        FastTextFilter.needDedup("0HbnIlFB");
    }
}
