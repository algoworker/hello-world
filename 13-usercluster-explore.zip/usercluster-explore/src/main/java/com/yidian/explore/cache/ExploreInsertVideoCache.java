package com.yidian.explore.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import lombok.extern.log4j.Log4j;

import java.util.concurrent.TimeUnit;

/**
 * 暂存参与试探的视频,主要解决视频多次入库的重复问题
 */
@Log4j
public class ExploreInsertVideoCache {
    private static volatile Cache<String, Object> cache = CacheBuilder.newBuilder()
            .maximumSize(300000)
            .expireAfterWrite(24, TimeUnit.HOURS)
            .recordStats()
            .build();

    private ExploreInsertVideoCache() {

    }

    public static void put(String docid, Object object) {
        cache.put(docid, object);
    }

    public static boolean contain(String docid) {
        return (cache.getIfPresent(docid) != null);
    }
}
