package com.yidian.explore.utils;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.yidian.explore.constant.Constants;

import java.util.*;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class KnnParameterUtil {
    private static volatile KnnParameterUtil instance = null;
    private static Map<String, KnnParam> paramMap = Maps.newHashMap();
    private static ScheduledThreadPoolExecutor pool = new ScheduledThreadPoolExecutor(1);

    public static KnnParameterUtil getInstance() {
        if (instance == null) {
            synchronized (KnnParameterUtil.class) {
                if (instance == null) {
                    instance = new KnnParameterUtil();
                }
            }
        }
        return instance;
    }

    public KnnParam getKnnParam(String key) {
        if (paramMap.containsKey(key)) {
            return paramMap.get(key);
        }
        return null;
    }

    private KnnParameterUtil() {
        this.refreshParam();
        pool.scheduleAtFixedRate(this::refreshParam, 0, 1, TimeUnit.MINUTES);
    }

    private void refreshParam() {
        JSONObject object = JSONObject.parseObject(new String(MorphuesClient.getInstance(Constants.USERCF_PARAM).read(Constants.USER2EXPLOREVIDEO_ONLINE, Constants.PARAM_COLUMN)));
        String column = object.getString(Constants.COLUMN);
        Integer version = Integer.parseInt(object.getString(Constants.VERSION));
        String usercfColumn = object.getString(Constants.USERCF_COLUMN);
        Integer usercfVersion = Integer.parseInt(object.getString(Constants.USERCF_VERSION));
        paramMap.put(Constants.USER2EXPLOREVIDEO_ONLINE, new KnnParam(column, version, usercfColumn, usercfVersion));
    }

    public void refresh(String key) {
        if (paramMap.containsKey(key)) {
            JSONObject trainObject = JSONObject.parseObject(new String(MorphuesClient.getInstance(Constants.USERCF_PARAM).read(Constants.USER2EXPLOREVIDEO_TRAIN, Constants.PARAM_COLUMN)));
            KnnParam trainParam = new KnnParam(trainObject);
            // 把TRAIN的参数更新到ONLINE参数
            MorphuesClient.getInstance(Constants.USERCF_PARAM).write(Constants.USER2EXPLOREVIDEO_ONLINE, trainParam.tojson().toString().getBytes(), Constants.PARAM_COLUMN);
        }
    }

    public static void main(String[] args) {
        KnnParameterUtil.getInstance().refresh(Constants.USER2EXPLOREVIDEO_ONLINE);
        System.exit(0);
    }
}
