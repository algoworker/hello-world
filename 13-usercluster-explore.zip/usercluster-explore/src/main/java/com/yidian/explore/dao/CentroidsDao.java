package com.yidian.explore.dao;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yidian.explore.config.ExploreExploitConfig;
import lombok.extern.log4j.Log4j;

import java.io.*;
import java.util.List;
import java.util.Map;

@Log4j
public class CentroidsDao {
    private static volatile CentroidsDao instances = null;
    private static VecInfo centroidsVecInfo = new VecInfo();

    static class VecInfo {
        int num;
        int size;
        Map<String, float[]> vec;
    }

    public static CentroidsDao defaultDAO() {
        if (instances == null) {
            synchronized (CentroidsDao.class) {
                if (instances == null) {
                    instances = new CentroidsDao();
                }
            }
        }
        return instances;
    }

    private CentroidsDao() {
        centroidsVecInfo.num = 0;
        centroidsVecInfo.size = 128;
        centroidsVecInfo.vec = Maps.newHashMap();
        try {
            loadVector(ExploreExploitConfig.defaultConfig().getCentroidsFile());
        } catch (IOException e) {
            log.error("Load cluster centroids vector exception:", e);
        }
    }

    private static void loadVector(String fileName) throws IOException {
        if (fileName == null) {
            return;
        }
        InputStreamReader isr = new InputStreamReader(new FileInputStream(fileName));
        BufferedReader br = new BufferedReader(isr);

        String line = null;
        while ((line = br.readLine()) != null) {
            String parts[] = line.trim().split("\t");
            if (parts.length != 2) {
                log.error("centroids file format error!");
                System.exit(-1);
            }
            String vecString[] = parts[1].split(" ");
            if (vecString.length != centroidsVecInfo.size) {
                log.error("centroids file dim error!");
                System.exit(-1);
            }
            float vec[] = new float[centroidsVecInfo.size];
            boolean isOk = true;
            for (int i = 0; i < vecString.length; i++) {
                try {
                    vec[i] = Float.parseFloat(vecString[i]);
                } catch (NumberFormatException e) {
                    log.error("Parse float vector exception:", e);
                    isOk = false;
                    break;
                }
            }
            if (!isOk) {
                continue;
            }
            centroidsVecInfo.vec.put(parts[0], vec);
        }
        centroidsVecInfo.num = centroidsVecInfo.vec.size();
    }

    public float[] getVecByCid(String cid) {
        return centroidsVecInfo.vec.getOrDefault(cid, null);
    }

    public List<String> getCids() {
        return Lists.newArrayList(centroidsVecInfo.vec.keySet());
    }

    public static void main(String[] args) {
        float[] ret = CentroidsDao.defaultDAO().getVecByCid("c52");
        System.out.println(ret);
    }
}
