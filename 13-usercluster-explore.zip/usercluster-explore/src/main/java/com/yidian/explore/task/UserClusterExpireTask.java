package com.yidian.explore.task;

import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.constant.LogManager;
import lombok.extern.log4j.Log4j;

import java.util.Date;

@Log4j
public class UserClusterExpireTask extends Thread{
    private long delay;
    private static IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

    public UserClusterExpireTask(int delayInSeconds) {
        this.delay = delayInSeconds;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(delay * 1000);
                exploreExploitPools.expire();
                Date next = new Date(System.currentTimeMillis() + delay * 1000);
                LogManager.EXPIRE.info("Expire done and next expire task will be executed at " + next.toString());
            } catch (InterruptedException e) {
                log.error("Schedule exploreExploitPools or exploreExploitVideoPools expire task exception:", e);
            }
        }
    }
}