package com.yidian.explore.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheStats;
import com.google.common.collect.Maps;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class KeyValueCache {
    private static volatile KeyValueCache instance = null;
    private volatile Cache<String, Optional<Boolean>> cache = CacheBuilder.newBuilder().maximumSize(200000).expireAfterWrite(5, TimeUnit.HOURS).recordStats().build();

    public static KeyValueCache defaultCache() {
        if (instance == null) {
            synchronized (KeyValueCache.class) {
                if (instance == null) {
                    instance = new KeyValueCache();
                }
            }
        }
        return instance;
    }

    private KeyValueCache() {

    }

    public Optional<Boolean> get(String key, Callable<Optional<Boolean>> c) {
        try {
            return cache.get(key, c);
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return Optional.of(false);
    }

    public Map<String, Object> getCacheStats() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        CacheStats stats = cache.stats();
        ret.put("keyValueCacheStats", stats.toString());
        ret.put("avgLoadPenalty", stats.averageLoadPenalty());
        ret.put("hitRate", stats.hitRate());
        ret.put("missRate", stats.missRate());
        ret.put("size", cache.size());
        return ret;
    }

    public long size() {
        return cache.size();
    }

    public void invalidateAll() {
        cache.invalidateAll();
    }
}