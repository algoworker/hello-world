package com.yidian.explore.constant;

public enum MetricsNameEnum {
    /**
     * exploreRealClick/exploreRealView:能够join到doc的play/view事件
     * exploreCjvClick/exploreCjvView:cjv下发的全部play/view事件
     */
    exploreRealClick,
    exploreRealView,
    exploreCjvClick,
    exploreCjvView,

    /**
     * 对应s_explore特征的expire reason
     */
    exploreLifetimeExpire,
    exploreBeyondViewsExpire,
    exploreLowCtrExpire,
    exploreToExploitExpire,
    poolSizeExpire,

    /**
     * 读取视频入库kafka进行的统计
     */
    nonChineseTitleVideo,
    passAuditVideo,
    nativeVideo,
    minuteDurationVideo,
    scLocalVideo,
    longTimeVideo,
    emptyKeywordListVideo,
    emptyYdTagsVideo,
    microVideo,
    iqiyiExploreVideo,
    scopeExceptionVideo,
    repeatedInsertVideo,
    lowSourceTierVideo,
    scDirtyVideo,
    specialTagsVideo,
    vivoToutiaoVideo,

    /**
     * VideoFilter处理前后的统计
     */
    beforeFilter,
    afterFilter,

    /**
     * model2news有效试探统计
     */
    effectiveExplore,

    /**
     * model2news试探生成的s_exploit特征统计
     */
    feedbackExplosiveFeature,
    feedbackExcellentFeature,
    feedbackGoodFeature,
    feedbackGeneralFeature,
    feedbackBadFeature,
    feedbackTerribleFeature,
    feedbackNullFeature,
}
