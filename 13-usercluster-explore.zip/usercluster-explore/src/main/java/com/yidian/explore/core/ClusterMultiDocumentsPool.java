package com.yidian.explore.core;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yidian.explore.compare_key.CompareKey;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.merger.DocumentsMerger;
import lombok.Data;
import org.codehaus.jackson.JsonNode;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Data
public class ClusterMultiDocumentsPool implements MultiDocumentsPool {
    private String cid = null;
    private DocumentsMerger merger = null;
    private Map<String, DocumentsPool> documentsPoolMap = Maps.newHashMap();

    public ClusterMultiDocumentsPool(String cid, DocumentsMerger merger){
        this.cid = cid;
        this.merger = merger;
    }

    @Override
    public boolean addDocumentsPool(String poolName) {
        if(documentsPoolMap.containsKey(poolName)){
            return false;
        }
        documentsPoolMap.put(poolName, new ClusterDocumentsPool(cid));
        return true;
    }

    @Override
    public boolean addDocument(String poolName, DocumentFeature doc) {
        if(!documentsPoolMap.containsKey(poolName)){
            return false;
        }
        DocumentsPool documentsPool = documentsPoolMap.get(poolName);
        documentsPool.addDocument(doc);
        return true;
    }

    @Override
    public boolean addDocumentInfo(String poolName, DocumentInfo documentInfo) {
        if(documentsPoolMap.containsKey(poolName)){
            return documentsPoolMap.get(poolName).addDocumentInfo(documentInfo);
        }
        return false;
    }

    @Override
    public DocumentInfo removeDocumentInfo(String poolName, String dodid) {
        if(documentsPoolMap.containsKey(poolName)){
            return documentsPoolMap.get(poolName).removeDocumentInfo(dodid);
        }
        return null;
    }

    @Override
    public boolean updateStatus(String uid, String docid, String event) {
        for(DocumentsPool documentsPool: documentsPoolMap.values()){
            documentsPool.updateStatus(uid, docid, event);
        }
        return true;
    }

    @Override
    public boolean model2newsUpdateStatus(String uid, String docid, String event) {
        if (documentsPoolMap.containsKey(Constants.MODEL2NEWS_VIDEO_POOL)) {
            DocumentsPool documentsPool = documentsPoolMap.get(Constants.MODEL2NEWS_VIDEO_POOL);
            return documentsPool.updateStatus(uid, docid, event);
        }
        return false;
    }

    @Override
    public Map<String, List<DocumentInfo>> expire() {
        Map<String, List<DocumentInfo>> ret = Maps.newHashMap();
        for(Map.Entry<String, DocumentsPool> entry: documentsPoolMap.entrySet()){
            ret.put(entry.getKey(), entry.getValue().expire());
        }
        return ret;
    }

    @Override
    public Map<String, List<DocumentInfo>> model2newsExpire() {
        Map<String, List<DocumentInfo>> ret = Maps.newHashMap();
        for(Map.Entry<String, DocumentsPool> entry: documentsPoolMap.entrySet()){  // documentsPoolMap=highPriorityPool+lowPriorityPool
            ret.put(entry.getKey(), entry.getValue().model2newsExpire());
        }
        return ret;
    }

    @Override
    public List<DocumentInfo> fetch(int topn) {
        List<List<DocumentInfo>> ret = Lists.newArrayList();
        for(DocumentsPool documentsPool: documentsPoolMap.values()){
            ret.add(documentsPool.fetch(topn));
        }
        return merger.merge(ret);
    }

    @Override
    public List<DocumentInfo> fetch(int topn, CompareKey ck) {
        List<List<DocumentInfo>> ret = Lists.newArrayList();
        for(DocumentsPool documentsPool: documentsPoolMap.values()){
            ret.add(documentsPool.fetch(topn, ck));
        }
        return merger.merge(ret);
    }

    @Override
    public Map<String, Object> getDebugInfo(String poolName, int topn, CompareKey ck) {
        Map<String, Object> ret = Maps.newHashMap();
        DocumentsPool documentsPool = documentsPoolMap.get(poolName);
        if(documentsPool == null){
            return ret;
        }
        return documentsPool.getDebugInfo(topn, ck);
    }

    @Override
    public Map<String, DocumentInfo> getClusterDocumentInfos(String poolName){
        Map<String, DocumentInfo> ret = Maps.newHashMap();
        DocumentsPool documentsPool = documentsPoolMap.get(poolName);
        if(documentsPool == null){
            return ret;
        }
        return documentsPool.getClusterDocumentInfos();
    }

    @Override
    public boolean deserialize(JsonNode root) {
        if(root.has("cid")){
            cid = root.get("cid").asText();
        }
        if(root.has("merger")){
            String mergerString = root.get("merger").asText();
        }
        if(root.has("documentsPoolMap")){
            JsonNode documentsPoolMapNode = root.get("documentsPoolMap");
            Iterator<String> fieldNames = documentsPoolMapNode.getFieldNames();
            while(fieldNames.hasNext()){
                String poolName = fieldNames.next();
                JsonNode DocumentsPoolNode =  documentsPoolMapNode.get(poolName);
                ClusterDocumentsPool clusterDocumentsPool = new ClusterDocumentsPool(cid);
                clusterDocumentsPool.deserialize(DocumentsPoolNode);
                documentsPoolMap.put(poolName, clusterDocumentsPool);
            }
        }
        return true;
    }

    @Override
    public Map<String, Object> serialize() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        ret.put("cid", cid);
        Map<String, Object> documentsPoolMapInfo = Maps.newLinkedHashMap();
        for(Map.Entry<String, DocumentsPool> entry: documentsPoolMap.entrySet()){
            documentsPoolMapInfo.put(entry.getKey(), entry.getValue().serialize());
        }
        ret.put("documentsPoolMap", documentsPoolMapInfo);
        return ret;
    }

    @Override
    public boolean embedFrameVector() {
        for(DocumentsPool documentsPool: documentsPoolMap.values()){
            documentsPool.embedFrameVector();
        }
        return true;
    }
}
