package com.yidian.explore.utils.convertor;

import com.alibaba.fastjson.JSONObject;
import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

public class JsonConfigObjectConvertor implements IConfigObjectConvertor<JSONObject> {
    @Override
    public JSONObject convert(String value) {
        if (org.apache.commons.lang3.StringUtils.isNotBlank(value)) {
            return JSONObject.parseObject(value);
        }
        return null;
    }
}