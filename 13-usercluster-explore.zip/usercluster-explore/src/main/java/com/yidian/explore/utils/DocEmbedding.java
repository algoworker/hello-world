package com.yidian.explore.utils;

import com.google.common.collect.Sets;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.DocumentFeature;
import lombok.extern.log4j.Log4j;

import java.io.*;
import java.util.*;

/**
 * Created by xiaobo on 2017/1/16.
 */
@Log4j
@Deprecated
public class DocEmbedding {
    private static String wordBlacklist = "爆笑 搞笑 趣图 gif 笑趣图 内涵图 囧 笑话 笑抽 内涵趣 动态图 动图 笑死 内涵图 内涵集锦 无节操 段子 糗事 恶搞 恶作剧 坑爹";
    private static Map<String, Integer> word_blacklist_map = new HashMap<>();

    private static String stopwords = "。。。 ... 「 」 + - — # . ： : 丨 【 】 、 的 了 是 着 在 ， , ! ！ “ ” 《 》 ( ) … ? ？· \" ' ?· 。。。　．．．　「　」　＋　－　—　＃　．　：　：　丨　【　】　、　的　了　是　着　在　，　，　！　！　“　”　《　》　（　）　…　？　？·　＂　＇";
    private static Map<String, Integer> stopwords_map = new HashMap<>();

    private static VecInfo word_vec_info = new VecInfo();

    private static volatile DocEmbedding instance;
    public static DocEmbedding defaultInstance() {
        if (instance == null) {
            synchronized (DocEmbedding.class) {
                if (instance == null) {
                    instance = new DocEmbedding();
                }
            }
        }
        return instance;
    }

    static class VecInfo {
        int num;
        int size;
        HashMap<String, float[]> vec;
    }

    static {
        for (String str : wordBlacklist.split(" ")) {
            if (str.length() > 0) {
                word_blacklist_map.put(str, 1);
            }
        }

        for (String str : stopwords.split(" ")) {
            if (str.length() > 0) {
                stopwords_map.put(str, 1);
            }
        }
    }

    private DocEmbedding(){
        init(ExploreExploitConfig.defaultConfig().getWordVecFile());
    }

    public int getVecSize() {
        return word_vec_info.size;
    }

    public static String getSegTitleWords(String segTitle){
        StringBuilder sb = new StringBuilder();
        for(char ch: segTitle.toCharArray()){
            if(stopwords_map.containsKey(String.valueOf(ch))){
                continue;
            }
            if(ch == ' '){
                continue;
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    public static Set<String> getJaccardSet(String txt, int window){
        Set<String> ret = Sets.newHashSet();
//        for(int i = window; i <= txt.length(); i++){
//            ret.add(txt.substring(i - window, i));
//        }
        for(char ch: txt.toCharArray()){
            ret.add(String.valueOf(ch));
        }
        return ret;
    }

    public static double JaccardScore(String words1, String words2){
        Set<String> set1 = getJaccardSet(words1, 3);
        Set<String> set2 = getJaccardSet(words2, 3);
        int cross_num = 0;
        for(String str: set1){
            if(set2.contains(str)){
                cross_num += 1;
            }
        }
        set1.addAll(set2);
        int union_num = set1.size();
        return cross_num * 1.0 / union_num;
    }

    private ArrayList<String> getDocFeature(DocumentFeature doc) {
        ArrayList<String> feature_list = new ArrayList<>();
        if (doc == null) {
            return feature_list;
        }
        String title = doc.getSeg_title();
        if(title == null){
            return feature_list;
        }
        String[] stitle = title.split(" ");
        List<Map.Entry<String, Double>> keywords_list = new ArrayList<Map.Entry<String, Double>>(doc.getKeywords().entrySet());
        Collections.sort(keywords_list, new Comparator<Map.Entry<String, Double>>() {
            public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });

        boolean is_filter = false;
        for (String token : stitle) {
            if (word_blacklist_map.containsKey(token)) {
                is_filter = true;
                break;
            }
            if (stopwords_map.containsKey(token)) {
                continue;
            }
            token = token.replaceAll("\\s", "");
            if(token.length() == 0){
                continue;
            }
            if (!feature_list.contains("t_" + token)) {
                feature_list.add("t_" + token);
            }
        }
        String source = doc.getSource();
        if(source == null){
            source = "";
        }
        source = source.replaceAll("\\s", "");
        if(source.length() != 0) {
            feature_list.add("src_" + doc.getSource());
        }

        int kws_num = 0;
        for (Map.Entry<String, Double> keywords_score : keywords_list) {
            String kws = keywords_score.getKey();
            if(kws.contains("^^")) {
                continue;
            }
            if (kws_num++ >= 20) {
                break;
            }
            kws = kws.replaceAll("\\s", "");
            if(kws.length() == 0){
                continue;
            }
            feature_list.add("kws_" + kws);
        }
        if (is_filter || feature_list.size() < 5) {
            feature_list.clear();
        }
        feature_list = new ArrayList<>(new LinkedHashSet<>(feature_list));
        return feature_list;
    }

    public float[] getDocVec(DocumentFeature doc) {
        if (doc == null) {
            return null;
        }
        int i;
        float[] vec = new float[word_vec_info.size];
        ArrayList<String> feature_list = getDocFeature(doc);

        if (feature_list == null || feature_list.size() <= 0/*5*/) {
            return null;
        }

        int Chinese_token_num = 0;
        for (String feature : feature_list) {
            if (isChinese(feature)) {
                Chinese_token_num++;
            }
        }
        if (Chinese_token_num <= 5) {
            return null;
        }
        for (String feature : feature_list) {
            float[] feature_vec = word_vec_info.vec.get(feature);
            if (feature_vec == null) {
                continue;
            }
            for (i = 0; i < word_vec_info.size; ++i) {
                vec[i] += feature_vec[i];
            }
        }
        double len = 0;
        for (i = 0; i < word_vec_info.size; ++i) {
            len += vec[i] * vec[i];
        }
        if (len == 0) {
            return null;
        }

        len = Math.sqrt(len);
        for (i = 0; i < word_vec_info.size; ++i) {
            vec[i] = (float)((double)vec[i] / len);
        }
        return vec;
    }

    private void init(String word_vec_file) {
        if (word_vec_file == null) {
            System.exit(-1);
        }
        try {
            log.info("load word vec:" + word_vec_file);
            load_vec(word_vec_file);
            log.info("word vec loaded.");
        } catch (Exception e) {
            log.error(e);
            System.exit(-1);
        }

        if (word_vec_info.size == 0) {
            log.error("model formate error.");
            System.exit(-1);
        }
    }

    private static void load_vec(String file_name) throws IOException {
        if (file_name == null || word_vec_info == null) {
            return;
        }

        DataInputStream dis = null;
        BufferedInputStream bis = null;

//        double len;
        float value;

        word_vec_info.num = 0;
        word_vec_info.size = 0;

        try {
            log.info("load vec from " + file_name);
            bis = new BufferedInputStream(new FileInputStream(file_name));
            dis = new DataInputStream(bis);

            word_vec_info.num = Integer.parseInt(readString(dis));
            log.info("num:" + word_vec_info.num);
            word_vec_info.size = Integer.parseInt(readString(dis));
            log.info("size:" + word_vec_info.size);

            word_vec_info.vec = new HashMap<>((int)(word_vec_info.num / 0.75 + 10));

            for (int i = 0; i < word_vec_info.num; ++i) {
                String id = readString(dis);
                float[] vec = new float[word_vec_info.size];
//                len = 0.0D;

                int j;
                for (j = 0; j < word_vec_info.size; ++j) {
                    value = readFloat(dis);
//                    len += (double)(value * value);
                    vec[j] = value;
                }

//                len = Math.sqrt(len);

//                for (j = 0; j < word_vec_info.size; ++j) {
//                    vec[j] = (float)((double)vec[j] / len);
//                }
                if (i % 10000 == 0) {
                    log.info("load line " + i + ":" + id);
                }
                word_vec_info.vec.put(id, vec);
                dis.read();
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            if (bis != null) {
                bis.close();
            }
            if (dis != null) {
                dis.close();
            }
        }
    }

    private static final boolean isChinese(char c) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
            return true;
        }
        return false;
    }

    public static final boolean isChinese(String strName) {
        char[] ch = strName.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            char c = ch[i];
            if (isChinese(c)) {
                return true;
            }
        }
        return false;
    }

    public static float readFloat(InputStream is) throws IOException {
        byte[] bytes = new byte[4];
        is.read(bytes);
        return getFloat(bytes);
    }

    public static float getFloat(byte[] b) {
        byte accum = 0;
        int accum1 = accum | (b[0] & 255) << 0;
        accum1 |= (b[1] & 255) << 8;
        accum1 |= (b[2] & 255) << 16;
        accum1 |= (b[3] & 255) << 24;
        return Float.intBitsToFloat(accum1);
    }

    private static String readString(DataInputStream dis) throws IOException {
        byte[] bytes = new byte[50];
        byte b = dis.readByte();
        int i = -1;
        StringBuilder sb = new StringBuilder();

        while(b != 32 && b != 10) {
            ++i;
            bytes[i] = b;
            b = dis.readByte();
            if(i == 49) {
                sb.append(new String(bytes));
                i = -1;
                bytes = new byte[50];
            }
        }
        sb.append(new String(bytes, 0, i + 1));//i = -1 is ok?
        return sb.toString();
    }
    public static void main(String [] args){
        String words1 = "腾讯 隐藏 秘密 : 活跃 用户 与 毛利 增速 放缓 , 社交 发展 空间 有限";
        String words2 = "腾讯 财报 隐藏 秘密 : 用户 与 毛利 增速 放缓 , 社交 发展 空间 有限";
        double score = JaccardScore(getSegTitleWords(words1), getSegTitleWords(words2));
        System.out.println(score);
    }
}
