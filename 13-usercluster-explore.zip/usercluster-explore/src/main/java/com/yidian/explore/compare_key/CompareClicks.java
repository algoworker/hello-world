package com.yidian.explore.compare_key;

import com.yidian.explore.core.DocumentInfo;

public class CompareClicks implements CompareKey{
    @Override
    public Number getCompareKey(DocumentInfo doc) {
        return -doc.getClicks();
    }
}
