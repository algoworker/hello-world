package com.yidian.explore.marker;

import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.dao.CentroidsDao;
import com.yidian.explore.utils.DocEmbedding;

@Deprecated
public class VectorDistanceMarker implements Marker {
    @Override
    public float score(String cid, DocumentFeature df) {
        float[] cvec = CentroidsDao.defaultDAO().getVecByCid(cid);
        float[] dvec = DocEmbedding.defaultInstance().getDocVec(df);

        float score = 0;
        if (cvec == null || dvec == null) {
            return score;
        }
        for (int i = 0; i < cvec.length; i++) {
            score += cvec[i] * dvec[i];
        }

        return score;
    }
}
