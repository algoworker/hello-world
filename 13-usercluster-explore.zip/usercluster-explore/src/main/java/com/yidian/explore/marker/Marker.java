package com.yidian.explore.marker;

import com.yidian.explore.core.DocumentFeature;

public interface Marker {
    float score(String cid, DocumentFeature df);
}
