package com.yidian.explore.core;

import com.google.common.collect.Maps;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.constant.DauDistribution;
import lombok.Data;
import lombok.ToString;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;
import org.mongodb.morphia.annotations.Transient;

import java.text.ParseException;
import java.util.*;

@Data
@Log4j
@ToString(callSuper = true)
public class VideoInfo extends DocumentInfo {
    /**
     * totalBoostView:需要扩大分发的总view数
     */
    @Transient
    private double totalBoostView;

    /**
     * lastGlobalView:上一次刷新时的globalView
     */
    @Transient
    private double lastGlobalView;

    /**
     * plannedHourBoostView:下一小时计划扩大的view数
     */
    @Transient
    private double plannedHourBoostView;

    /**
     * plannedHourViewCoefficient:下一小时计划扩大的view数对应的系数,根据实际分发量与计划分发量进行调整
     */
    @Transient
    private double plannedHourViewCoefficient = 1.0D;

    /**
     * newBoostVideo:allInVideoPoolExpire得到的boostVideo在第一次boostViewExploitExpire执行时不进行参数调整
     */
    @Transient
    private boolean newBoostVideo = false;

    public VideoInfo() {
        super();
    }

    public VideoInfo(String docid, String titleWords, String source, int tier, float baseScore, Date date, String refer) {
        super(docid, titleWords, source, tier, baseScore, date, refer);
    }

    public void initBoostVideoInfoFields(VideoInfo videoInfo, double globalCtr, double globalView) {
        String currentDate = Constants.simpleDateFormat.format(new Date());
        int currentHour = Integer.parseInt(currentDate.substring(11, 13));
        double currentViewCoefficient = DauDistribution.getOppobrowserDauDistribution().get(currentHour);
        // neededViews是当前视频需要扩大的总views数
        // TODO set this neededViews double neededViews = (5 * globalCtr - 1) * globalView;
        double neededViews = Math.pow(2, 10 * globalCtr + 11) + globalCtr * globalView;
        videoInfo.setTotalBoostView(neededViews);  // 需要扩大分发的总view数
        videoInfo.setLastGlobalView(globalView);  // 当前globalView
        videoInfo.setPlannedHourBoostView(neededViews * currentViewCoefficient);  // 初始化下一个小时的需要的扩大分发数
        videoInfo.setPlannedHourViewCoefficient(1.0);  // 初始化下一个小时的需要的分发系数
        videoInfo.setNewBoostVideo(true);  // 首次扩大分发标识
    }

    /**
     * 判断入库24h之后的视频是否需要扩大分发
     * 这里认为ctr>0.2的视频为需要加强分发的好视频
     * oppobrowser近一个月单篇视频的平均曝光基数为1100
     */
    public static boolean isBoostViewVideo(double globalCtr, double globalView, double dwell) {
        if (globalCtr < Constants.G_CTR_TH || dwell < Constants.G_DWELL_TH) {
            return false;
        }
        double weight = globalCtr / 0.1 * 1000;
        double viewUpperLimit = Math.pow(2.5, globalCtr / Constants.G_CTR_TH) * weight;
        return globalView > Constants.GVIEW_LOWER_LIMIT && globalView < viewUpperLimit;
    }

    /**
     * allInVideoSerialize
     * 单独为allInVideoPool服务的serialize,简化allInVideoPool写入mongo的数据
     */
    public Map<String, Object> allInVideoSerialize() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        ret.put("views", views);
        ret.put("baseScore", baseScore);
        ret.put("docid", docid);
        ret.put("source", source);
        ret.put("titleWords", titleWords);
        ret.put("refer", refer);
        ret.put("tier", tier);
        ret.put("date", Constants.simpleDateFormat.format(date));
        return ret;
    }

    /**
     * boostViewVideoSerialize
     * 单独为boostViewVideoPool服务的serialize,将VideoInfo特有的5个fields写入mongo
     */
    public Map<String, Object> boostViewVideoSerialize() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        ret.put("views", views);
        ret.put("baseScore", baseScore);
        ret.put("docid", docid);
        ret.put("source", source);
        ret.put("titleWords", titleWords);
        ret.put("refer", refer);
        ret.put("tier", tier);
        ret.put("date", Constants.simpleDateFormat.format(date));
        // boost view video fields
        ret.put("totalBoostView", totalBoostView);
        ret.put("lastGlobalView", lastGlobalView);
        ret.put("plannedHourBoostView", plannedHourBoostView);
        ret.put("plannedHourViewCoefficient", plannedHourViewCoefficient);
        ret.put("newBoostVideo", newBoostVideo);
        return ret;
    }

    /**
     * boostViewVideoDeserialize
     * 单独为boostViewVideoPool服务的deserialize,加载VideoInfo特有的5个fields
     */
    public boolean boostViewVideoDeserialize(JsonNode root) {
        try {
            if (root.has("clicks")) {
                clicks = root.get("clicks").asInt(0);
            }
            if (root.has("views")) {
                views = root.get("views").asInt(0);
            }
            if (root.has("baseScore")) {
                baseScore = (float) root.get("baseScore").asDouble();
            }
            if (root.has("docid")) {
                docid = root.get("docid").asText();
            }
            if (root.has("source")) {
                source = root.get("source").asText();
            }
            if (root.has("titleWords")) {
                titleWords = root.get("titleWords").asText();
            }
            if (root.has("refer")) {
                refer = root.get("refer").asText();
            }
            if (root.has("tier")) {
                tier = root.get("tier").asInt(0);
            }
            if (root.has("date")) {
                String dateString = root.get("date").asText();
                date = new Date();
                try {
                    date = Constants.simpleDateFormat.parse(dateString);
                } catch (ParseException e) {
                    log.error("Parse date string to Date exception:", e);
                }
            }
            if (root.has("thumbUps")) {
                thumbUps = root.get("thumbUps").asInt(0);
            }
            if (root.has("shareDocs")) {
                shareDocs = root.get("shareDocs").asInt(0);
            }
            if (root.has("likes")) {
                likes = root.get("likes").asInt(0);
            }
            if (root.has("comments")) {
                comments = root.get("comments").asInt(0);
            }
            // boost view video fields
            if (root.has("totalBoostView")) {
                totalBoostView = root.get("totalBoostView").asDouble(0.0);
            }
            if (root.has("lastGlobalView")) {
                lastGlobalView = root.get("lastGlobalView").asDouble(0.0);
            }
            if (root.has("plannedHourBoostView")) {
                plannedHourBoostView = root.get("plannedHourBoostView").asDouble(0.0);
            }
            if (root.has("plannedHourViewCoefficient")) {
                plannedHourViewCoefficient = root.get("plannedHourViewCoefficient").asDouble(1.0);
            }
            if (root.has("newBoostVideo")) {
                newBoostVideo = root.get("newBoostVideo").asBoolean(false);
            }
        } catch (Exception e) {
            log.error("VideoInfo deserialize exception:", e);
            return false;
        }
        return true;
    }

    public static void main(String[] args) {
        DocumentInfo df = new VideoInfo();
        System.out.println(df instanceof VideoInfo);
        Date now = new Date();
        System.out.println(now);
        System.out.println(System.currentTimeMillis());

        Calendar currentTime = Calendar.getInstance();
        currentTime.setTime(now);
        int currentHour = currentTime.get(Calendar.HOUR);
        currentTime.set(Calendar.HOUR, currentHour + 1);
        currentTime.set(Calendar.MINUTE, 0);
        currentTime.set(Calendar.SECOND, 0);
        currentTime.set(Calendar.MILLISECOND, 0);

        Date nextHour = currentTime.getTime();
        System.out.println(nextHour);
        System.out.println(nextHour.getTime());
        System.out.println(nextHour.getTime() - now.getTime());
    }
}
