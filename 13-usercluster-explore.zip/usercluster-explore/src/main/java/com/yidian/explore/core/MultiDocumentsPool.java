package com.yidian.explore.core;

import com.yidian.explore.compare_key.CompareKey;
import org.codehaus.jackson.JsonNode;

import java.util.List;
import java.util.Map;

public interface MultiDocumentsPool {
    boolean addDocumentsPool(String poolName);

    boolean addDocument(String poolName, DocumentFeature doc);

    boolean addDocumentInfo(String poolName, DocumentInfo documentInfo);

    DocumentInfo removeDocumentInfo(String poolName, String dodid);

    boolean updateStatus(String uid, String docid, String event);

    boolean model2newsUpdateStatus(String uid, String docid, String event);

    Map<String, List<DocumentInfo>> expire();

    Map<String, List<DocumentInfo>> model2newsExpire();

    List<DocumentInfo> fetch(int topn);

    List<DocumentInfo> fetch(int topn, CompareKey ck);

    Map<String, Object> getDebugInfo(String poolName, int topn, CompareKey ck);

    boolean deserialize(JsonNode root);

    Map<String, Object> serialize();

    boolean embedFrameVector();

    Map<String, DocumentInfo> getClusterDocumentInfos(String poolName);
}
