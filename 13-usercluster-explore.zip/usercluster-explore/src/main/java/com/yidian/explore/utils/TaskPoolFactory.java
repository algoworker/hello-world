package com.yidian.explore.utils;

import com.yidian.explore.constant.Constants;

public class TaskPoolFactory {
    public static volatile TaskPool userclusterAddDocumentTaskPool = new TaskPool(10, 50, 20, 3000, "UserClusterAddVideo");
    public static volatile TaskPool userclusterExpireTaskPool = new TaskPool(10, 50, 20, 3000, "UserClusterExpire");
    public static volatile TaskPool feedbackTaskPool = new TaskPool(Constants.FEEDBACK_THREAD_NUM, 10, 20, 3000, "VideoFeedback");

    private TaskPoolFactory() {

    }
}