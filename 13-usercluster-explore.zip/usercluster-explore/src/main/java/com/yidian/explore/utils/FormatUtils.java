package com.yidian.explore.utils;

import java.nio.ByteBuffer;

/**
 * Created by guopeidong on 2017/8/3.
 */
public class FormatUtils {
    public static float[] bytes2floats(byte[] bytes) {
        float[] res = new float[bytes.length / 4];
        ByteBuffer.wrap(bytes).asFloatBuffer().get(res);

        return res;
    }

    public static byte[] floats2bytes(float[] floats) {
        ByteBuffer buffer = ByteBuffer.allocate(4 * floats.length);

        for (float value : floats) {
            buffer.putFloat(value);
        }
        return buffer.array();
    }

    public static float[] string2floats(String str) {
        String[] contents = str.split(" ");
        float[] res = new float[contents.length];

        for (int i = 0; i < contents.length; i++) {
            res[i] = Float.parseFloat(contents[i]);
        }
        return res;
    }

    public static String floats2str(float[] floats) {
        String sep = " ";
        StringBuilder sbRes = new StringBuilder();

        if (floats.length > 0) {
            sbRes.append(String.format("%.6f", floats[0]));
        }

        for (int i = 1; i < floats.length; i++) {
            sbRes.append(" " + String.format("%.6f", floats[i]));
        }
        return sbRes.toString();
    }

    public static byte[] str2bytes(String str) {
        return str.getBytes();
    }

    public static String bytes2string(byte[] bytes) {
        return new String(bytes);
    }

    public interface ValueFormatter {
        byte[] format(String value);
    }
}