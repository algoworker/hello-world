package com.yidian.explore.dao;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.utils.MorphuesClient;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class Userid2CidDao {
    private static volatile Userid2CidDao instance = null;

    private LoadingCache<String, List<String>> cache = CacheBuilder
            .newBuilder()
            .maximumSize(1000000)
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .recordStats()
            .build(new CacheLoader<String, List<String>>() {
                @Override
                public List<String> load(String key) {
                    List<String> cids = Lists.newArrayList();
                    String cidInfo = getCidInfoFromDB(key);
                    if (cidInfo != null) {
                        String[] parts = cidInfo.split(",");
                        for (String part : parts) {
                            cids.add(part.split(":")[0]);
                        }
                    }
                    return cids;
                }
            });

    private static MorphuesClient mc = MorphuesClient.getInstance(ExploreExploitConfig.defaultConfig().getUserClusterName());

    public static Userid2CidDao defaultDAO() {
        if (instance == null) {
            synchronized (Userid2CidDao.class) {
                if (instance == null) {
                    instance = new Userid2CidDao();
                }
            }
        }
        return instance;
    }

    private Userid2CidDao() {

    }

    public List<String> getCidLst(String uid) {
        List<String> ret = Lists.newArrayList();
        try {
            ret = cache.get(uid);
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        return ret;
    }

    private String getCidInfoFromDB(String uid) {
        byte[] data = mc.read(uid, ExploreExploitConfig.defaultConfig().getUserClusterColumn());
        if (data.length == 0) {
            return null;
        }
        return new String(data);
    }

    private String getCidInfoFromMorpheus(String uid) {
        byte[] new_cid = mc.read(uid, ExploreExploitConfig.defaultConfig().getUserClusterColumn());
        byte[] old_cid = mc.read(uid, "a");

        if (new_cid.length == 0 && old_cid.length == 0) {
            return null;
        }

        String newCid = new String(new_cid);  // if new_cid.length is 0 then newCid is ""
        String oldCid = new String(old_cid);

        if (new_cid.length == 0) {
            newCid = "c#:1,c#:2";
        }
        if (old_cid.length == 0) {
            oldCid = "c#:1,c#:2";
        }

        return newCid + "," + oldCid;
    }

    public static void main(String[] args) {
        byte[] cid = new byte[0];
        System.out.println(cid.length);
        System.out.println(new String(cid));
        List<String> ret = Userid2CidDao.defaultDAO().getCidLst("280688691");
        System.out.println(ret);
    }
}
