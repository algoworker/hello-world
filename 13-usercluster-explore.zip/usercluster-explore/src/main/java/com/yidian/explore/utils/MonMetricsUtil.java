package com.yidian.explore.utils;

import com.yidian.explore.constant.MetricsNameEnum;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.common.Tag;
import com.yidian.serving.index.metrics.util.Watch;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by fanxuehui on 18/12/27.
 */
@Slf4j
public class MonMetricsUtil {
    public static final String TAGNAME_APPID = "appid";

    public enum MetricsPrefixEnum {
        /**
         * 公共逻辑的metric前缀,公共逻辑的前缀内容为null即无前缀
         */
        COMMON(null),
        KAFKA_VIDEO_COLLECT("kafkaVideoCollect"),
        M2N_EXPLORE("model2newsVideoExplore"),
        UC_EXPLORE("userclusterVideoExplore"),
        EXPLORE_FEEDBACK_RECOVERY("exploreFeedbackRecovery"),
        MCN_VIEW_ASSURANCE("mcnViewsAssurance"),
        DOUYIN_VIEW_ASSURANCE("douyinViewsAssurance"),
        UGC_VIEW_ASSURANCE("ugcViewsAssurance"),
        MOMO_VIEW_ASSURANCE("momoViewsAssurance");

        //前缀内容字符串
        private String prefixStr;

        MetricsPrefixEnum(String prefixStr) {
            this.prefixStr = prefixStr;
        }

        public String getPrefixStr() {
            return prefixStr;
        }
    }

    public static void latency(MetricsPrefixEnum prefixEnum, MetricsNameEnum latencyName, long latencyValue) {
        Metrics.simple(prefixEnum.getPrefixStr()).latency(latencyName.name(), latencyValue);
    }

    public static void latency(MetricsPrefixEnum prefixEnum, MetricsNameEnum latencyName, Watch latencyValue) {
        Metrics.simple(prefixEnum.getPrefixStr()).latency(latencyName.name(), latencyValue);
    }

    public static void qps(MetricsPrefixEnum prefixEnum, MetricsNameEnum qpsName) {
        Metrics.simple(prefixEnum.getPrefixStr()).qps(qpsName.name());
    }

    public static void qpsWithAppid(MetricsPrefixEnum prefixEnum, MetricsNameEnum qpsName, String appid) {
        Metrics.tag(prefixEnum.getPrefixStr(), Tag.newTag(TAGNAME_APPID, appid)).qps(qpsName.name());
    }

    public static void mean(MetricsPrefixEnum prefixEnum, MetricsNameEnum countName, long countValue) {
        Metrics.simple(prefixEnum.getPrefixStr()).mean(countName.name(), countValue);
    }

    public static void ratio(MetricsPrefixEnum prefixEnum, MetricsNameEnum ratioName, boolean ratioYes) {
        Metrics.simple(prefixEnum.getPrefixStr()).ratio(ratioName.name(), ratioYes);
    }

    public static void ratioWithAppid(MetricsPrefixEnum prefixEnum, MetricsNameEnum ratioName, boolean ratioYes, String appid) {
        Metrics.tag(prefixEnum.getPrefixStr(), Tag.newTag(TAGNAME_APPID, appid)).ratio(ratioName.name(), ratioYes);
    }

    public static void count(MetricsPrefixEnum prefixEnum, MetricsNameEnum countName, long countValue) {
        Metrics.simple(prefixEnum.getPrefixStr()).count(countName.name(), countValue);
    }
}
