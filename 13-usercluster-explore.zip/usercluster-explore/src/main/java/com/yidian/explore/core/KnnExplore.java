package com.yidian.explore.core;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hipu.util.Delegator;
import com.hipu.util.JacksonUtil;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.dao.UserVectorDao;
import com.yidian.explore.utils.KnnParam;
import com.yidian.explore.utils.KnnParameterUtil;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.type.TypeReference;
import yidian.data.usercf.UserVector;
import yidian.data.usercf.UserVectorTags;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Log4j
public class KnnExplore {
    private static String url = "http://knn-test.ha.in.yidian.com:9000/knn/search";
    private static Delegator delegator = new Delegator(500);

    /**
     * 获取user向量,并从knn召回相似文章
     */
    public List<MIPSEntry> retrieve(String userid, int clickNumThreshold) {
        KnnParam knnParam = KnnParameterUtil.getInstance().getKnnParam(Constants.USER2EXPLOREVIDEO_ONLINE);
        UserVector userVector = UserVectorDao.getInstance().getUserVector(userid, knnParam.usercfColumn);

        List<MIPSEntry> result = new ArrayList<>();
        if (userVector != null) {
            // 抽取训练模型的标签,包括点击数目/训练版本号
            UserVectorTags tags = userVector.getVectags();
            if (tags == null) {
                return result;
            }
            int clickNum = tags.getClickNum();
            if (clickNum < clickNumThreshold) {
                return result;
            }
            Integer vectorVersion = Integer.parseInt(tags.getVersion());
            // 如果存在当前版本的模型
            if (vectorVersion.equals(knnParam.usercfVersion)) {
                List<Float> vec = userVector.getVecsList();
                // 从knn 召回相似文章
                try {
                    return retrieve(vec, knnParam);
                } catch (IOException e) {
                    log.error("Retrieve knn video for " + userid + " exception:", e);
                }
            }
        }
        return result;
    }

    /**
     * knn 召回相似文章
     * @param vec
     * @param knnParam
     * @throws IOException
     */
    private List<MIPSEntry> retrieve(List<Float> vec, KnnParam knnParam) throws IOException {
        List<MIPSEntry> lst = Lists.newArrayList();

        StringBuilder vecStr = new StringBuilder();
        for (float ele : vec) {
            vecStr.append(ele).append(" ");
        }

        Map<String, Object> params = Maps.newHashMap();
        params.put("top", 300);
        params.put("type", Constants.USER2EXPLOREVIDEO);
        params.put("column", knnParam.column);
        params.put("byPassCache", true);
        params.put("vector", vecStr.substring(0, vecStr.length() - 1));
        String data = delegator.post(url, params);
        try {
            if (!Strings.isNullOrEmpty(data) && data.contains("success")) {
                JsonNode node = JacksonUtil.getJsonObject(data);
                lst = JacksonUtil.getMappedObject(node.get("result"), new TypeReference<List<MIPSEntry>>() {
                });
            }
        } catch (Exception e) {
            log.error("Parse Json data expection:", e);
        }
        return lst.stream().filter(o -> o.distance > 0).collect(Collectors.toList());
    }

    public static void main(String[] args) {
        KnnExplore knnExplore = new KnnExplore();
        List<MIPSEntry> ret = knnExplore.retrieve("-99999981", 0);
        System.out.println(ret);
        System.out.println(ret.size());
        System.exit(0);
    }
}
