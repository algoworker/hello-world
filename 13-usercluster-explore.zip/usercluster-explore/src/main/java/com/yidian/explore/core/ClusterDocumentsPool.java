package com.yidian.explore.core;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.google.common.cache.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yidian.explore.constant.*;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.serving.index.docfeature.core.common.data.Scope;
import com.yidian.serving.index.docfeature.core.data.ClickFeedbacks;
import com.yidian.serving.index.metrics.Metrics;
import lombok.Data;
import lombok.extern.log4j.Log4j;
import org.apache.commons.lang3.tuple.Pair;
import org.codehaus.jackson.JsonNode;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.yidian.explore.cache.*;
import com.yidian.explore.utils.*;
import com.yidian.explore.utils.MonMetricsUtil.*;
import com.yidian.explore.compare_key.CompareKey;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.dao.MongoDao;
import com.yidian.explore.ranker.VideoRerankPerUser;
import com.yidian.explore.timer.FrameVectorEmbedTimer;
import yidian.data.neo.EventType;

@Log4j
@Data
public class ClusterDocumentsPool implements DocumentsPool {
    private String cid;
    private volatile long clicks = 0;
    private volatile long views = 0;
    private volatile Map<String, DocumentInfo> documentInfoMap = Maps.newConcurrentMap();
    private volatile ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private volatile LoadingCache<String, List<DocumentInfo>> fetchCache = CacheBuilder.newBuilder()
            .maximumSize(ExploreExploitConfig.defaultConfig().getExploreClusterCacheSize())
            .expireAfterWrite(ExploreExploitConfig.defaultConfig().getExploreClusterCacheExpireSecs(), TimeUnit.SECONDS)
            .recordStats()
            .build(new CacheLoader<String, List<DocumentInfo>>() {
                @Override
                public List<DocumentInfo> load(String key) throws Exception {
                    try {
                        int topN = Integer.parseInt(key);
                        return processFetch(topN);
                    } catch (NumberFormatException e) {
                        log.error("Process Fetch From Cache Error:", e);
                    }
                    return processFetch(300);
                }
            });

    private static final String EXPIRE_START_INFO = "Start to expire {0} videos for cluster {1} at {2}";
    private static final String CONF_ENV_INFO = "Current reference.conf env is {0}";
    private static final String CONSUME_LOG = "[consume] uid: {0} cid: {1} docid: {2} event: {3}";

    private static Set<String> clusterPools = new HashSet<>();

    static {
        clusterPools.add(Constants.MCN);
        clusterPools.add(Constants.UGC);
        clusterPools.add(Constants.DOUYIN);
        clusterPools.add(Constants.MOMO);
    }

    public ClusterDocumentsPool() {

    }

    public ClusterDocumentsPool(String cid) {
        this.cid = cid;
    }

    @Override
    public boolean addDocument(DocumentFeature doc) {
        readWriteLock.readLock().lock();
        try {
            int tier = doc.getTier();
            String docid = doc.getDocid();
            String source = doc.getSource();
            String titleWords = VideoEmbedding.getSegTitleWords(doc.getSeg_title());
            String refer = doc.getRefer();
            float baseScore = doc.getScore();
            Date date = new Date();
            if (doc.getDate() != null) {
                try {
                    date = simpleDateFormat.parse(doc.getDate());
                } catch (ParseException e) {
                    log.error("Transform doc date for adding document exception:", e);
                }
            }

            if (!documentInfoMap.containsKey(docid)) {
                VideoInfo pdoc = new VideoInfo(docid, titleWords, source, tier, baseScore, date, refer);
                pdoc.setMicro(((VideoFeature) doc).isMicro());
                pdoc.setPassAudit(((VideoFeature) doc).isPassAudit());
                List<DocumentInfo> dupDocuments = Lists.newArrayList();
                dupDocuments.add(pdoc);

                float[] frameVector = ImageVectorCache.getInstance().getFrameVector(docid);
                // user cluster cid warn only
                if (frameVector == null && this.cid.startsWith("c")) {
                    LogManager.COLLECT.warn(String.format("%s fetchs empty video frame vector from cache", docid));
                }

                for (DocumentInfo documentInfo : documentInfoMap.values()) {
                    String key = documentInfo.getDocid();
                    java.util.Optional<Boolean> val = KeyValueCache.defaultCache().get(key, () -> {
                        double jaccardScore = DocEmbedding.JaccardScore(titleWords, documentInfo.getTitleWords());  // only use function JaccardScore() in class DocEmbedding
                        double frameScore = VideoRerankPerUser.simScore(frameVector, documentInfo.getFrameVector());
                        // double coverScore = VideoRerankPerUser.simScore(cover_vector, documentInfo.getCoverVector());
                        if ((jaccardScore > 0.85 || frameScore > 0.975) && !clusterPools.contains(cid)) {
                            LogManager.DEDUPLICATE.info(MessageFormat.format("{0} meets similar video {1} in cluster {2} with jaccardScore={3},frameScore={4}", docid, key, cid, jaccardScore, frameScore));
                            return java.util.Optional.of(true);
                        } else {
                            return java.util.Optional.of(false);
                        }
                    });
                    if (val.isPresent() && val.get()) {
                        dupDocuments.add(documentInfo);
                    }
                }

                if (dupDocuments.size() == 1) {
                    DocumentInfo documentInfo = dupDocuments.get(0);
                    documentInfo.setViews(0);
                    documentInfo.setClicks(0);
                    documentInfo.setFrameVector(frameVector);
                    documentInfoMap.put(documentInfo.getDocid(), documentInfo);
                    return true;
                }

                Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getTier)
                        .thenComparing(DocumentInfo::getClicks)
                        .thenComparing(DocumentInfo::getViews)
                        .thenComparing(DocumentInfo::getBaseScore).reversed();
                dupDocuments.sort(comparator);

                int tviews = 0;
                int tclicks = 0;
                for (DocumentInfo documentInfo : dupDocuments) {
                    tviews += documentInfo.getViews();
                    tclicks += documentInfo.getClicks();
                    documentInfoMap.remove(documentInfo.getDocid());
                    if (Constants.MODEL2NEWS.equals(cid)) {
                        try {
                            MongoDao.getInstance().exploreRemover(documentInfo.getDocid());
                        } catch (Exception e) {
                            LogManager.DEDUPLICATE.error("Remove similar video from mongo for model2news explore exception:", e);
                        }
                    }
                }
                for (DocumentInfo documentInfo : dupDocuments.subList(1, dupDocuments.size())) {
                    LogManager.DEDUPLICATE.info("cluster " + cid + " delete dup-doc " + documentInfo.getDocid() + " and remain doc " + dupDocuments.get(0).getDocid());
                }
                DocumentInfo documentInfo = dupDocuments.get(0);
                documentInfo.setViews(tviews);
                documentInfo.setClicks(tclicks);
                documentInfo.setFrameVector(ImageVectorCache.getInstance().getFrameVector(documentInfo.getDocid()));
                documentInfoMap.put(documentInfo.getDocid(), documentInfo);

                return true;
            } else {
                if (!doc.getRefer().equals("pipline")) {
                    DocumentInfo pdoc = documentInfoMap.get(doc.getDocid());
                    pdoc.setRefer(doc.getRefer());
                    log.info("video " + doc.getDocid() + " reset refer to " + doc.getRefer() + " in pool cid: " + cid);
                } else {
                    LogManager.DEDUPLICATE.info("doc " + doc.getDocid() + " already in pool cid: " + cid);
                }
            }
        } catch (Exception e) {
            log.error("Add document " + doc.toString() + " into documentInfoMap exception:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    private void incViews(int delta) {
        synchronized (this) {
            views += delta;
        }
    }

    private void incClicks(int delta) {
        synchronized (this) {
            clicks += delta;
        }
    }

    @Override
    public boolean updateStatus(String uid, String docid, String event) {
        readWriteLock.readLock().lock();
        try {
            DocumentInfo doc = documentInfoMap.get(docid);
            if (doc == null) {
                if (Constants.MODEL2NEWS.equals(this.cid) || Constants.FEEDBACK_RECOVERY.equals(this.cid)) {
                    Metrics.simple().qps("model2newsVideoExplore_invalid_" + this.cid + "_feedback");
                }
                return false;
            }
            if (event.startsWith("play")) {
                incClicks(1);
                if (Constants.MODEL2NEWS.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreRealClick);
                    MonMetricsUtil.qps(MetricsPrefixEnum.COMMON, MetricsNameEnum.exploreRealClick);
                } else if (Constants.FEEDBACK_RECOVERY.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.EXPLORE_FEEDBACK_RECOVERY, MetricsNameEnum.exploreRealClick);
                    MonMetricsUtil.qps(MetricsPrefixEnum.COMMON, MetricsNameEnum.exploreRealClick);
                } else if (Constants.MCN.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.MCN_VIEW_ASSURANCE, MetricsNameEnum.exploreRealClick);
                } else if (Constants.UGC.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.UGC_VIEW_ASSURANCE, MetricsNameEnum.exploreRealClick);
                } else if (Constants.DOUYIN.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.DOUYIN_VIEW_ASSURANCE, MetricsNameEnum.exploreRealClick);
                } else if (Constants.MOMO.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.MOMO_VIEW_ASSURANCE, MetricsNameEnum.exploreRealClick);
                } else {
                    MonMetricsUtil.qps(MetricsPrefixEnum.UC_EXPLORE, MetricsNameEnum.exploreRealClick);
                }
            } else if ("view".equals(event)) {
                incViews(1);
                if (Constants.MODEL2NEWS.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreRealView);
                    MonMetricsUtil.qps(MetricsPrefixEnum.COMMON, MetricsNameEnum.exploreRealView);
                } else if (Constants.FEEDBACK_RECOVERY.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.EXPLORE_FEEDBACK_RECOVERY, MetricsNameEnum.exploreRealView);
                    MonMetricsUtil.qps(MetricsPrefixEnum.COMMON, MetricsNameEnum.exploreRealView);
                } else if (Constants.MCN.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.MCN_VIEW_ASSURANCE, MetricsNameEnum.exploreRealView);
                } else if (Constants.UGC.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.UGC_VIEW_ASSURANCE, MetricsNameEnum.exploreRealView);
                } else if (Constants.DOUYIN.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.DOUYIN_VIEW_ASSURANCE, MetricsNameEnum.exploreRealView);
                } else if (Constants.MOMO.equals(this.cid)) {
                    MonMetricsUtil.qps(MetricsPrefixEnum.MOMO_VIEW_ASSURANCE, MetricsNameEnum.exploreRealView);
                } else {
                    MonMetricsUtil.qps(MetricsPrefixEnum.UC_EXPLORE, MetricsNameEnum.exploreRealView);
                }
            }
            doc.incVideoEvent(event);
            if (Constants.MODEL2NEWS.equals(this.cid) || Constants.FEEDBACK_RECOVERY.equals(this.cid)) {
                Metrics.simple().qps("model2newsVideoExplore_valid_" + this.cid + "_feedback");
            }
            // 提前写入s_explore特征阻止user2video继续分发已经完成曝光需求的视频
            if (Constants.MODEL2NEWS.equals(this.cid) && doc.getViews() >= Constants.EXPLORE_TIME) {
                String exploreFeatureTime = "[" + simpleDateFormat.format(new Date()) + "] ";
                ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(doc.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "explore_beyond_views_expire");
            }
            // LogManager.FEEDBACK.info(MessageFormat.format(CONSUME_LOG, uid, cid, docid, event));
            return true;
        } catch (Exception e) {
            log.error("Update Status Error:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    /**
     * usercluster-explore clusters expire method, designed for all
     * videoExplorePool and videoExploitPool of each cluster,
     * but not fit for userclusterVideoExploitPool.
     */
    @Override
    public List<DocumentInfo> expire() {
        List<DocumentInfo> ret = Lists.newArrayList();
        ret.addAll(baseExpire());
        readWriteLock.writeLock().lock();
        try {
            long startTime = System.currentTimeMillis();
            Date now = new Date();
            LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, simpleDateFormat.format(now)));

            int poolCapacity = 5000;
            int poolSize = documentInfoMap.size();
            int minExpireDoc = (poolSize > poolCapacity) ? (poolSize - poolCapacity) : 0;

            List<Pair<String, Double>> docScore = Lists.newArrayList();
            List<Pair<String, String>> expireDocs = Lists.newArrayList();
            Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(documentInfoMap.keySet());

            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                long delt = now.getTime() - documentInfo.getDate().getTime();
                long minutes = (int) (delt / (1000 * 60));
                double dwPunish = 1.0;

                if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                    NewsDocument nd = newsDocumentMap.get(documentInfo.getDocid());
                    String newsDocumentExpire = newsDocumentExpire(nd);
                    if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "[doc feature expire] " + newsDocumentExpire));
                        continue;
                    }
                    Optional<ClickFeedbacks> cfOpt = nd.getClickFeedbacksOpt();
                    if (cfOpt.isPresent()) {
                        double click = cfOpt.get().getClickDoc().or(0.0);
                        double dwell = nd.getDwellClickRate();
                        if (click > 10 && dwell < 20) {
                            expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[feedback dwell expire] feedbackClick={0},feedbackDwell={1}", click, dwell)));
                            continue;
                        }
                        if (documentInfo.getRefer().endsWith("exploit") && minutes > Constants.SEVEN_DAYS) {  // for exploit
                            double globalCtr = cfOpt.get().getGlobalCTR().or(1.0);
                            double exploitCtr = cfOpt.get().getFidCTR("video-ucExploit").or(1.0);
                            if (exploitCtr < globalCtr && exploitCtr < 0.2) {
                                expireDocs.add(Pair.of(documentInfo.getDocid(), "exploitCtr=" + exploitCtr + ",globalCtr=" + globalCtr));
                                continue;
                            }
                            if (exploitCtr < 0.2) {
                                expireDocs.add(Pair.of(documentInfo.getDocid(), "exploitCtr=" + exploitCtr + ",exploitDays=" + ((double) minutes / Constants.ONE_DAY)));
                                continue;
                            }
                        }
                    }
                    if (documentInfo.getRefer().endsWith("exploit")) {
                        dwPunish = Math.pow(0.95, nd.getDwellClickRate() / 100);
                    }
                } else {
                    LogManager.EXPIRE.warn(String.format("cid:%s get doc failed from NewsDocumentCache docid:%s", cid, documentInfo.getDocid()));
                }

                if (!documentInfo.getRefer().equals("pipline") && !documentInfo.getRefer().endsWith("exploit")) {
                    LogManager.EXPIRE.error("docid " + documentInfo.getDocid() + " get wrong refer " + documentInfo.getRefer());
                    continue;
                }
                if (documentInfo.getRefer().endsWith("exploit")) {  // for exploit
                    try {
                        docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getBaseScore() / dwPunish));
                    } catch (Exception e) {
                        LogManager.EXPIRE.error(String.format("exploit video %s punish error: dw_punish=%s", documentInfo.getDocid(), dwPunish), e);
                        docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getBaseScore() / 1.0));
                    }
                } else {
                    docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getUCBScore(views)));
                }
            }

            int num = 0;
            Date expireTime = new Date();
            for (Pair<String, String> pair : expireDocs) {
                num += 1;
                DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                if (delDoc == null) {
                    LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                incViews(-delDoc.getViews());
                incClicks(-delDoc.getClicks());
                delDoc.setExpireTime(expireTime);
                delDoc.setExpireReason(pair.getRight());
                ret.add(delDoc);
                documentInfoMap.remove(pair.getLeft());  // 删除explore-pool中移到exploit-pool中的文章
            }
            docScore.sort(Comparator.comparingDouble(Pair::getValue));
            ret.addAll(poolSizeExpire(docScore, num, minExpireDoc));
            Metrics.simple().latency("userclusterVideoExploreExploit_expire_process", System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            log.error("User Cluster Expire Error:", e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return ret;
    }

    /**
     * <p> This method is used to expire some "ClusterDocumentsPool" exploit pools.
     * Since this method expires exploit pools only, pool size is cancelled. All exploit pools are:
     * userclusterVideoExploitPool(global exploit video of all clusters) with cid "userclusterVideoExploit",
     * model2newsMicroVideoExploitPool with cid "m2nMicroVideo".
     */
    List<DocumentInfo> clusterDocumentsExploitPoolExpire() {
        readWriteLock.writeLock().lock();
        List<DocumentInfo> ret = Lists.newArrayList();

        try {
            long startTime = System.currentTimeMillis();
            Date now = new Date();
            LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, simpleDateFormat.format(now)));

            List<Pair<String, Double>> docScore = Lists.newArrayList();
            List<Pair<String, String>> expireDocs = Lists.newArrayList();
            Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(documentInfoMap.keySet());

            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                long timeDiff = now.getTime() - documentInfo.getDate().getTime();
                long minutes = (int) (timeDiff / (1000 * 60));
                double dwPunish = 1.0;

                if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                    NewsDocument newsDocument = newsDocumentMap.get(documentInfo.getDocid());
                    String newsDocumentExpire = newsDocumentExpire(newsDocument);
                    if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), newsDocumentExpire));
                        continue;
                    }
                    if (this.cid.equals("userclusterVideoExploit")) {
                        dwPunish = Math.pow(0.95, newsDocument.getDwellClickRate() / 100);
                    }
                    if ("m2nMicroVideo".equals(this.cid)) {
                        String videoType = microvideoDefinitionExpire(newsDocument);
                        if (!Strings.isNullOrEmpty(videoType) && "normal".equals(videoType)) {
                            expireDocs.add(Pair.of(documentInfo.getDocid(), "[video type exception] video_type=normal,durtion=" + newsDocument.getDuration()));
                            continue;
                        }
                    }
                } else {
                    LogManager.EXPIRE.warn(MessageFormat.format("cluster {0} get newsDocument of {1} from NewsDocumentCache exception", cid, documentInfo.getDocid()));
                }

                // 生命期expire
                if (minutes > Constants.ONE_MONTH) {
                    expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("insertTime={0},lifeTime={1}", minutes, Constants.ONE_MONTH)));
                    continue;
                }
                // 试探ctr异常expire
                if (documentInfo.getBaseScore() > 1) {
                    expireDocs.add(Pair.of(documentInfo.getDocid(), "[exploit video baseScore exception] refer=" + documentInfo.getRefer() + ",baseScore=" + documentInfo.getBaseScore()));
                    continue;
                }
                if (this.cid.equals("userclusterVideoExploit")) {
                    docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getBaseScore() / dwPunish));
                } else if (this.cid.equals("m2nMicroVideo")) {
                    docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getPoolRankingScore()));
                }
            }

            for (Pair<String, String> pair : expireDocs) {
                DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                if (delDoc == null) {
                    LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                ret.add(delDoc);
                documentInfoMap.remove(pair.getLeft());
            }
            docScore.sort(Comparator.comparingDouble(Pair::getValue));
            Metrics.simple().latency(cid + "_exploit_expire_process", System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            log.error(MessageFormat.format("ClusterExploitPool {0} expire runtime exception:", this.cid), e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return ret;
    }

    /**
     * 根据doc feature刷新不适合曝光的文章,主要是Scope字段的动态变化
     */
    private String newsDocumentExpire(NewsDocument newsDocument) {
        if (newsDocument != null) {
            Scope scope = newsDocument.getScope();
            if (scope != null && (Scope.removed.equals(scope) || Scope.notserve.equals(scope) || Scope.notrecommend.equals(scope) || Scope.hide.equals(scope))) {
                return "scope=" + scope.name();
            }
            if (!newsDocument.getCType().equals("video")) {
                return "ctype=" + newsDocument.getCType();
            }
        }
        return null;
    }

    private String microvideoDefinitionExpire(NewsDocument newsDocument) {
        if (newsDocument != null) {
            int vWidth = newsDocument.getVideoCoverWidth();
            int vHeight = newsDocument.getVideoCoverHeight();
            return (vWidth < vHeight) ? "micro" : "normal";
        }
        return null;
    }

    /**
     * This method is designed for usercluster-explore/usercluster-exploit/model2news-explore/model2news-exploit.
     * Since usercluster-explore and usercluster-exploit are suspended, this method is used for model2news-explore/model2news-exploit only.
     *
     * <p> base expire contains:
     * 1.expire每个cluster中lifetime超时的视频,不同cluster中视频的lifetime不同,其中explore为24h/exploit为
     * 2.expire每个cluster中views满足一定条件的视频,不同cluster中视频的views需求不同
     * <p>
     * model2news-explore needs to write explore expire flag:
     * 1.s_explore=explore_lifetime_expire
     * 2.s_explore=explore_beyond_views_expire
     * 3.s_explore=explore_low_ctr_expire
     * 4.s_explore=explore_to_exploit_expire
     */
    private List<DocumentInfo> baseExpire() {
        List<DocumentInfo> baseExpireDocs = Lists.newArrayList();
        if (documentInfoMap.isEmpty()) {
            return baseExpireDocs;
        }
        readWriteLock.writeLock().lock();
        List<Pair<String, String>> expireDocs = Lists.newArrayList();
        try {
            int lifeTime = ApolloConfigUtil.getInstance().getExploreVideoLifetime();  // default lifeTime for explore video
            DocumentInfo[] documentInfoArray = documentInfoMap.values().toArray(new DocumentInfo[0]);
            DocumentInfo tempDocumentInfo = documentInfoArray[0];
            if (tempDocumentInfo.getRefer().endsWith("exploit")) {
                lifeTime = Constants.HALF_MONTH;
            }

            Date now = new Date();
            String exploreFeatureTime = "[" + simpleDateFormat.format(now) + "] ";
            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                try {
                    long diffTime = now.getTime() - documentInfo.getDate().getTime();
                    long minutes = (int) (diffTime / (1000 * 60));
                    if (minutes >= lifeTime) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[explore lifetime expire] insertTime={0},lifeTime={1}", minutes, lifeTime)));
                        if ("pipline".equals(documentInfo.getRefer())) {  // for explore
                            ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(documentInfo.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "explore_lifetime_expire");
                            MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreLifetimeExpire);
                        }
                        continue;
                    }
                    if (documentInfo.getRefer().endsWith("exploit") && documentInfo.getBaseScore() > 1) {  // for exploit
                        expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[exploit video baseScore expire] refer={0},baseScore={1}", documentInfo.getRefer(), documentInfo.getBaseScore())));
                        continue;
                    }
                    if (documentInfo.getRefer().equals("pipline")) {  // for explore
                        if (documentInfo.getViews() >= Constants.EXPLORE_TIME) {
                            expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[explore beyond views expire] refer={0},clicks={1},views={2}", documentInfo.getRefer(), documentInfo.getClicks(), documentInfo.getViews())));
                            ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(documentInfo.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "explore_beyond_views_expire");
                            MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreBeyondViewsExpire);
                            continue;
                        }
                        if (documentInfo.isExploitVideo()) {  // 好视频移入exploit池
                            expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[explore to exploit expire] clicks={0},views={1}", documentInfo.getClicks(), documentInfo.getViews())));
                            ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(documentInfo.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "explore_to_exploit_expire");
                            MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreToExploitExpire);
                            continue;
                        }
                        if (this.cid.startsWith("c") && ((documentInfo.getViews() >= 200 && 10 * documentInfo.getClicks() < documentInfo.getViews() && minutes > 20)
                                || (documentInfo.getViews() >= 50 && documentInfo.getClicks() == 0))) {  // 试探多次后无足够click停止试探(model2explore的play事件有延迟不做该expire)
                            expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[explore low ctr expire] clicks={0},views={1}", documentInfo.getClicks(), documentInfo.getViews())));
                            ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(documentInfo.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "explore_low_ctr_expire");
                            MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.exploreLowCtrExpire);
                        }
                    }
                } catch (Exception e) {
                    log.error("Expire video " + documentInfo.toString() + " exception:", e);
                }
            }

            Date expireTime = new Date();
            for (Pair<String, String> pair : expireDocs) {
                DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                if (delDoc == null) {
                    LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                incViews(-delDoc.getViews());
                incClicks(-delDoc.getClicks());
                delDoc.setExpireTime(expireTime);
                delDoc.setExpireReason(pair.getRight());
                baseExpireDocs.add(delDoc);
                documentInfoMap.remove(pair.getLeft());  // 删除explore-pool中移到exploit-pool中的文章
            }
        } catch (Exception e) {
            log.error("Cluster " + this.cid + " base expire exception:", e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return baseExpireDocs;
    }

    /**
     * 每次删除池子中的低分doc来保持池子容量
     * @param docScore:打分按降序排列的文章池
     * @param num:上一环节已经删除的doc数
     * @param minExpireDoc:最小expire数
     */
    private List<DocumentInfo> poolSizeExpire(List<Pair<String, Double>> docScore, int num, int minExpireDoc) {
        List<DocumentInfo> lowScoreDocs = Lists.newArrayList();
        if (docScore == null || docScore.isEmpty()) {
            return lowScoreDocs;
        }
        readWriteLock.writeLock().lock();
        try {
            int count = num;
            Date expireTime = new Date();
            String exploreFeatureTime = "[" + simpleDateFormat.format(expireTime) + "] ";
            for (Pair<String, Double> doc : docScore) {
                if (count >= minExpireDoc) {
                    break;
                }
                DocumentInfo delDoc = documentInfoMap.get(doc.getKey());
                if (delDoc == null) {
                    LogManager.EXPIRE.info("doc " + doc.getKey() + " removed by other thread");
                    continue;
                }
                long timeDiff = new Date().getTime() - delDoc.getDate().getTime();
                long minutes = (int) (timeDiff / (1000 * 60));
                if (minutes < 60 * 6) {
                    continue;
                }
                if (delDoc.getViews() != 0) {
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + delDoc.toString() + " reason: pool size");
                incViews(-delDoc.getViews());
                incClicks(-delDoc.getClicks());
                delDoc.setExpireTime(expireTime);
                delDoc.setExpireReason(MessageFormat.format("[pool size expire] clicks={0},views={1},expireVideoCount={2}", delDoc.getClicks(), delDoc.getViews(), minExpireDoc));
                lowScoreDocs.add(delDoc);
                ExploreExploitFeatureUtil.getInstance().updateExploreExploitFeature(delDoc.getDocid(), Constants.S_EXPLORE, exploreFeatureTime + "pool_size_expire");
                MonMetricsUtil.qps(MetricsPrefixEnum.M2N_EXPLORE, MetricsNameEnum.poolSizeExpire);
                documentInfoMap.remove(doc.getKey());
                count += 1;
            }
        } catch (Exception e) {
            log.error("Cluster " + this.cid + " pool size expire exception:", e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return lowScoreDocs;
    }

    /**
     * 筛选出入库1天后需要扩大分发的视频
     * @return 需要扩大分发的视频list value表示需要扩大分发的总views数
     */
    List<VideoInfo> allInVideoPoolExpire() {
        readWriteLock.writeLock().lock();
        List<VideoInfo> result = Lists.newArrayList();

        try {
            long startTime = System.currentTimeMillis();
            Date now = new Date();
            String currentDate = simpleDateFormat.format(now);
            LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, currentDate));

            Set<String> expireDocumentInfoSet = new HashSet<>();
            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                long timeDiff = now.getTime() - documentInfo.getDate().getTime();
                long minutes = (int) (timeDiff / (1000 * 60));
                // 入库时间少于12h不处理
                if (minutes < Constants.HALF_DAY) {
                    continue;
                }
                expireDocumentInfoSet.add(documentInfo.getDocid());
            }
            Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(expireDocumentInfoSet);

            List<Pair<String, String>> expireDocs = Lists.newArrayList();
            Map<String, VideoInfo> boostViewVideo = new HashMap<>();
            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                String docid = documentInfo.getDocid();
                if (!expireDocumentInfoSet.contains(docid)) {
                    continue;
                }
                if (newsDocumentMap.containsKey(docid)) {
                    NewsDocument newsDocument = newsDocumentMap.get(docid);
                    // scope and ctype expire
                    String newsDocumentExpire = newsDocumentExpire(newsDocument);
                    if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), newsDocumentExpire));
                        continue;
                    }
                    // cfb misssing expire
                    Optional<ClickFeedbacks> cfb = newsDocument.getClickFeedbacksOpt();
                    if (!cfb.isPresent()) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "cfb missing"));
                        continue;
                    }
                    // boost view expire
                    double globalCtr = cfb.get().getGlobalCTR().or(0.0);
                    double globalView = newsDocument.getGlobalView();
                    double dwell = newsDocument.getDwellClickRate();
                    if (VideoInfo.isBoostViewVideo(globalCtr, globalView, dwell)) {
                        // 满足扩大分发的视频baseScore设置后不再修改
                        documentInfo.setBaseScore((float) globalCtr);
                        documentInfo.setRankScore(globalCtr);
                        documentInfo.setViews((int) globalView);
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "need boosting view"));
                        if (documentInfo instanceof VideoInfo) {
                            VideoInfo videoInfo = (VideoInfo) documentInfo;
                            videoInfo.initBoostVideoInfoFields(videoInfo, globalCtr, globalView);
                            boostViewVideo.put(docid, videoInfo);
                        }
                    } else {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "lifetime more than 24h"));
                    }
                } else {
                    LogManager.EXPIRE.warn(MessageFormat.format("cluster {0} get newsDocument of {1} from NewsDocumentCache exception", cid, documentInfo.getDocid()));
                    // newsDocument missing expire
                    expireDocs.add(Pair.of(documentInfo.getDocid(), "newsDocument missing"));
                }
            }

            for (Pair<String, String> pair : expireDocs) {
                String docid = pair.getLeft();
                DocumentInfo expireDoc = documentInfoMap.get(docid);
                if (expireDoc == null) {
                    LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + expireDoc.toString() + " reason: " + pair.getRight());
                // 如果boostViewVideo不包含docid,boostViewVideo.get(docid)将返回null
                if (Objects.equals(pair.getRight(), "need boosting view") && boostViewVideo.containsKey(docid)) {
                    result.add(boostViewVideo.get(docid));
                    // log.info("VideoPool " + Constants.ALLIN + " throws " + expireDoc.toString() + " into " + Constants.BOOST_VIEW);
                }
                documentInfoMap.remove(docid);
            }
            Metrics.simple().latency("allInVideoPool_expire_process", System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            log.error(MessageFormat.format("ClusterExploitPool {0} expire runtime exception:", this.cid), e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return result;
    }

    /**
     * boostViewVideoExploitPool expire
     * @version 保持boostViewVideoExploitPool的最新状态
     */
    void boostViewVideoExploitPoolExpire() {
        readWriteLock.writeLock().lock();

        try {
            long startTime = System.currentTimeMillis();
            Date now = new Date();
            String currentDate = simpleDateFormat.format(now);
            LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, currentDate));

            // 当前时间段对应的曝光占比
            int currentHour = Integer.parseInt(currentDate.substring(11, 13));
            double currentViewCoefficient = DauDistribution.getOppobrowserDauDistribution().get(currentHour);

            List<Pair<String, String>> expireDocs = Lists.newArrayList();
            Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(documentInfoMap.keySet());

            int newsDocumentExpireCnt = 0;
            int cfbMissingExpireCnt = 0;
            int ctrFallingExpireCnt = 0;
            int lowWeekCtrExpireCnt = 0;
            int lowFactorCtrExpireCnt = 0;
            int newsDocumentMissingExpireCnt = 0;
            int lifeTimeExpireCnt = 0;

            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                long timeDiff = now.getTime() - documentInfo.getDate().getTime();
                long minutes = (int) (timeDiff / (1000 * 60));
                // 生命期expire 15天生命期
                if (minutes > Constants.HALF_MONTH) {
                    expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("insertTime={0},lifeTime={1}", minutes, Constants.HALF_MONTH)));
                    lifeTimeExpireCnt += 1;
                    continue;
                }

                if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                    NewsDocument newsDocument = newsDocumentMap.get(documentInfo.getDocid());
                    // scope and ctype expire
                    String newsDocumentExpire = newsDocumentExpire(newsDocument);
                    if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), newsDocumentExpire));
                        newsDocumentExpireCnt += 1;
                        continue;
                    }
                    // cfb misssing expire
                    Optional<ClickFeedbacks> cfb = newsDocument.getClickFeedbacksOpt();
                    if (!cfb.isPresent()) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "cfb missing"));
                        cfbMissingExpireCnt += 1;
                        continue;
                    }
                    // globalCtr falling expire
                    double globalCtr = cfb.get().getGlobalCTR().or(0.0);
                    documentInfo.setRankScore(globalCtr);
                    if (globalCtr < Constants.G_CTR_TH - 0.05) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "globalCtr falling:" + (documentInfo.getBaseScore() - globalCtr)));
                        ctrFallingExpireCnt += 1;
                        continue;
                    }
                    // low globalCtr after 15 days expire
                    if (globalCtr < 0.3 && minutes > Constants.SEVEN_DAYS) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "low globalCtr after 7 days:" + globalCtr));
                        lowWeekCtrExpireCnt += 1;
                        continue;
                    }
                    // 根据实际分发情况动态调整每个视频的分发系数和扩大分发数
                    if (documentInfo instanceof VideoInfo) {
                        VideoInfo videoInfo = (VideoInfo) documentInfo;
                        if (videoInfo.isNewBoostVideo()) {
                            videoInfo.setNewBoostVideo(false);
                            continue;
                        }
                        String vfactor = Constants.ECOLOGY;
                        double coefficient = videoInfo.getPlannedHourViewCoefficient();
                        double globalView = newsDocument.getGlobalView();
                        videoInfo.setLastGlobalView(globalView);
                        // factor real cfb expire
                        if (cfb.get().getFid().containsKey(vfactor)) {
                            // video-m2nEcology已经分发出该视频
                            double factorCtr = cfb.get().getFidCTR(vfactor).or(1.0);
                            if (cfb.get().getFid().get(vfactor).getOpt(EventType.RViewDoc).isPresent()) {
                                double factorRView = cfb.get().getFid().get(vfactor).get(EventType.RViewDoc);
                                if (factorRView > 100 && factorCtr < 0.15) {
                                    expireDocs.add(Pair.of(documentInfo.getDocid(), "low factor ctr:" + factorCtr + ",factor view:" + factorRView));
                                    lowFactorCtrExpireCnt += 1;
                                    continue;
                                }
                            }
                        } else {
                            // video-m2nEcology尚未分发出该视频,调整分发系数
                            coefficient = timeDiff / (1000D * 60 * 60 * 24);
                            videoInfo.setPlannedHourViewCoefficient(coefficient);
                            videoInfo.setPlannedHourBoostView(videoInfo.getTotalBoostView() * coefficient);
                            continue;
                        }

                        double lastHourView = globalView - videoInfo.getLastGlobalView();
                        if (lastHourView > 0) {
                            // 上一小时有分发,ctr上升则扩大分发,ctr下降则减少分发
                            if (globalCtr > documentInfo.getRankScore()) {
                                coefficient = (coefficient < 8) ? coefficient * 2 : 8D;
                            } else {
                                coefficient = (coefficient > 1) ? coefficient / 2 : 1D;
                            }
                        } else {
                            // 上一小时无分发,扩大分发
                            coefficient = (coefficient < 8) ? coefficient * 2 : 8D;
                        }
                        videoInfo.setPlannedHourViewCoefficient(coefficient);
                        videoInfo.setPlannedHourBoostView(videoInfo.getTotalBoostView() * coefficient);
                    }
                } else {
                    LogManager.EXPIRE.warn(MessageFormat.format("cluster {0} get newsDocument of {1} from NewsDocumentCache exception", cid, documentInfo.getDocid()));
                    // newsDocument missing expire
                    expireDocs.add(Pair.of(documentInfo.getDocid(), "newsDocument missing"));
                    newsDocumentMissingExpireCnt += 1;
                }
            }

            for (Pair<String, String> pair : expireDocs) {
                DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                if (delDoc == null) {
                    LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                    continue;
                }
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                documentInfoMap.remove(pair.getLeft());
            }
            LogManager.EXPIRE.warn(MessageFormat.format("boostViewVideoExploitPool expire info: newsDocumentExpireCnt={0},cfbMissingExpireCnt={1},ctrFallingExpireCnt={2},lowWeekCtrExpireCnt={3},lowFactorCtrExpireCnt={4},newsDocumentMissingExpireCnt={5},lifeTimeExpireCnt={6}",
                    newsDocumentExpireCnt, cfbMissingExpireCnt, ctrFallingExpireCnt, lowWeekCtrExpireCnt, lowFactorCtrExpireCnt, newsDocumentMissingExpireCnt, lifeTimeExpireCnt));
            Metrics.simple().latency("boostViewVideoExploitPool_expire_process", System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            log.error(MessageFormat.format("ClusterExploitPool {0} expire runtime exception:", this.cid), e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
    }

    @Override
    public List<DocumentInfo> fetch(int topn) {
        if (ExploreExploitConfig.defaultConfig().isExploreClusterCacheEnable()) {
            try {
                return fetchCache.get(String.valueOf(topn));
            } catch (ExecutionException e) {
                log.error("Get explore result from fetchCache failed of cid:" + cid + " topn:" + topn, e);
            }
            return Lists.newArrayList();
        } else {
            return processFetch(topn);
        }
    }

    public List<DocumentInfo> processFetch(int topn) {
        List<DocumentInfo> ret = Lists.newArrayList();
        List<Pair<DocumentInfo, Double>> lst = Lists.newArrayList();
        for (DocumentInfo doc : documentInfoMap.values()) {
            DocumentInfo ndoc = (DocumentInfo) doc.clone();
            lst.add(Pair.of(ndoc, ndoc.getUCBScore(views)));
        }
        lst.sort(Comparator.comparingDouble(d -> -d.getRight()));
        for (Pair<DocumentInfo, Double> pair : lst) {
            ret.add(pair.getLeft());
        }
        return ret.subList(0, Math.min(topn, ret.size()));
    }

    public List<DocumentInfo> exploitFetch(int topn) {
        List<DocumentInfo> ret = Lists.newArrayList();
        List<String> docids = Lists.newArrayList();
        docids.addAll(documentInfoMap.keySet());
        Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(docids);
        List<Pair<DocumentInfo, Double>> lst = Lists.newArrayList();
        for (DocumentInfo doc : documentInfoMap.values()) {
            NewsDocument nd = newsDocumentMap.get(doc.getDocid());
            if (nd == null) {
                continue;
            }
            double dwell = nd.getDwellClickRate();
            if (Math.abs(dwell) < 0.000001 || dwell < 0.0) {
                continue;
            }
            double dw_punish = 1 / (1 + Math.exp((dwell - 100) * 0.01)) + 0.73;
            double rankScore = doc.getBaseScore() / dw_punish;
            lst.add(Pair.of(doc, rankScore));
        }
        lst.sort(Comparator.comparingDouble(d -> -d.getRight()));
        for (Pair<DocumentInfo, Double> pair : lst) {
            ret.add(pair.getLeft());
        }
        return ret.subList(0, Math.min(topn, ret.size()));
    }

    @Override
    public List<DocumentInfo> fetch(int topn, CompareKey ck) {
        if (ck == null) {
            return fetch(topn);
        }
        List<DocumentInfo> ret = Lists.newArrayList();
        List<Pair<DocumentInfo, Double>> lst = Lists.newArrayList();
        for (DocumentInfo doc : documentInfoMap.values()) {
            lst.add(Pair.of(doc, ck.getCompareKey(doc).doubleValue()));
        }
        lst.sort(Comparator.comparingDouble(Pair::getRight));
        for (Pair<DocumentInfo, Double> pair : lst) {
            ret.add(pair.getLeft());
        }
        return ret.subList(0, Math.min(topn, ret.size()));
    }

    @Override
    public boolean contain(String docid) {
        return documentInfoMap.containsKey(docid);
    }

    @Override
    public boolean addDocumentInfo(DocumentInfo documentInfo) {
        readWriteLock.readLock().lock();
        try {
            String docid = documentInfo.getDocid();
            if (documentInfoMap.containsKey(docid)) {
                float score = documentInfo.getBaseScore();
                DocumentInfo doc = documentInfoMap.get(docid);
                if (doc != null && doc.getBaseScore() < score) {
                    doc.setBaseScore(score);
                }
                return true;
            }
            documentInfoMap.put(documentInfo.getDocid(), documentInfo);
            incViews(documentInfo.getViews());
            incClicks(documentInfo.getClicks());
        } catch (Exception e) {
            log.error("Add Document Info Error:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public DocumentInfo removeDocumentInfo(String docid) {
        readWriteLock.readLock().lock();
        try {
            DocumentInfo documentInfo = documentInfoMap.get(docid);
            if (documentInfo == null) {
                return null;
            }
            incViews(-documentInfo.getViews());
            incClicks(-documentInfo.getClicks());
            documentInfoMap.remove(docid);
            return documentInfo;
        } catch (Exception e) {
            log.error("Remove Document Info Error:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return null;
    }

    @Override
    public boolean deserialize(JsonNode root) {
        if (root.has("views")) {
            views = root.get("views").asLong(0);
        }
        if (root.has("clicks")) {
            clicks = root.get("clicks").asLong(0);
        }
        if (root.has("cid")) {
            cid = root.get("cid").asText();
        }
        if (root.has("documentInfoMap")) {
            JsonNode documentInfoMapNode = root.get("documentInfoMap");
            Iterator<String> fieldNames = documentInfoMapNode.getFieldNames();
            while (fieldNames.hasNext()) {
                String docid = fieldNames.next();
                JsonNode documentInfoNode = documentInfoMapNode.get(docid);
                VideoInfo documentInfo = new VideoInfo();
                if (Constants.BOOST_VIEW.equals(cid)) {
                    documentInfo.boostViewVideoDeserialize(documentInfoNode);
                } else {
                    documentInfo.deserialize(documentInfoNode);
                }
                documentInfoMap.put(docid, documentInfo);
            }
        }
        return true;
    }

    @Override
    public Map<String, Object> serialize() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        ret.put("views", views);
        ret.put("clicks", clicks);
        ret.put("cid", cid);
        Map<String, Object> documentInfoMapInfo = Maps.newLinkedHashMap();
        for (Map.Entry<String, DocumentInfo> entry : documentInfoMap.entrySet()) {
            // 单独处理需要扩大分发的视频的两个cid
            if (Constants.ALLIN.equals(cid)) {
                if (entry.getValue() instanceof VideoInfo) {
                    documentInfoMapInfo.put(entry.getKey(), ((VideoInfo) entry.getValue()).allInVideoSerialize());
                }
            } else if (Constants.BOOST_VIEW.equals(cid)) {
                if (entry.getValue() instanceof VideoInfo) {
                    documentInfoMapInfo.put(entry.getKey(), ((VideoInfo) entry.getValue()).boostViewVideoSerialize());
                }
            } else {
                documentInfoMapInfo.put(entry.getKey(), entry.getValue().serialize());
            }
        }
        ret.put("documentInfoMap", documentInfoMapInfo);
        return ret;
    }

    @Override
    public Map<String, Object> getDebugInfo(int topn, CompareKey ck) {
        List<DocumentInfo> fetchResult = fetch(topn, ck);
        Map<String, Object> ret = Maps.newLinkedHashMap();
        ret.put("cid", cid);
        ret.put("getCacheStats", cacheStats());
        ret.put("exploreTimes", views);
        ret.put("clickTimes", clicks);
        ret.put("docSize", documentInfoMap.size());
        List<Map<String, Object>> lst = Lists.newArrayList();
        for (DocumentInfo documentInfo : fetchResult) {
            if (documentInfo == null) {
                continue;
            }
            Map<String, Object> debugInfo = documentInfo.getDebugInfo(views);
            lst.add(debugInfo);
        }
        ret.put("docs", lst);
        return ret;
    }

    private Map<String, Object> cacheStats() {
        CacheStats stats = fetchCache.stats();
        Map<String, Object> result = Maps.newHashMap();
        result.put("fetchCacheStats", stats.toString());
        result.put("avgLoadPenalty", stats.averageLoadPenalty());
        result.put("hitRate", stats.hitRate());
        result.put("missRate", stats.missRate());
        result.put("size", fetchCache.size());
        return result;
    }

    @Override
    public boolean embedFrameVector() {
        readWriteLock.readLock().lock();
        try {
            if (documentInfoMap == null || documentInfoMap.isEmpty()) {
                return false;
            }
            log.info("Embed frame vector for cluster " + cid + " at " + new Date().toString());
            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                if (documentInfo.getFrameVector() == null) {
                    java.util.Optional<float[]> vec = FrameVectorEmbedTimer.documentInfoFrameVectorCache.get(documentInfo.getDocid());
                    if (vec.isPresent()) {
                        float[] frame_vector = vec.get();
                        documentInfo.setFrameVector(frame_vector);
                    }
                }
            }
            return true;
        } catch (Exception e) {
            log.error("Embed Frame Vector For Cluster " + cid + " Error:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public List<DocumentInfo> model2newsExpire() {
        List<DocumentInfo> ret = Lists.newArrayList();
        readWriteLock.writeLock().lock();
        try {
            if (Constants.MODEL2NEWS.equals(this.cid)) {
                ret.addAll(baseExpire());
                long startTime = System.currentTimeMillis();
                Date now = new Date();
                LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, simpleDateFormat.format(now)));

                int poolCapacity = ApolloConfigUtil.getInstance().getModel2explorePoolCapacity();
                int poolSize = documentInfoMap.size();
                int minExpireDoc = (poolSize > poolCapacity) ? (poolSize - poolCapacity) : 0;

                List<Pair<String, Double>> docScore = Lists.newArrayList();
                List<Pair<String, String>> expireDocs = Lists.newArrayList();
                Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(documentInfoMap.keySet());

                for (DocumentInfo documentInfo : documentInfoMap.values()) {
                    double dwPunish = 1.0;
                    if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                        NewsDocument nd = newsDocumentMap.get(documentInfo.getDocid());
                        String newsDocumentExpire = newsDocumentExpire(nd);
                        if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                            expireDocs.add(Pair.of(documentInfo.getDocid(), "[doc feature expire] " + newsDocumentExpire));
                            continue;
                        }
                        Optional<ClickFeedbacks> cfOpt = nd.getClickFeedbacksOpt();
                        if (cfOpt.isPresent()) {
                            double click = cfOpt.get().getClickDoc().or(0.0);
                            double dwell = nd.getDwellClickRate();
                            if (click > 20 && dwell < 20 && !documentInfo.isMicro()) {
                                expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[feedback dwell expire] feedbackClick={0},feedbackDwell={1}", click, dwell)));
                                continue;
                            }
                            if (documentInfo.getRefer().equals("pipline")) {
                                double view = cfOpt.get().getRViewDoc().or(0.0);
                                if (view > 5000) {
                                    expireDocs.add(Pair.of(documentInfo.getDocid(), "[feedback view expire] feedbackView=" + view));
                                    continue;
                                }
                            }
                        }
                        if (documentInfo.getRefer().endsWith("exploit")) {
                            dwPunish = Math.pow(0.95, nd.getDwellClickRate() / 100);
                        }
                    } else {
                        LogManager.EXPIRE.warn("model2news expire get doc failed from NewsDocumentCache docid: " + documentInfo.getDocid());
                    }

                    if (!documentInfo.getRefer().equals("pipline") && !documentInfo.getRefer().endsWith("exploit")) {
                        LogManager.EXPIRE.error("docid " + documentInfo.getDocid() + " get wrong refer " + documentInfo.getRefer());
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "referError=" + documentInfo.getRefer()));
                        continue;
                    }
                    if (documentInfo.getRefer().endsWith("exploit")) {
                        try {
                            docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getBaseScore() / dwPunish));
                        } catch (Exception e) {
                            log.error(String.format("exploit video %s punish error: dw_punish=%s", documentInfo.getDocid(), dwPunish), e);
                            docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getBaseScore() / 1.0));
                        }
                    } else {
                        documentInfo.setBaseScore(documentInfo.getViews() != 0 ? ((float) documentInfo.getClicks() / documentInfo.getViews()) : 0);
                        docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getUCBScore(views)));
                    }
                }

                int num = 0;
                Date expireTime = new Date();
                for (Pair<String, String> pair : expireDocs) {
                    num += 1;
                    DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                    if (delDoc == null) {
                        LogManager.EXPIRE.info("doc " + pair.getLeft() + " removed by other thread");
                        continue;
                    }
                    LogManager.EXPIRE.info("cluster model2news removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                    incViews(-delDoc.getViews());
                    incClicks(-delDoc.getClicks());
                    delDoc.setExpireTime(expireTime);
                    delDoc.setExpireReason(pair.getRight());
                    ret.add(delDoc);
                    documentInfoMap.remove(pair.getLeft());
                }
                docScore.sort(Comparator.comparingDouble(Pair::getValue));
                ret.addAll(poolSizeExpire(docScore, num, minExpireDoc));
                LogManager.EXPIRE.info("cid:" + this.cid + " expire " + ret.size() + " explore video in model2newsExploreVideoPool at " + new Date().toString());
                Metrics.simple().latency("model2newsVideoExploreExploit_expire_process", System.currentTimeMillis() - startTime);
            } else if (Constants.FEEDBACK_RECOVERY.equals(this.cid)) {
                Date now = new Date();
                LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, simpleDateFormat.format(now)));
                List<Pair<String, String>> expireDocs = Lists.newArrayList();
                int feedbackRecoveryDelay = ApolloConfigUtil.getInstance().getExploreFeedbackRecoveryDelay();
                for (DocumentInfo documentInfo : documentInfoMap.values()) {
                    documentInfo.setBaseScore(documentInfo.getViews() != 0 ? ((float) documentInfo.getClicks() / documentInfo.getViews()) : 0);
                    try {
                        long diffTime = now.getTime() - documentInfo.getExpireTime().getTime();
                        long minutes = (int) (diffTime / (1000 * 60));
                        if (minutes >= feedbackRecoveryDelay) {
                            expireDocs.add(Pair.of(documentInfo.getDocid(), MessageFormat.format("[feedback recovery expire] expireTime={0},currentTime={1}", documentInfo.getExpireTime(), now)));
                        }
                    } catch (Exception e) {
                        log.error("Expire video " + documentInfo.toString() + " exception:", e);
                    }
                }
                for (Pair<String, String> pair : expireDocs) {
                    DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                    if (delDoc == null) {
                        continue;
                    }
                    LogManager.EXPIRE.info("cluster feedbackRecovery removed doc " + delDoc.toString() + " reason: " + pair.getRight());
                    incClicks(-delDoc.getClicks());
                    incViews(-delDoc.getViews());
                    ret.add(delDoc);
                    documentInfoMap.remove(pair.getLeft());
                }
                LogManager.EXPIRE.info("cid:" + this.cid + " expire " + ret.size() + " feedback recovery video in model2newsExploreVideoPool at " + new Date().toString());
            }
        } catch (Exception e) {
            log.error("Model2news Expire Error:", e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return ret;
    }

    @Override
    public Map<String, DocumentInfo> getClusterDocumentInfos() {
        if (this.documentInfoMap.size() != 0) {
            return this.documentInfoMap;
        }
        return Maps.newConcurrentMap();
    }

    /**
     * 有曝光需求的视频试探:为一些视频提供足够的曝光,不设置pool size
     * 需求列表:
     * 1.mcn源 2.ugc小视频 3.douyin百万粉丝一点号 4.陌陌4个源
     */
    public List<DocumentInfo> viewsAssuranceExploreExpire() {
        readWriteLock.writeLock().lock();
        List<DocumentInfo> ret = Lists.newArrayList();

        try {
            long startTime = System.currentTimeMillis();
            LogManager.EXPIRE.info(MessageFormat.format(EXPIRE_START_INFO, this.documentInfoMap.size(), this.cid, simpleDateFormat.format(new Date())));

            int viewsUpperLimit = getViewAssuranceThreshold(this.cid);
            List<Pair<String, Double>> docScore = Lists.newArrayList();
            List<Pair<String, String>> expireDocs = Lists.newArrayList();
            Map<String, NewsDocument> newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(documentInfoMap.keySet());

            for (DocumentInfo documentInfo : documentInfoMap.values()) {
                long timeDiff = new Date().getTime() - documentInfo.getDate().getTime();
                long minutes = (int) (timeDiff / (1000 * 60));
                if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                    NewsDocument newsDocument = newsDocumentMap.get(documentInfo.getDocid());
                    String newsDocumentExpire = newsDocumentExpire(newsDocument);
                    if (!Strings.isNullOrEmpty(newsDocumentExpire)) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), newsDocumentExpire));
                        continue;
                    }
                    if (newsDocument.getYDTags().contains("特殊_低俗") || newsDocument.getYDTags().contains("低俗")) {
                        expireDocs.add(Pair.of(documentInfo.getDocid(), "ydTags=" + newsDocument.getYDTags()));
                        continue;
                    }
                } else {
                    LogManager.EXPIRE.warn("cid: " + cid + " get doc failed from NewsDocumentCache docid: " + documentInfo.getDocid());
                }

                int lifeTime = Constants.UGC.equals(this.cid) ? Constants.SEVEN_DAYS : Constants.ONE_MONTH;
                if (minutes > lifeTime) {
                    expireDocs.add(Pair.of(documentInfo.getDocid(), "insertTime=" + minutes + ",lifeTime=" + lifeTime));
                    continue;
                }
                if (documentInfo.getRefer().equals("pipline") && documentInfo.getViews() >= viewsUpperLimit) {
                    expireDocs.add(Pair.of(documentInfo.getDocid(), "[explore enough time] refer=" + documentInfo.getRefer() + ",views=" + documentInfo.getViews()));
                    continue;
                }
                documentInfo.setBaseScore(documentInfo.getViews() != 0 ? ((float) documentInfo.getClicks() / documentInfo.getViews()) : 0);
                documentInfo.setRankScore(documentInfo.getPoolRankingScore());
                docScore.add(Pair.of(documentInfo.getDocid(), documentInfo.getPoolRankingScore()));
            }

            Date expireTime = new Date();
            for (Pair<String, String> pair : expireDocs) {
                DocumentInfo delDoc = documentInfoMap.get(pair.getLeft());
                if (delDoc == null) {
                    continue;
                }
                String video2string = "(docid=" + delDoc.getDocid() + ",views=" + delDoc.getViews() + ",clicks=" + delDoc.getClicks() + ",baseScore=" + delDoc.getBaseScore() + ",rankScore=" + delDoc.getRankScore() + ",titleWords=" + delDoc.getTitleWords() + ",refer=" + delDoc.getRefer() + ",tiger=" + delDoc.getTier() + ",date=" + delDoc.getDate() + ")";
                LogManager.EXPIRE.info("cluster " + cid + " removed doc " + video2string + " reason: " + pair.getRight());
                incViews(-delDoc.getViews());
                incClicks(-delDoc.getClicks());
                delDoc.setExpireTime(expireTime);
                ret.add(delDoc);
                documentInfoMap.remove(pair.getLeft());
            }
            docScore.sort(Comparator.comparingDouble(Pair::getValue));
            Metrics.simple().latency(cid + "_views_assurance_expire_process", System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            log.error("Views Assurance Expire Error:", e);
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return ret;
    }

    private int getViewAssuranceThreshold(String cid) {
        int defaultViews = 1000;
        String apolloKey;
        switch (cid) {
            case Constants.MCN:
                apolloKey = "mcn_default_views";
                break;
            case Constants.DOUYIN:
                apolloKey = "douyin_default_views";
                break;
            case Constants.UGC:
                apolloKey = "ugc_default_views";
                break;
            case Constants.MOMO:
                apolloKey = "momo_default_views";
                break;
            default:
                return defaultViews;
        }
        try {
            JSONObject config = ApolloConfigUtil.getInstance().getViewsAssuranceConfig();
            if (config.containsKey(apolloKey)) {
                defaultViews = Integer.parseInt(config.getString(apolloKey));
            }
        } catch (Exception e) {
            log.error("Read " + cid + " view assurance from apollo exception:", e);
        }
        return defaultViews;
    }
}
