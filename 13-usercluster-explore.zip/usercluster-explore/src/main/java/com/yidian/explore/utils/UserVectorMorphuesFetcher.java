package com.yidian.explore.utils;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.yidian.cfvectorestore.dao.MorphuesDao;
import com.yidian.cfvectorestore.utils.GZipUtils;
import com.yidian.serving.index.metrics.Metrics;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import yidian.data.usercf.UserVector;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xiaobo on 2017/8/25.
 */
public class UserVectorMorphuesFetcher {
    public static Logger logger = Logger.getLogger(UserVectorMorphuesFetcher.class);
    private static volatile Map<String, UserVectorMorphuesFetcher> instances = new HashMap();
    private MorphuesDao morphuesDao = null;

    private static final String CONFIG_PREFIX = "usercf-morphues-";

    public final static String TABLE_NAME_USER_VECTOR = "uservector";
    public final static String TABLE_NAME_USER_VIDEO_VECTOR = "video_user_vector";

    private UserVectorMorphuesFetcher(String table) {
        try {
            String configName = CONFIG_PREFIX + table;
            Config usercfConfig = ConfigFactory.load(UserVectorMorphuesFetcher.class.getClassLoader()).getConfig("usercluster-explore");
            if (usercfConfig == null || !usercfConfig.hasPath(configName)) {
                logger.error("Doesn't have usercf config or usercf config doesn't have " + configName + " configuration");
                throw new RuntimeException("Doesn't have usercf config or usercf config doesn't have " + configName + " configuration");
            }
            morphuesDao = new MorphuesDao(usercfConfig.getConfig(configName), table);
        } catch (Exception ex) {
            logger.error("Init MorpheusTools exception: " + ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public static UserVectorMorphuesFetcher getInstance(String table) {
        if (!instances.containsKey(table)) {
            synchronized (UserVectorMorphuesFetcher.class) {
                if (!instances.containsKey(table)) {
                    instances.put(table, new UserVectorMorphuesFetcher(table));
                }
            }
        }
        return instances.get(table);
    }

    public UserVector getUserRankVector(String userId, String column) {
        return getUserRankVector(userId, column, 0, null);
    }

    public UserVector getUserRankVector(String userId, String column, int clickNum, String version) {
        long startTime = System.currentTimeMillis();
        byte[] rankVecotrBytes = morphuesDao.read(userId, column);

        UserVector userVector = null;
        try {
            if (rankVecotrBytes != null && rankVecotrBytes.length > 0) {
                userVector = UserVector.parseFrom(GZipUtils.decompress(rankVecotrBytes));
                Metrics.simple().qps("usercluster_explore_getrankvector_succ");

                if (clickNum > 0 && userVector.getVectags().getClickNum() < clickNum) {
                    userVector = null;
                    Metrics.simple().qps("usercluster_explore_getrankvector_clicknum_tooless");
                }
                if (userVector != null && !StringUtils.isEmpty(version) && !version.equals(userVector.getVectags().getVersion())) {
                    userVector = null;
                    Metrics.simple().qps("usercluster_explore_getrankvector_version_error");
                }
            } else {
                Metrics.simple().qps("usercluster_explore_getrankvector_empty");
            }
        } catch (Exception ex) {
            Metrics.simple().qps("usercluster_explore_getrankvector_parse_failed");
            logger.error("getUserRankVector", ex);
        }

        long latency = System.currentTimeMillis() - startTime;
        Metrics.simple().latency("usercluster_explore_getuserrankvector_latency", latency);
        return userVector;
    }
}
