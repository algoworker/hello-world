package com.yidian.explore.service;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.cache.NewsDocumentCache;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.*;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class ClusterOperateServlet extends HttpServlet {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String op = request.getParameter("op");
        String cid = request.getParameter("cid");
        String doc = request.getParameter("docid");

        if (op.equals("reload")) {
            exploreExploitPools.loadExploreExploitData();
        } else if (op.equals("dump")) {
            exploreExploitPools.dumpExploreExploitData();
        } else if (op.equals("changeSafe")) {
            String reuse = request.getParameter("reuse");
            if (reuse == null) {
                HttpUtil.sendFailed(response, "globalExploitReuse is required");
                return;
            }
            if (reuse.equals("true")) {
                ExploreExploitConfig.defaultConfig().setGlobalExploitReuse(true);
            } else {
                ExploreExploitConfig.defaultConfig().setGlobalExploitReuse(false);
            }
        } else if (op.equals("enableCache")) {
            String cacheName = request.getParameter("cacheName");
            if (cacheName == null) {
                HttpUtil.sendFailed(response, "cacheName is required");
                return;
            }
            if (cacheName.equals("clusterCache")) {
                ExploreExploitConfig.defaultConfig().setExploreClusterCacheEnable(true);
            }
        } else if (op.equals("disableCache")) {
            String cacheName = request.getParameter("cacheName");
            if (cacheName == null) {
                HttpUtil.sendFailed(response, "cacheName is required");
                return;
            }
            if (cacheName.equals("clusterCache")) {
                ExploreExploitConfig.defaultConfig().setExploreClusterCacheEnable(false);
            }
        } else if (Objects.equals(op, "addDocument")) {
            if (cid != null && doc != null) {
                ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
                ClusterDocumentsPool clusterDocumentsPool;

                if ("mcnVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getMcnVideoExplorePool();
                } else if ("ugcVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getUgcVideoExplorePool();
                } else if ("douyinVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getDouyinVideoExplorePool();
                } else if ("momoVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getMomoVideoExplorePool();
                } else {
                    HttpUtil.sendFailed(response, "ClusterDocumentsPool cid error, only mcnVideoExplore or ugcVideoExplore or douyinVideoExplore is allowed");
                    return;
                }

                Optional<NewsDocument> ndOpt = NewsDocumentCache.defaultInstance().get(doc);
                if (!ndOpt.isPresent()) {
                    HttpUtil.sendFailed(response, "NewsDocument is none");
                    return;
                }

                NewsDocument nd = ndOpt.get();
                DocumentFeature documentFeature = new DocumentFeature(doc, nd.getSegTitle(), nd.getSource(), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(nd.getDate()), "pipline");
                documentFeature.setTier(nd.getDocAuthority().or(0));
                documentFeature.setSig(nd.getSignature());
                documentFeature.setKeywords(nd.getKeywords());

                clusterDocumentsPool.addDocument(documentFeature);
            } else {
                HttpUtil.sendFailed(response, "Both cid and docid are required");
                return;
            }
        } else if (Objects.equals(op, "removeDocumentInfo")) {
            if (cid != null && doc != null) {
                ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
                ClusterDocumentsPool clusterDocumentsPool;

                if ("mcnVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getMcnVideoExplorePool();
                } else if ("ugcVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getUgcVideoExplorePool();
                } else if ("douyinVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getDouyinVideoExplorePool();
                } else if ("momoVideoExplore".equals(cid)) {
                    clusterDocumentsPool = exploreExploitVideoPools.getMomoVideoExplorePool();
                } else {
                    HttpUtil.sendFailed(response, "ClusterDocumentsPool cid error, only mcnVideoExplore or ugcVideoExplore or douyinVideoExplore is allowed");
                    return;
                }

                clusterDocumentsPool.removeDocumentInfo(doc);
            } else {
                HttpUtil.sendFailed(response, "Both cid and docid are required");
                return;
            }
        }

        Map<String, Object> retMap = Maps.newHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        HttpUtil.setResponse(response, gson.toJson(retMap));
    }
}
