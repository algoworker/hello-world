package com.yidian.explore.cache;

import com.yidian.explore.core.DocumentFeature;

public class CacheVideoFeature {
    public String docid;
    public int survivalTime = 0;
    public float[] videoVector = null;
    public DocumentFeature documentFeature;

    public CacheVideoFeature(String docid, int survivalTime, float[] videoVector, DocumentFeature documentFeature) {
        this.docid = docid;
        this.survivalTime = survivalTime;
        this.videoVector = videoVector;
        this.documentFeature = documentFeature;
    }
}