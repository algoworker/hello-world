package com.yidian.explore.utils.convertor;

import com.alibaba.fastjson.JSONArray;
import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

@Deprecated
public class JsonArrayConfigConvertor implements IConfigObjectConvertor<JSONArray> {
    @Override
    public JSONArray convert(String value) {
        if (org.apache.commons.lang3.StringUtils.isNotBlank(value)) {
            return JSONArray.parseArray(value);
        }
        return null;
    }
}
