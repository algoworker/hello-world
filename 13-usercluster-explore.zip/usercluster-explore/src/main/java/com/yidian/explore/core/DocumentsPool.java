package com.yidian.explore.core;

import com.yidian.explore.compare_key.CompareKey;
import org.codehaus.jackson.JsonNode;

import java.util.List;
import java.util.Map;

public interface DocumentsPool {
    boolean addDocument(DocumentFeature doc);

    boolean updateStatus(String uid, String docid, String event);

    List<DocumentInfo> expire();

    List<DocumentInfo> model2newsExpire();

    List<DocumentInfo> fetch(int topn);

    List<DocumentInfo> fetch(int topn, CompareKey ck);

    boolean contain(String docid);

    boolean addDocumentInfo(DocumentInfo documentInfo);

    DocumentInfo removeDocumentInfo(String dodid);

    boolean deserialize(JsonNode root);

    Map<String, Object> serialize();

    Map<String, Object> getDebugInfo(int topn, CompareKey ck);

    boolean embedFrameVector();

    Map<String, DocumentInfo> getClusterDocumentInfos();
}