package com.yidian.explore.utils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by mengjun on 16/11/19.
 */
public class KnnSimVideosHandler {
    private static Logger logger = Logger.getLogger(KnnSimVideosHandler.class);
    private static volatile KnnSimVideosHandler instance = null;
    private static Gson gson = new Gson();

    protected static HttpClient client;
    private static String SIM_VIDEOS_SERVICE = "http://k-nearestneighbor.ha.in.yidian.com:9000/knn/search";

    private int DEFAULT_VIDEO_SIM_NUM = 10;
    private String KNN_VIDEO_SIM_TYPE = "video2video";
    private String KNN_VIDEO_SIM_COLUMN = "b";
    private String KNN_VIDEO_SIM_VERSION = "1";

    private KnnSimVideosHandler() {
        PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager();
        connectionManager.setMaxTotal(1000);
        connectionManager.setDefaultMaxPerRoute(1000);
        client = new DefaultHttpClient(connectionManager);
        client.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5 * 10);
        client.getParams().setIntParameter(CoreConnectionPNames.SO_TIMEOUT, 150);

        Config usercfConfig = ConfigFactory.load(KnnSimVideosHandler.class.getClassLoader()).getConfig("usercluster-explore");
        if (usercfConfig == null) {
            logger.error("Doesn't have usercf config");
            throw new RuntimeException("Doesn't have usercf config");
        }

        if (usercfConfig.hasPath("knn-videos")) {
            try {
                Config knnVideosConfig = usercfConfig.getConfig("knn-videos");
                if (knnVideosConfig.hasPath("knn.videos.num")) {
                    DEFAULT_VIDEO_SIM_NUM = knnVideosConfig.getInt("knn.videos.sim.num");
                    logger.info("override default video sim num to: " + DEFAULT_VIDEO_SIM_NUM);
                }
                if (knnVideosConfig.hasPath("knn.videos.type")) {
                    KNN_VIDEO_SIM_TYPE = knnVideosConfig.getString("knn.videos.sim.type");
                    logger.info("override knn video sim type to: " + KNN_VIDEO_SIM_TYPE);
                }
                if (knnVideosConfig.hasPath("knn.videos.sim.column")) {
                    KNN_VIDEO_SIM_COLUMN = knnVideosConfig.getString("knn.videos.sim.column");
                    logger.info("override knn video sim column to: " + KNN_VIDEO_SIM_COLUMN);
                }
                if (knnVideosConfig.hasPath("knn.videos.sim.version")) {
                    KNN_VIDEO_SIM_VERSION = knnVideosConfig.getString("knn.videos.sim.version");
                    logger.info("override knn video sim version to: " + KNN_VIDEO_SIM_VERSION);
                }
            } catch (Exception ex) {
                logger.error("Init SimUserHandler Exception", ex);
            }
        }
    }

    public static KnnSimVideosHandler getInstance() {
        if (instance == null) {
            synchronized (KnnSimVideosHandler.class) {
                if (instance == null) {
                    instance = new KnnSimVideosHandler();
                }
            }
        }
        return instance;
    }

    public KnnResponseData getKnnData(String docId, float[] vector) throws IOException {
        String metricPrefix = "usercluster-ee.video.explore";
        return getKnnData(metricPrefix, docId, KNN_VIDEO_SIM_COLUMN, KNN_VIDEO_SIM_TYPE, DEFAULT_VIDEO_SIM_NUM, KNN_VIDEO_SIM_VERSION, vector);
    }

    private KnnResponseData getKnnData(String metricPrefix, String docId, String vecColumn, String type, int num, String version, float[] vec) throws IOException {
        String serviceAdd = SIM_VIDEOS_SERVICE;
        HttpPost post = new HttpPost(serviceAdd);
        KnnResponseData knnResponseData = new KnnResponseData();

        try {
            if (docId == null || !docId.startsWith("V_")) {
                logger.error("docId parameter error: " + docId + " can't return sim-video by knn search");
                return knnResponseData;
            }
            if (vec == null || vec.length != 256) {
                logger.error("Video vector parameter error: " + docId + " can't return sim-video by knn search");
                return knnResponseData;
            }

            // long startTime = System.currentTimeMillis();
            List<NameValuePair> postParameters = new ArrayList<>();

            postParameters.add(new BasicNameValuePair("extern-id", docId));
            postParameters.add(new BasicNameValuePair("top", String.valueOf(num)));
            postParameters.add(new BasicNameValuePair("type", type));
            postParameters.add(new BasicNameValuePair("column", vecColumn));
            if (version != null && !version.isEmpty()) {
                postParameters.add(new BasicNameValuePair("version", version));
            }

            StringBuilder vecStr = new StringBuilder();
            for (float item : vec) {
                vecStr.append(item).append(" ");
            }
            postParameters.add(new BasicNameValuePair("vector", vecStr.substring(0, vecStr.length() - 1)));
            postParameters.add(new BasicNameValuePair("byPassCache", "true"));

            post.setEntity(new UrlEncodedFormEntity(postParameters));
            HttpResponse response = client.execute(post);
            // long execLatency = System.currentTimeMillis() - startTime;
            // logger.info("docId:" + docId + " knn search execute latency:" + execLatency);

            String respJsonStr = EntityUtils.toString(response.getEntity(), "UTF-8");
            if (respJsonStr == null) {
                logger.error("RespJsonStr type error");
                return knnResponseData;
            }

            Map<String, Object> retMap = gson.fromJson(respJsonStr, new TypeToken<Map<String, Object>>() {
            }.getType());

            if (retMap.containsKey("result") && retMap.get("result") != null) {
                List<Map<String, Object>> simUserDataMap = (List<Map<String, Object>>) retMap.get("result");
                if (simUserDataMap.isEmpty()) {
                    return knnResponseData;
                }
                Map<String, Object> dataMap = simUserDataMap.get(0);
                String doc = (String) dataMap.get("externId");
                double similarity = (double) dataMap.get("distance");
                if (doc == null || !doc.startsWith("V_")) {
                    return knnResponseData;
                }
                knnResponseData.docId = doc;
                knnResponseData.similarity = similarity;
            }

            return knnResponseData;

        } catch (Exception ex) {
            String log = String.format("getSimVideos[%s %s %s %s %s]:" + ex, docId, String.valueOf(num), type, vecColumn, version);
            logger.error(log);
            throw new IOException(ex);
        } finally {
            post.releaseConnection();
        }
    }

    public static class KnnResponseData {
        public String docId = null;
        public Double similarity = null;
    }

    public static void main(String[] args) throws IOException {
        String docid = "V_01JmzJMu";
        float[] videoVector = VideoVectorMorpheusFetcher.getInstance("usercf-morpheus-video_avg_feature").getVideoVector(docid);

        KnnResponseData data = KnnSimVideosHandler.getInstance().getKnnData(docid, videoVector);
        System.out.println(data.docId);
        System.out.println(data.similarity);
    }
}
