package com.yidian.explore.utils;

import lombok.extern.log4j.Log4j;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static java.util.stream.Collectors.toSet;

/**
 * Created by xin on 2018/11/09 14:30.
 */
@Log4j
public class LoadConfigFile {
    private static volatile LoadConfigFile instance = null;

    private ACTrie mcnACTrie = new ACTrie();
    private ACTrie dytopACTrie = new ACTrie();
    private ACTrie topVctACTrie = new ACTrie();
    private ACTrie exploreSourceACTrie = new ACTrie();

    public ACTrie getMcnACTrie() {
        return this.mcnACTrie;
    }

    public ACTrie getDytopACTrie() {
        return this.dytopACTrie;
    }

    public ACTrie getTopVctACTrie() {
        return this.topVctACTrie;
    }

    public ACTrie getExploreSourceACTrie(){
        return this.exploreSourceACTrie;
    }

    public static LoadConfigFile getInstance() {
        if (instance == null) {
            synchronized (LoadConfigFile.class) {
                if (instance == null) {
                    instance = new LoadConfigFile();
                }
            }
        }
        return instance;
    }

    private LoadConfigFile() {
        try {
            Set<String> mcnSourceWhiteList;
            mcnSourceWhiteList = ApolloConfigUtil.getInstance().getMcnInvitationSource();
            if (mcnSourceWhiteList == null || mcnSourceWhiteList.isEmpty()) {
                log.warn("load mcn view assurance source white list from apollo exception");
                mcnSourceWhiteList = Files.readAllLines(Paths.get("mcnInvitationSource.txt")).stream()
                        .map(line -> line.trim())
                        .collect(toSet());
            }
            for (String source : mcnSourceWhiteList) {
                mcnACTrie.addKeyword(source);
            }

            Set<String> douyinTopSourceWhiteList;
            douyinTopSourceWhiteList = ApolloConfigUtil.getInstance().getDouyinTopSource();
            if (douyinTopSourceWhiteList == null || douyinTopSourceWhiteList.isEmpty()) {
                log.warn("load douyin top view assurance source white list from apollo exception");
                douyinTopSourceWhiteList = Files.readAllLines(Paths.get("douyinTopSourceInYidian.txt")).stream()
                        .map(line -> line.trim())
                        .collect(toSet());
            }
            for (String source : douyinTopSourceWhiteList) {
                dytopACTrie.addKeyword(source);
            }

            Set<String> boostViewVideoCategoryWhiteList;
            boostViewVideoCategoryWhiteList = ApolloConfigUtil.getInstance().getBoostViewVideoCategory();
            if (boostViewVideoCategoryWhiteList == null || boostViewVideoCategoryWhiteList.isEmpty()) {
                log.warn("load boost view video category white list from apollo exception");
                // 默认的15个大类根据人均停留时长降序排列
                String[] defaultVctWhiteList = {"电视剧", "游戏", "综艺", "电影", "三农", "动漫", "搞笑", "生活", "社会", "军事", "音乐", "体育", "时政", "民生", "国际"};
                boostViewVideoCategoryWhiteList = new HashSet<>(Arrays.asList(defaultVctWhiteList));
            }
            for (String vct : boostViewVideoCategoryWhiteList) {
                topVctACTrie.addKeyword(vct);
            }

            Set<String> exploreSourceBlacklist;
            exploreSourceBlacklist = ApolloConfigUtil.getInstance().getExploreSourceBlacklist();
            if (exploreSourceBlacklist != null && !exploreSourceBlacklist.isEmpty()) {
                for (String source : exploreSourceBlacklist) {
                    exploreSourceACTrie.addKeyword(source);
                }
            }
        } catch (IOException e) {
            log.error("load source files into actrie exception:", e);
        }
    }
}
