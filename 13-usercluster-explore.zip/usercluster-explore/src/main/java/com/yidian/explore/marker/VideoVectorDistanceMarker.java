package com.yidian.explore.marker;

import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.VideoFeature;
import com.yidian.explore.dao.CentroidsDao;
import com.yidian.explore.utils.ACTrie;
import com.yidian.explore.utils.VideoEmbedding;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Set;

import static java.util.stream.Collectors.toSet;

public class VideoVectorDistanceMarker implements Marker {
    public static Logger logger = Logger.getLogger(VideoVectorDistanceMarker.class);
    private static ACTrie highContentQualityFromidACTrie = new ACTrie();

    static {
        try {
            Set<String> highContentQualityFromidList = Files.readAllLines(Paths.get("20190416_HighContentQualityFromid.txt")).stream()
                    .map(line -> line.trim())
                    .collect(toSet());
            for (String source : highContentQualityFromidList) {
                highContentQualityFromidACTrie.addKeyword(source);
            }
        } catch (IOException e) {
            logger.error("load HighContentQualityFromid text file into actrie exception:", e);
        }
    }

    public float score(String cid, DocumentFeature df) {
        float[] cvec = CentroidsDao.defaultDAO().getVecByCid(cid);
        float[] vvec = null;

        if (df instanceof VideoFeature) {
            VideoFeature vf = (VideoFeature) df;
            vvec = VideoEmbedding.defaultInstance().getVideoVectorFromCacheByVf(vf);
        }

        float score = 0;
        if (cvec == null || vvec == null) {
            return score;
        }
        for (int i = 0; i < cvec.length; i++) {
            score += cvec[i] * vvec[i];
        }
//        if (highContentQualityFromidACTrie.contains(df.source)) {
//            score += 0.5;
//        }

        return score;
    }
}