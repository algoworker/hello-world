package com.yidian.explore.core;

import lombok.Data;

@Data
public class MIPSEntry {
    public String externId;
    public float distance;
    public double score;
}
