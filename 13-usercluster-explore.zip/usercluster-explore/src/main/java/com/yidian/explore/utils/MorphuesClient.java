package com.yidian.explore.utils;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.yidian.cfvectorestore.dao.MorphuesDao;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * Created by liupeng on 17/3/7.
 */
public class MorphuesClient{
    private static Logger logger = Logger.getLogger(MorphuesClient.class);
    private static volatile Map<String, MorphuesClient> instances = new HashMap();
    private MorphuesDao morphuesDao = null;
    private static int MIN_CLICK_NUM = 50;
    private static final int RETRY_NUM = 5;

    private static final String CONFIG_PREFIX = "usercf-morphues-";

    private MorphuesClient(String table) {
        try {
            String configName = CONFIG_PREFIX + table;
            Config usercfConfig = ConfigFactory.load(MorphuesClient.class.getClassLoader()).getConfig("usercluster-explore");
            if (usercfConfig == null || !usercfConfig.hasPath(configName)) {
                logger.error("Doesn't have usercf config or usercf config doesn't have " + configName + " configuration");
                throw new RuntimeException("Doesn't have usercf config or usercf config doesn't have " + configName + " configuration");
            }
            morphuesDao = new MorphuesDao(usercfConfig.getConfig(configName), table);
        } catch (Exception ex) {
            logger.error("Init MorpheusClient exception: " + ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public static MorphuesClient getInstance(String table) {
        if (!instances.containsKey(table)) {
            synchronized (MorphuesClient.class) {
                if (!instances.containsKey(table)) {
                    instances.put(table, new MorphuesClient(table));
                }
            }
        }
        return instances.get(table);
    }

    public String write(String key, byte[] value, String column){
        return morphuesDao.write(key, value, column);
    }

    public byte[] read(String key, String column) {
        byte[] result = null;
        int num = 0;
        while(result == null || result.length == 0) {
            result = morphuesDao.read(key, column);
            num++;
            if(num > RETRY_NUM){
                break;
            }
        }
        return result;
    }

    public Map<String, byte[]> batchRead(List<Pair<String, String>> keyList) {
        return morphuesDao.batchRead(keyList);
    }

    public void delete(String key, String column){
        morphuesDao.delete(key, column);
    }

    public static void main(String [] args){
        byte[] ret = MorphuesClient.getInstance("user_cluster").read("99998722", "a");
        System.out.println(new String(ret));
    }
}
