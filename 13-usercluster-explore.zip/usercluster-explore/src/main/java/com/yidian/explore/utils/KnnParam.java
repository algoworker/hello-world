package com.yidian.explore.utils;

import com.alibaba.fastjson.JSONObject;
import com.yidian.explore.constant.Constants;

public class KnnParam {
    public String column;
    public Integer version;
    public String usercfColumn;
    public Integer usercfVersion;

    public KnnParam(String column, Integer version, String usercfColumn, Integer usercfVersion) {
        this.column = column;
        this.version = version;
        this.usercfColumn = usercfColumn;
        this.usercfVersion = usercfVersion;
    }

    public KnnParam(JSONObject object) {
        this.column = object.getString(Constants.COLUMN);
        this.version = Integer.parseInt(object.getString(Constants.VERSION));
        this.usercfColumn = object.getString(Constants.USERCF_COLUMN);
        if (object.getString(Constants.USERCF_VERSION) != null) {
            this.usercfVersion = Integer.parseInt(object.getString(Constants.USERCF_VERSION));
        }
    }

    public void nextVersion() {
        if ("a".equals(this.column)) {
            this.column = "b";
        } else {
            this.column = "a";
        }
        this.version += 1;
    }

    public JSONObject tojson() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(Constants.COLUMN, this.column);
        jsonObject.put(Constants.VERSION, this.version);
        jsonObject.put(Constants.USERCF_COLUMN, this.usercfColumn);
        jsonObject.put(Constants.USERCF_VERSION, this.usercfVersion);
        return jsonObject;
    }
}

