package com.yidian.explore.task;

import com.yidian.explore.constant.MetricsNameEnum;
import com.yidian.explore.filter.DocumentFilter;
import com.yidian.explore.filter.VideoFilter;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.utils.KafkaConsumer;
import com.yidian.explore.utils.MonMetricsUtil;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.message.MessageAndMetadata;
import kafka.utils.ZkUtils;
import lombok.extern.log4j.Log4j;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

@Log4j
public class ExploreVideoCollect extends Thread {
    private DocumentFilter videoFilter = null;
    private String topic = "null";

    public ExploreVideoCollect(DocumentFilter videoFilter, String topic) {
        this.videoFilter = videoFilter;
        this.topic = topic;
    }

    @Override
    public void run() {
        super.run();
        this.setName("ExploreVideoCollect-thread-" + topic);
        Properties props = new Properties();

        try {
            FileInputStream fs = new FileInputStream("kafka.properties");
            props.load(fs);
            log.info("reading kafka.properties");
        } catch (FileNotFoundException e) {
            log.error("kafka.properties is missing!");
            log.error(e);
            System.exit(-1);
        } catch (IOException e) {
            log.error("read kafka.properties failed!");
            log.error(e);
            System.exit(-1);
        }

        String hostName = "usercluster-ee";
        try {
            hostName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.error("The hostname cannot be resolved", e);
            throw new RuntimeException(e);
        }

        props.setProperty("group.id", hostName);
        String zkUrl = props.getProperty("zookeeper.connect").replace("/violet", "");
        ZkUtils.maybeDeletePath(zkUrl, "/violet/consumers/" + hostName + "/offsets/indata_str_vertical_documents");

        IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

        ConsumerConfig config = new ConsumerConfig(props);
        KafkaConsumer consumer = new KafkaConsumer(config);

        KafkaStream<byte[], byte[]> stream = consumer.createMessageStream("indata_str_vertical_documents");
        Iterator<MessageAndMetadata<byte[], byte[]>> iter = stream.iterator();

        while (iter.hasNext()) {
            MessageAndMetadata<byte[], byte[]> msg = iter.next();
            String data = new String(msg.message());
            MonMetricsUtil.qps(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.beforeFilter);
            Optional<DocumentFeature> documentFeatureOpt = videoFilter.filter(data);
            documentFeatureOpt.ifPresent(exploreExploitPools::addDocument);
        }
    }

    public static void main(String[] args) {
        System.out.println("Start debug ExploreVideoCollect.");
        ExploreVideoCollect evc = new ExploreVideoCollect(VideoFilter.getInstance(), "indata_str_vertical_documents");
        evc.run();
        System.out.println("Debug have done.");
    }
}
