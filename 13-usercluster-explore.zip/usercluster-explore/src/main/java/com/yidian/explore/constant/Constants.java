package com.yidian.explore.constant;

import java.text.SimpleDateFormat;
import java.util.*;

public final class Constants {
    /**
     * explore and exploit video life time (minutes)
     */
    public static final int HALF_DAY = 720;
    public static final int ONE_DAY = 1440;
    public static final int SEVEN_DAYS = 10080;
    public static final int HALF_MONTH = 1440 * 15;
    public static final int ONE_MONTH = 1440 * 30;

    /**
     * cjv feedback process thread number
     */
    public static final int FEEDBACK_THREAD_NUM = 5;

    /**
     * default views count
     */
    public static final int EXPLORE_TIME = 300;
    public static final int EXPLOSIVE_TIME = 1000;

    /**
     * default expire refresh time
     * usercluster:300 seconds
     * model2news:300 seconds
     */
    public static final int USERCLUSTER_EXPIRE_FREQUENCY = 60 * 5;
    public static final int MODEL2NEWS_EXPIRE_FREQUENCY = 60 * 3;

    /**
     * cluster pools cid
     */
    public static final String MCN = "mcnVideoExplore";
    public static final String UGC = "ugcVideoExplore";
    public static final String DOUYIN = "douyinVideoExplore";
    public static final String ALLIN = "allInVideoPool";
    public static final String BOOST_VIEW = "boostViewVideoExploit";
    public static final String MOMO = "momoVideoExplore";

    /**
     * String "model2news" is unique cid of model2explore and model2exploit.
     * String "model2newsVideoPool" unique pool name of all model2news cids.
     * String "feedbackRecovery" is unique cid of another pool used to recover backward feedback.
     */
    public static final String MODEL2NEWS = "model2news";
    public static final String FEEDBACK_RECOVERY = "feedbackRecovery";
    public static final String MODEL2NEWS_VIDEO_POOL = "model2newsVideoPool";

    /**
     * need boost view video parameters threshold
     */
    public static final double G_CTR_TH = 0.2;
    public static final double G_DWELL_TH = 60D;
    public static final double GVIEW_LOWER_LIMIT = 200D;

    /**
     * user2video online vfactors
     */
    public static final String ECOLOGY = "video-m2nEcology";

    /**
     * SimpleDateFormat是非线程安全类
     */
    public static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * explore&exploit create features
     */
    public static final String S_EXPLORE = "s_explore";
    public static final String S_EXPLOIT = "s_exploit";

    /**
     * exploit features evaluated by explore feedback
     */
    public enum ExploreFeedback {
        EXPLOSIVE,  // feedback view more than explosive threshold
        EXCELLENT,  // feedback ctr (0.25, 1]
        GOOD,  // feedback ctr (0.15, 0.25]
        GENERAL,  // feedback ctr (0.1, 0.15]
        BAD,  // feedback ctr (0.05, 0.1]
        TERRIBLE,  // feedback ctr [0, 0.05] nearly 30% videos
    }

    /**
     * UGC小视频源
     */
    public static final String UGC_SOURCE = "一点UGC";

    /**
     * knn morpheus parameters
     */
    public static final String USERCF_PARAM = "usercf_param";
    public static final String USERVECTORVIDEO_KNN = "uservector_video";
    public static final String PARAM_COLUMN = "param";
    public static final String VERSION = "main_version";
    public static final String COLUMN = "main_column";
    public static final String USERCF_VERSION = "usercf_main_version";
    public static final String USERCF_COLUMN = "usercf_main_column";
    public static final String USER2EXPLOREVIDEO_TRAIN = "user2explorevideo_train_parameters";
    public static final String USER2EXPLOREVIDEO_ONLINE = "user2explorevideo_online_parameters";
    public static final String USER2EXPLOREVIDEO = "user2explorevideo";

    /**
     * time punish bin
     */
    public static Map<Double, Double> PUNISHBIN = new HashMap<>();

    /**
     * metrics threshold of effective explore views
     */
    public static final int EFFECTIVE_EXPLORE_MINUTE = 30;

    static {
        PUNISHBIN.put(0.5, 2d);
        PUNISHBIN.put(3.0, 1.5);
        PUNISHBIN.put(6.0, 1.2);
    }

    private Constants() {

    }

    public static void main(String[] args) {
        for (int i = 0; i < 100; i++) {
            double value = Math.exp(i);
            System.out.println(value);
        }
    }
}
