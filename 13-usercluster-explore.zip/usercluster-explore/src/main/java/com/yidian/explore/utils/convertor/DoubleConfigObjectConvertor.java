package com.yidian.explore.utils.convertor;

import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

public class DoubleConfigObjectConvertor implements IConfigObjectConvertor<Double> {
    @Override
    public Double convert(String value) {
        return Double.parseDouble(value);
    }
}
