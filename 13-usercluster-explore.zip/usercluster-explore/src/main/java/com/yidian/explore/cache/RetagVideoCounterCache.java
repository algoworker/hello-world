package com.yidian.explore.cache;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import lombok.extern.log4j.Log4j;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Xin
 * @version 需要重新打标的参与试探的短视频签计数器
 * @date 2019/07/28 12:20
 */
@Log4j
public class RetagVideoCounterCache {
    private static volatile RetagVideoCounterCache instance = null;
    private static final String COUNTER_KEY = "counter";

    private static LoadingCache<String, AtomicInteger> retagExploreVideoCounter = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .recordStats()
            .build(new CacheLoader<String, AtomicInteger>() {
                @Override
                public AtomicInteger load(String key) throws Exception {
                    log.warn("Init re-tag explore video counter to zero");
                    return new AtomicInteger(0);
                }
            });

    private static LoadingCache<String, AtomicInteger> retagExploreMicroVideoCounter = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .recordStats()
            .build(new CacheLoader<String, AtomicInteger>() {
                @Override
                public AtomicInteger load(String key) throws Exception {
                    log.warn("Init re-tag explore micro video counter to zero");
                    return new AtomicInteger(0);
                }
            });

    public static RetagVideoCounterCache getInstance() {
        if (instance == null) {
            synchronized (RetagVideoCounterCache.class) {
                if (instance == null) {
                    instance = new RetagVideoCounterCache();
                }
            }
        }
        return instance;
    }

    public AtomicInteger getVideoCounter() {
        try {
            return retagExploreVideoCounter.get(COUNTER_KEY);
        } catch (ExecutionException e) {
            log.error(e);
        }
        return new AtomicInteger(0);
    }

    public void setVideoCounter(int value) {
        try {
            retagExploreVideoCounter.get(COUNTER_KEY).set(value);
        } catch (ExecutionException e) {
            log.error(e);
        }
    }

    public AtomicInteger getMicroVideoCounter() {
        try {
            return retagExploreMicroVideoCounter.get(COUNTER_KEY);
        } catch (ExecutionException e) {
            log.error(e);
        }
        return new AtomicInteger(0);
    }

    public void setMicroVideoCounter(int value) {
        try {
            retagExploreMicroVideoCounter.get(COUNTER_KEY).set(value);
        } catch (ExecutionException e) {
            log.error(e);
        }
    }
    public void reset() {
        try {
            retagExploreVideoCounter.get(COUNTER_KEY).set(0);
            retagExploreMicroVideoCounter.get(COUNTER_KEY).set(0);
        } catch (ExecutionException e) {
            log.error(e);
        }
    }


    public static void main(String[] args) {
        int counter = RetagVideoCounterCache.getInstance().getVideoCounter().intValue();
        System.out.print(counter);
        RetagVideoCounterCache.getInstance().setVideoCounter(100);
        counter = RetagVideoCounterCache.getInstance().getVideoCounter().intValue();
        System.out.print(counter);
    }
}

