package com.yidian.explore.ranker;

import com.google.common.collect.Lists;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.explore.utils.DocEmbedding;
import com.yidian.explore.utils.UserVectorMorphuesFetcher;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import org.apache.log4j.Logger;
import yidian.data.usercf.UserVector;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Created by xiaobo on 2017/8/25.
 */
@Deprecated
public class DocRerankPerUser {
    public static Logger logger = Logger.getLogger(DocRerankPerUser.class);

    private static float[] extractVector(UserVector userVector) {
        if (userVector == null) {
            return null;
        }
        int size = userVector.getVecsCount();
        float[] vec = new float[size];

        int i;
        double len = 0;
        float value;
        for (i = 0; i < size; ++i) {
            value = userVector.getVecs(i);
            vec[i] = value;
            len += (double) (value * value);
        }

        len = Math.sqrt(len);

        for (i = 0; i < size; ++i) {
            vec[i] = (float) ((double) vec[i] / len);
        }

        return vec;
    }

    public static float simScore(float[] userVec, float[] docVec) {
        float score = 0;
        if (userVec == null || docVec == null || userVec.length != docVec.length) {
            return score;
        }
        for (int i = 0; i < userVec.length; i++) {
            score += userVec[i] * docVec[i];
        }
        return score;
    }

    public static float getUserDocSimScore(String userId, DocumentInfo documentInfo){
        if (userId == null || documentInfo == null) {
            logger.error("parameter error");
            return 0;
        }
        try {
            UserVector userVectorInfo = UserVectorMorphuesFetcher.getInstance(UserVectorMorphuesFetcher.TABLE_NAME_USER_VECTOR).getUserRankVector(userId, "b", 0, "9");
            if (userVectorInfo == null) {
                logger.info("userid:" + userId + " does not have vec.");
                return 0;
            }
            float[] userVec = extractVector(userVectorInfo);
            SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            com.google.common.base.Optional<NewsDocument> ndOpt = DocumentDataDAO.getInstance().getDocumentOpt(documentInfo.getDocid());
            if(ndOpt.isPresent()){
                NewsDocument nd = ndOpt.get();
                DocumentFeature documentFeature = new DocumentFeature(nd.getDocid(), nd.getSegTitle(), nd.getSource(), simpleFormat.format(nd.getDate()), "pipline");
                documentFeature.setTier(nd.getDocAuthority().or(0));
                documentFeature.setSig(nd.getSignature());
                documentFeature.setKeywords(nd.getKeywords());
                float[] docVec = DocEmbedding.defaultInstance().getDocVec(documentFeature);
                return simScore(userVec, docVec);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return 0;
    }

    public static void rerank(String userId, List<DocumentInfo> clusterRes, int num) {
        if (clusterRes == null || num <= 0) {
            logger.error("parameter error");
            return;
        }
        try {
            if (num >= clusterRes.size()) {
                num = clusterRes.size();
            }
            List<DocumentInfo> rerankRes = clusterRes.subList(0, num);
            UserVector userVectorInfo = UserVectorMorphuesFetcher.getInstance(UserVectorMorphuesFetcher.TABLE_NAME_USER_VECTOR).getUserRankVector(userId, "b", 0, "9");
            if (userVectorInfo == null) {
                logger.info("userid:" + userId + " does not have vec.");
                return;
            }
            float[] userVec = extractVector(userVectorInfo);
            SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            List<String> docids = Lists.newArrayList();
            for (DocumentInfo doc : rerankRes) {
                docids.add(doc.getDocid());
            }
            Map<String, NewsDocument> newsDocumentMap = DocumentDataDAO.getInstance().getDocumentsMap(docids);
            for (DocumentInfo doc : rerankRes) {
                NewsDocument nd = newsDocumentMap.get(doc.getDocid());
                if (nd == null) {
                    doc.setRankScore(-10);
                    continue;
                }
                DocumentFeature documentFeature = new DocumentFeature(nd.getDocid(), nd.getSegTitle(), nd.getSource(), simpleFormat.format(nd.getDate()), "pipline");
                documentFeature.setTier(nd.getDocAuthority().or(0));
                documentFeature.setSig(nd.getSignature());
                documentFeature.setKeywords(nd.getKeywords());
                float[] docVec = DocEmbedding.defaultInstance().getDocVec(documentFeature);
                doc.setRankScore(simScore(userVec, docVec));
            }
            rerankRes.sort(Comparator.comparingDouble(d -> -d.getRankScore()));
        } catch (Exception e) {
            logger.error(e);
        }
    }

    public static void unittest(List<Integer> list) {
        list.subList(0, 4).sort(Comparator.comparingInt(d -> d));
    }

    public static void main(String[] args) {
        List<Integer> list = Lists.newArrayList();
        list.add(5);
        list.add(4);
        list.add(3);
        list.add(2);
        list.add(1);

        unittest(list);
        System.out.print(list);
    }
}
