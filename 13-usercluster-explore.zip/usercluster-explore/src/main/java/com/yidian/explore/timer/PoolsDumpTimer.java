package com.yidian.explore.timer;

import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.explore.constant.LogManager;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Xin
 * @version 定期将内存中的视频池写入mongo, 防止k8s视频异常自动重启
 * @date 2019/02/18 12:10
 */
public class PoolsDumpTimer {
    private static volatile PoolsDumpTimer instance = null;

    public static PoolsDumpTimer getInstance() {
        if (instance == null) {
            synchronized (PoolsDumpTimer.class) {
                if (instance == null) {
                    instance = new PoolsDumpTimer();
                }
            }
        }
        return instance;
    }

    private PoolsDumpTimer() {
        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();

                Date now = new Date(System.currentTimeMillis());
                LogManager.DUMP.info("Video pools dump into morpheus and mongo task is executing at " + now.toString());

                exploreExploitVideoPools.dumpExploreExploitData();

                Date next = new Date(System.currentTimeMillis() + 1000 * 60 * 60);
                LogManager.DUMP.info("Next video pools dump into morpheus and mongo task will be executed at " + next.toString());
            }
        }, 1000L * 60 * 15, 1000L * 60 * 60);  // 每60分钟dump一次
    }
}

