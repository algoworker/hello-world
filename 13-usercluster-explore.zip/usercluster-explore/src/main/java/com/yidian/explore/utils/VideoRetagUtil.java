package com.yidian.explore.utils;

import com.google.common.base.Strings;
import com.hipu.util.helper.JacksonUtil;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClientConfig;
import com.ning.http.client.Response;
import com.yidian.explore.cache.AlreadyRetagVideoCache;
import com.yidian.explore.cache.RetagVideoCounterCache;
import com.yidian.explore.constant.LogManager;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;

import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @version 视频人工审核重新打标签服务, 接入文明系统
 * @date 2019-07-05 11:00
 */
@Log4j
public class VideoRetagUtil {
    private static volatile boolean needRetagVideo = true;
    private static volatile boolean needRetagMicroVideo = true;
    private static final String SERVICE_INTERFACE = "http://imedia.int.yidian-inc.com/post/quality/audit?doc_ids=";
    private static final String UGC_SERVICE_INTERFACE = "http://a4.go2yd.com/Website/ugc/quality-notify?docid=";
    private static final SimpleMetrics metrics = Metrics.simple();

    private VideoRetagUtil() {

    }

    public static boolean needRetagVideo() {
        return needRetagVideo;
    }

    public static boolean needRetagMicroVideo() {
        return needRetagMicroVideo;
    }

    public static void reset() {
        needRetagVideo = true;
        needRetagMicroVideo = true;
    }

    private static final AsyncHttpClient asyncHttpClient = new AsyncHttpClient(
            new AsyncHttpClientConfig.Builder()
                    .setFollowRedirect(true)
                    .setRequestTimeout(5000)
                    .build());

    public static void writeRetagVideo(Object documentInfo) {
        try {
            String docid;
            if (documentInfo instanceof DocumentFeature) {
                docid = ((DocumentFeature) documentInfo).getDocid();
            } else if (documentInfo instanceof DocumentInfo) {
                docid = ((DocumentInfo) documentInfo).getDocid();
            } else {
                return;
            }
            if (AlreadyRetagVideoCache.contain(docid)) {
                return;
            }
            String serviceUrl = SERVICE_INTERFACE + docid;
            Future<Response> responseFuture = asyncHttpClient.prepareGet(serviceUrl).execute();
            Response response = responseFuture.get();
            String responseStr = response.getResponseBody();
            if (Strings.isNullOrEmpty(responseStr)) {
                log.error("Execute explore re-tag video write service " + serviceUrl + " exception");
                return;
            }

            JsonNode jsonResult = JacksonUtil.getJsonObject(responseStr);
            String status = jsonResult.get("status").asText();
            if (!"success".equalsIgnoreCase(status)) {
                log.error(serviceUrl + " response status exception:" + status);
                return;
            }
            LogManager.TAG.info("Retag video: " + documentInfo.toString());
            AlreadyRetagVideoCache.putIfNotContain(docid, documentInfo);
            metrics.qps("model2newsVideoExplore_return_retag_video_success");

            AtomicInteger beforeWrite = RetagVideoCounterCache.getInstance().getVideoCounter();
            if (beforeWrite.intValue() >= ApolloConfigUtil.getInstance().getRetagExploreVideoCount()) {
                needRetagVideo = false;
                return;
            }
            int incBeforeWrite = beforeWrite.intValue() + 1;
            RetagVideoCounterCache.getInstance().setVideoCounter(incBeforeWrite);
        } catch (Exception e) {
            log.error("Write re-tag video " + documentInfo.toString() + " exception:", e);
        }
    }

    public static void writeRetagMicroVideo(Object video) {
        try {
            String docid;
            if (video instanceof DocumentFeature) {
                docid = ((DocumentFeature) video).getDocid();
            } else if (video instanceof DocumentInfo) {
                docid = ((DocumentInfo) video).getDocid();
            } else {
                return;
            }
            if (AlreadyRetagVideoCache.contain(docid)) {
                return;
            }
            String serviceUrl = SERVICE_INTERFACE + docid;
            Future<Response> responseFuture = asyncHttpClient.prepareGet(serviceUrl).execute();
            Response response = responseFuture.get();
            String responseStr = response.getResponseBody();
            if (Strings.isNullOrEmpty(responseStr)) {
                log.error("Execute explore re-tag microvideo write service " + serviceUrl + " exception");
                return;
            }

            JsonNode jsonResult = JacksonUtil.getJsonObject(responseStr);
            String status = jsonResult.get("status").asText();
            if (!"success".equalsIgnoreCase(status)) {
                log.error(serviceUrl + " response status exception:" + status);
                return;
            }
            LogManager.TAG.info("Retag micro video: " + video.toString());
            AlreadyRetagVideoCache.putIfNotContain(docid, video);
            metrics.qps("model2newsVideoExplore_return_retag_microvideo_success");

            AtomicInteger beforeWrite = RetagVideoCounterCache.getInstance().getMicroVideoCounter();
            if (beforeWrite.intValue() >= ApolloConfigUtil.getInstance().getRetagExploreMicroVideoCount()) {
                needRetagMicroVideo = false;
                return;
            }
            int incBeforeWrite = beforeWrite.intValue() + 1;
            RetagVideoCounterCache.getInstance().setMicroVideoCounter(incBeforeWrite);
        } catch (Exception e) {
            log.error("Write re-tag micro video " + video.toString() + " exception:", e);
        }
    }

    public static void writeRetagUgcVideo(DocumentFeature ugcVideo) {
        try {
            String docid = ugcVideo.getDocid();
            if (AlreadyRetagVideoCache.contain(docid)) {
                return;
            }
            String serviceUrl = UGC_SERVICE_INTERFACE + docid;
            Future<Response> responseFuture = asyncHttpClient.prepareGet(serviceUrl).execute();
            Response response = responseFuture.get();
            String responseStr = response.getResponseBody();
            if (Strings.isNullOrEmpty(responseStr)) {
                log.error("Execute explore re-tag write service " + serviceUrl + " exception");
                return;
            }

            JsonNode jsonResult = JacksonUtil.getJsonObject(responseStr);
            String status = jsonResult.get("status").asText();
            if (!"success".equalsIgnoreCase(status)) {
                log.error(serviceUrl + " response status exception:" + status);
                return;
            }
            LogManager.TAG.info("Retag ugc microvideo: " + ugcVideo.toString());
            AlreadyRetagVideoCache.putIfNotContain(docid, ugcVideo);
            metrics.qps("model2newsVideoExplore_return_retag_ugc_video_success");

            AtomicInteger beforeWrite = RetagVideoCounterCache.getInstance().getMicroVideoCounter();
            if (beforeWrite.intValue() >= ApolloConfigUtil.getInstance().getRetagExploreMicroVideoCount()) {
                needRetagMicroVideo = false;
                return;
            }
            int incBeforeWrite = beforeWrite.intValue() + 1;
            RetagVideoCounterCache.getInstance().setMicroVideoCounter(incBeforeWrite);
        } catch (Exception e) {
            log.error("Write re-tag ugc video " + ugcVideo.toString() + " exception:", e);
        }
    }

    public static void main(String[] args) {
        System.out.println(VideoRetagUtil.needRetagVideo());
        needRetagVideo = false;
        System.out.println(VideoRetagUtil.needRetagVideo());
        VideoRetagUtil.reset();
        System.out.println(VideoRetagUtil.needRetagVideo());
    }
}
