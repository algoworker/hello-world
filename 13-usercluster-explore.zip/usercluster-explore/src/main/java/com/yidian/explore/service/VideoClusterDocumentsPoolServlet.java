package com.yidian.explore.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.cache.NewsDocumentCache;
import com.yidian.explore.core.ClusterDocumentsPool;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import lombok.extern.log4j.Log4j;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.*;

@Log4j
public class VideoClusterDocumentsPoolServlet extends HttpServlet {
    private static final SimpleMetrics metrics = Metrics.simple();
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        String poolName = request.getParameter("pool");
        String micro = request.getParameter("micro");
        String detail = request.getParameter("detail");
        String sort = request.getParameter("sort");
        String ctr = request.getParameter("ctr");
        int count = Integer.parseInt(com.google.common.base.Optional.fromNullable(request.getParameter("count")).or("1000"));

        Map<String, Object> resultMap = Maps.newLinkedHashMap();
        resultMap.put("status", "success");
        resultMap.put("code", 0);

        List<Map<String, Object>> poolVideoList = Lists.newArrayList();
        resultMap.put("docs", poolVideoList);

        /* ClusterDocumentsPool List
         * 1.m2nMicroVideo
         * 2.mcnVideoExplore
         * 3.ugcVideoExplore
         * 4.douyinVideoExplore
         * 5.momoVideoExplore
         * 6.blenderBackupMicroVideo(blender补底池,不要改动)
         */
        if (poolName == null) {
            HttpUtil.setResponse(response, gson.toJson(resultMap));
            log.error("Request pool name parameter error");
            return;
        }

        boolean debug = false;
        if (detail != null) {
            debug = Boolean.valueOf(detail);
        }

        int resultCount = 0;
        ClusterDocumentsPool clusterDocumentsPool = new ClusterDocumentsPool();
        List<DocumentInfo> clusterDocumentsPoolVideoInfo = Lists.newArrayList();

        try {
            if ("m2nMicroVideo".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getModel2newsMicroVideoExploitPool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
                clusterDocumentsPoolVideoInfo.sort(DocumentInfo.m2nMicroVideoDocumentInfoComparator);
            } else if ("mcnVideoExplore".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getMcnVideoExplorePool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
                Collections.shuffle(clusterDocumentsPoolVideoInfo);
            } else if ("ugcVideoExplore".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getUgcVideoExplorePool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
                clusterDocumentsPoolVideoInfo.sort(DocumentInfo.ugcDocumentInfoComparator);
            } else if ("douyinVideoExplore".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getDouyinVideoExplorePool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
                Collections.shuffle(clusterDocumentsPoolVideoInfo);
            } else if ("momoVideoExplore".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getMomoVideoExplorePool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
                Collections.shuffle(clusterDocumentsPoolVideoInfo);
            } else if ("blenderBackupMicroVideo".equals(poolName)) {
                clusterDocumentsPoolVideoInfo.addAll(exploreExploitVideoPools.getModel2newsMicroVideoExploitPool().getDocumentInfoMap().values());
                clusterDocumentsPoolVideoInfo.sort(DocumentInfo.m2nMicroVideoDocumentInfoComparator);
                List<DocumentInfo> ugcVideoExplorePool = Lists.newArrayList();
                ugcVideoExplorePool.addAll(exploreExploitVideoPools.getUgcVideoExplorePool().getDocumentInfoMap().values());
                ugcVideoExplorePool.sort(DocumentInfo.ugcDocumentInfoComparator);
                for (int i = 0; i < ugcVideoExplorePool.size(); i++) {
                    DocumentInfo video = ugcVideoExplorePool.get(i);
                    if (video.getTier() != 3) {
                        continue;
                    }
                    clusterDocumentsPoolVideoInfo.add(video);
                }
            } else if ("allInVideoPool".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getAllInVideoPool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
            } else if ("boostViewVideoExploitPool".equals(poolName)) {
                clusterDocumentsPool = exploreExploitVideoPools.getBoostViewVideoExploitPool();
                clusterDocumentsPoolVideoInfo.addAll(clusterDocumentsPool.getDocumentInfoMap().values());
            }

            if (debug) {
                resultMap.put("cid", clusterDocumentsPool.getCid());
                resultMap.put("clicks", clusterDocumentsPool.getClicks());
                resultMap.put("views", clusterDocumentsPool.getViews());
                resultMap.put("videoCount", clusterDocumentsPool.getDocumentInfoMap().size());
            }

            if (sort != null) {
                if (Objects.equals(sort, "clicks")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getClicks)
                            .thenComparing(DocumentInfo::getViews)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                } else if (Objects.equals(sort, "views")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getViews)
                            .thenComparing(DocumentInfo::getClicks)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                } else if (Objects.equals(sort, "date")) {
                    clusterDocumentsPoolVideoInfo.sort((o1, o2) -> {
                        if (o1.getDate().before(o2.getDate())) {
                            return -1;
                        }
                        return 1;
                    });
                } else if (Objects.equals(sort, "thumbUps")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getThumbUps)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                } else if (Objects.equals(sort, "shareDocs")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getShareDocs)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                } else if (Objects.equals(sort, "likes")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getLikes)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                } else if (Objects.equals(sort, "comments")) {
                    Comparator<DocumentInfo> comparator = Comparator.comparing(DocumentInfo::getComments)
                            .thenComparing(DocumentInfo::getDate).reversed();
                    clusterDocumentsPoolVideoInfo.sort(comparator);
                }
            }

            Map<String, NewsDocument> newsDocumentMap = new HashMap<>();
            if (ctr != null && Objects.equals(ctr, "true") || "boostViewVideoExploitPool".equals(poolName)){
                Set<String> docids = new HashSet<>();
                for (DocumentInfo documentInfo : clusterDocumentsPoolVideoInfo) {
                    docids.add(documentInfo.getDocid());
                }
                newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(docids);
            }

            for (DocumentInfo documentInfo : clusterDocumentsPoolVideoInfo) {
                Map<String, Object> videoInfo = Maps.newHashMap();
                String docid = documentInfo.getDocid();
                videoInfo.put("docid", docid);
                videoInfo.put("title", documentInfo.getTitleWords());
                videoInfo.put("score", documentInfo.getBaseScore());

                if (debug) {
                    videoInfo.put("date", documentInfo.getDate());
                    videoInfo.put("refer", documentInfo.getRefer());
                    videoInfo.put("micro", documentInfo.isMicro());
                    videoInfo.put("passAudit", documentInfo.isPassAudit());
                    videoInfo.put("tier", documentInfo.getTier());
                    videoInfo.put("clicks", documentInfo.getClicks());
                    videoInfo.put("views", documentInfo.getViews());
                    videoInfo.put("thumbUps", documentInfo.getThumbUps());
                    videoInfo.put("shareDocs", documentInfo.getShareDocs());
                    videoInfo.put("likes", documentInfo.getLikes());
                    videoInfo.put("comments", documentInfo.getComments());
                    videoInfo.put("source", documentInfo.getSource());
                    videoInfo.put("url", String.format("http://www.yidianzixun.com/%s", docid));
                    if (ctr != null && Objects.equals(ctr, "true") && newsDocumentMap.containsKey(docid)) {
                        NewsDocument newsDocument = newsDocumentMap.get(docid);
                        videoInfo.put("ctr", newsDocument.getGlobalCTR().or(0.0));
                    }
                    if ("boostViewVideoExploitPool".equals(poolName)) {
                        NewsDocument newsDocument = newsDocumentMap.get(docid);
                        if (newsDocument != null) {
                            videoInfo.put("globalCtr", newsDocument.getGlobalCTR().or(0.0));
                            videoInfo.put("globalView", newsDocument.getGlobalView());
                            videoInfo.put("vct", newsDocument.getCategory());
                        }
                    }
                }

                // knn explore views filter
                if ("knnVideoExplore".equals(poolName) && documentInfo.getViews() > 300) {
                    continue;
                }
                poolVideoList.add(videoInfo);
            }

            if (debug) {
                resultMap.put("docs", poolVideoList);
                resultCount = poolVideoList.size();
            } else {
                resultMap.put("docs", poolVideoList.subList(0, Math.min(count, poolVideoList.size())));
                resultCount = Math.min(count, poolVideoList.size());
            }
        } catch (Exception e) {
            log.error(MessageFormat.format("Servlet process request {0} exception:", request.getQueryString()), e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        HttpUtil.setResponse(response, gson.toJson(resultMap));
        log.info("ACCESS:" + request.getQueryString() + " micro video count: " + resultCount);

        String cid = clusterDocumentsPool.getCid();
        String metricPrefix = "videoExploreClusterPool_" + cid;
        metrics.qps(metricPrefix + "_access");
        long latency = System.currentTimeMillis() - startTime;
        metrics.latency(metricPrefix + "_process", latency);
        metrics.ratio(metricPrefix + "_empty_result", resultCount == 0);
        metrics.count(metricPrefix + "_result_size", resultCount);
    }
}
