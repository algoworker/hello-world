package com.yidian.explore.service;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.utils.KnnParameterUtil;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public class NotifyServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(NotifyServlet.class);
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String column = request.getParameter("column");
        String type = request.getParameter("type");

        Map<String, Object> retMap = Maps.newHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);

        // 更新user2explore线上模型
        try {
            KnnParameterUtil.getInstance().refresh(type + "_online_parameters");
            retMap.put("column", column);
        } catch (Exception e) {
            logger.error("Update knn online model exception:", e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        HttpUtil.setResponse(response, gson.toJson(retMap));
    }
}
