package com.yidian.explore.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import lombok.extern.log4j.Log4j;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

@Log4j
public class VideoPoolAppendServlet extends HttpServlet {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        String docids = request.getParameter("docids");
        String docFile = request.getParameter("docFile");
        if (docids != null && docFile != null) {
            HttpUtil.sendFailed(response, "video list input parameter conflict");
            return;
        }

        List<String> videoList = Lists.newArrayList();
        if (docids != null) {
            String[] docs = docids.trim().split(",");
            videoList.addAll(Arrays.asList(docs));
        } else if (docFile != null) {
            try {
                videoList.addAll(Files.readAllLines(Paths.get(docFile)));
            } catch (IOException e) {
                log.error("Fail to read a document file ", e);
            }
        } else {
            HttpUtil.sendFailed(response, "missing video list input parameter");
            return;
        }

        Map<String, Object> retMap = Maps.newHashMap();
        List<NewsDocument> newsDocuments = DocumentDataDAO.getInstance().getDocuments(videoList);
        videoList.clear();
        for (NewsDocument nd : newsDocuments) {
            videoList.add(nd.getDocid());
        }
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (NewsDocument nd : newsDocuments) {
            String refer = nd.getSource().equals("一点UGC") ? "ugc" : "mcn";
            DocumentFeature documentFeature = new DocumentFeature(nd.getDocid(), nd.getSegTitle(), nd.getSource(), simpleFormat.format(nd.getDate()), refer);
            documentFeature.setSig(nd.getSignature());
            documentFeature.setTier(nd.getDocAuthority().or(0));
            documentFeature.setKeywords(nd.getKeywords());
            exploreExploitPools.addDocument(documentFeature);
        }

        retMap.put("result", videoList);
        retMap.put("status", "success");
        retMap.put("code", 0);

        HttpUtil.setResponse(response, gson.toJson(retMap));
    }
}
