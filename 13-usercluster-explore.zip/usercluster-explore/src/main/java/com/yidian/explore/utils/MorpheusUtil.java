package com.yidian.explore.utils;

import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.ClusterDocumentsPool;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.text.MessageFormat;

public class MorpheusUtil {
    private static Logger logger = Logger.getLogger(MorpheusUtil.class);

    public static void morpheusPoolCleaner(String key) {
        MorphuesClient mc = MorphuesClient.getInstance(ExploreExploitConfig.defaultConfig().getDatastoreName());
        try {
            mc.delete(key, "a");
            logger.info("Morpheus explore&exploit video pool " + key + " has been cleaned now.");
        } catch (Exception e) {
            logger.error("Clean morpheus table exception:", e);
        }
    }

    /**
     * 程序启动时,将morpheus中的ClusterDocumentsPool加载到内存
     * @param clusterDocumentsPool:video pool
     * @param key:morpheus key
     * @param column:morpheus column
     */
    public static void loadClusterDocumentsPoolFromMorpheus(ClusterDocumentsPool clusterDocumentsPool, String key, String column) {
        String loadMorpheusInfoLog = "Load {0} videos for {1} from morpheus successfully";
        String loadMorpheusErrorLog = "Load {0} from morpheus exception:";
        MorphuesClient mc = MorphuesClient.getInstance(ExploreExploitConfig.defaultConfig().getDatastoreName());
        ObjectMapper mapper = new ObjectMapper();
        byte[] data = mc.read(key, column);
        if (data != null && data.length != 0) {
            String val = new String(data);
            try {
                JsonNode root = mapper.readTree(val);
                clusterDocumentsPool.deserialize(root);
                logger.info(MessageFormat.format(loadMorpheusInfoLog, clusterDocumentsPool.getDocumentInfoMap().size(), clusterDocumentsPool.getCid()));
            } catch (IOException e) {
                logger.error(MessageFormat.format(loadMorpheusErrorLog, clusterDocumentsPool.getCid()), e);
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Start to clean pool in morpheus.");
        // TODO 服务重构后删除"global_exploit_pool"这个key
        MorpheusUtil.morpheusPoolCleaner("global_exploit_pool");
        MorpheusUtil.morpheusPoolCleaner("model2news_mcnmicrovideo_explore_pool");
        MorpheusUtil.morpheusPoolCleaner("model2news_ugcmicrovideo_explore_pool");
        System.out.println("Finish to clean pool in morpheus.");
    }
}
