package com.yidian.explore.utils.convertor;

import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

@Deprecated
public class LongConfigObjectConverter implements IConfigObjectConvertor<Long> {
    @Override
    public Long convert(String value) {
        return Long.parseLong(value);
    }
}
