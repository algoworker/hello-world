package com.yidian.explore.service;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.compare_key.*;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.ExploreExploitPools;
import com.yidian.explore.core.ExploreExploitVideoPools;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public class ClusterDebugServlet extends HttpServlet {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static ExploreExploitPools exploreExploitPools = ExploreExploitPools.getInstance();
    private static ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        String collectionPool = request.getParameter("collectionPool");
        String cid = request.getParameter("cid");
        String documentsPool = request.getParameter("documentsPool");
        String topnString = request.getParameter("topn");
        String rankBy = request.getParameter("rankBy");

        if (collectionPool == null) {
            HttpUtil.sendFailed(response, "have no collectionPool");
            return;
        }
        if (documentsPool == null) {
            HttpUtil.sendFailed(response, "have no documentsPool");
            return;
        }
        int topn = 200;
        if (topnString != null) {
            topn = Integer.parseInt(topnString);
        }
        if (cid == null) {
            HttpUtil.sendFailed(response, "have no cid");
            return;
        }
        if (rankBy == null) {
            rankBy = "ucb";
        }
        CompareKey ck = new CompareClicks();
        if (rankBy.equals("ucb")) {
            ck = null;  // new CompareUCBScore();
        } else if (rankBy.equals("baseScore")) {
            ck = new CompareBaseScore();
        } else if (rankBy.equals("views")) {
            ck = new CompareViews();
        } else if (rankBy.equals("clicks")) {
            ck = new CompareClicks();
        }

        Map<String, Object> retMap = Maps.newHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);
        if (ExploreExploitConfig.defaultConfig().getEnv().equals("video")) {
            retMap.put("result", exploreExploitVideoPools.getDebugInfo(collectionPool, cid, documentsPool, topn, ck));
        } else {
            retMap.put("result", exploreExploitPools.getDebugInfo(collectionPool, cid, documentsPool, topn, ck));
        }
        HttpUtil.setResponse(response, gson.toJson(retMap));
    }
}
