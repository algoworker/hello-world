package com.yidian.explore.merger;

import com.yidian.explore.core.DocumentInfo;

import java.util.List;

public interface DocumentsMerger {
    List<DocumentInfo> merge(List<List<DocumentInfo>> documentsLst);
}
