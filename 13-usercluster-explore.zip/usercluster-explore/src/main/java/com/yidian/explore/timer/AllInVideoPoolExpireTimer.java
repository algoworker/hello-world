package com.yidian.explore.timer;

import com.yidian.explore.cache.ExploreEfficiencyCache;
import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.explore.constant.LogManager;
import lombok.extern.log4j.Log4j;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * AllInVideoPool定时expire任务
 * @author Created by xin on 2019/01/17 16:50.
 * @version 服务启动后的下一个整点开始执行 1h执行一次 找出入库24h之后需要扩大分发的视频
 */
@Log4j
public class AllInVideoPoolExpireTimer {
    private long period = 1000L * 60 * 60;  // execute once 60 min
    private static volatile AllInVideoPoolExpireTimer instance = null;

    public static AllInVideoPoolExpireTimer getInstance() {
        if (instance == null) {
            synchronized (AllInVideoPoolExpireTimer.class) {
                if (instance == null) {
                    instance = new AllInVideoPoolExpireTimer();
                }
            }
        }
        return instance;
    }

    private AllInVideoPoolExpireTimer() {
        long delay = getTimerDelay();  // 1000L * 60 * 10
        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ExploreEfficiencyCache.getInstance().effectiveExploreMetrics();  // 借用定时job打点
                ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
                LogManager.EXPIRE.info("Start AllInVideoPool expire task at " + new Date(System.currentTimeMillis()).toString());
                exploreExploitVideoPools.allInVideoPoolExpire();
                Date next = new Date(System.currentTimeMillis() + period);
                LogManager.EXPIRE.info("Next AllInVideoPool expire task will be executed at " + next.toString());
            }
        }, delay, period);
    }

    private long getTimerDelay() {
        try {
            Date now = new Date();
            Calendar currentTime = Calendar.getInstance();
            currentTime.setTime(now);
            int currentHour = currentTime.get(Calendar.HOUR);
            currentTime.set(Calendar.HOUR, currentHour + 1);
            currentTime.set(Calendar.MINUTE, 0);
            currentTime.set(Calendar.SECOND, 0);
            currentTime.set(Calendar.MILLISECOND, 0);

            Date nextHour = currentTime.getTime();
            return nextHour.getTime() - now.getTime();
        } catch (Exception e) {
            log.error("Get AllInVideoPoolExpireTimer delay exception:", e);
        }
        return 1000L * 60 * 10;
    }
}
