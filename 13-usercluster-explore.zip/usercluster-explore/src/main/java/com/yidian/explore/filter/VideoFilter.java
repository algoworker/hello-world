package com.yidian.explore.filter;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hipu.util.TokenUtil;
import com.yidian.explore.cache.AlreadyRetagVideoCache;
import com.yidian.explore.cache.ExploreInsertVideoCache;
import com.yidian.explore.constant.MetricsNameEnum;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.VideoFeature;
import com.yidian.explore.constant.LogManager;
import com.yidian.explore.utils.ApolloConfigUtil;
import com.yidian.explore.utils.LoadConfigFile;
import com.yidian.explore.utils.MonMetricsUtil;
import com.yidian.serving.index.metrics.Metrics;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.CoreConnectionPNames;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoFilter implements DocumentFilter {
    private static HttpClient client;
    private static ObjectMapper mapper = new ObjectMapper();
    private static volatile VideoFilter instance = null;

    private int nonChineseTitleVCount = 0;
    private int iqiyiExploreVCount = 0;
    private int scopeExceptionVCount = 0;
    private int repeatedInsertVCount = 0;
    private int passAuditVCount = 0;
    private int nativeVCount = 0;
    private int minuteDurationVCount = 0;
    private int scLocalVCount = 0;
    private int longTimeVCount = 0;
    private int emptyKeywordListVCount = 0;
    private int emptyYdTagsVCount = 0;
    private int microVCount = 0;
    private int scDirtyVCount = 0;
    private int lowSourceTierVCount = 0;
    private int specialTagsVCount = 0;
    private int vivoToutiaoVCount = 0;
    private int dailyBeforeFilterVCount = 0;
    private int dailyAfterFilterVCount = 0;

    private static final String VIDEO_DETAIL = "{0},docid={1},title={2},source={3},date={4}";

    static {
        PoolingClientConnectionManager connectionManager = new PoolingClientConnectionManager();
        connectionManager.setMaxTotal(100);
        connectionManager.setDefaultMaxPerRoute(100);
        client = new DefaultHttpClient(connectionManager);
        client.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5 * 10);
        client.getParams().setIntParameter(CoreConnectionPNames.SO_TIMEOUT, 150);
    }

    public static VideoFilter getInstance() {
        if (instance == null) {
            synchronized (VideoFilter.class) {
                if (instance == null) {
                    instance = new VideoFilter();
                }
            }
        }
        return instance;
    }

    private VideoFilter() {

    }

    public void filterCounterReset() {
        this.nonChineseTitleVCount = 0;
        this.iqiyiExploreVCount = 0;
        this.scopeExceptionVCount = 0;
        this.repeatedInsertVCount = 0;
        this.passAuditVCount = 0;
        this.nativeVCount = 0;
        this.minuteDurationVCount = 0;
        this.scLocalVCount = 0;
        this.longTimeVCount = 0;
        this.emptyKeywordListVCount = 0;
        this.emptyYdTagsVCount = 0;
        this.microVCount = 0;
        this.scDirtyVCount = 0;
        this.lowSourceTierVCount = 0;
        this.specialTagsVCount = 0;
        this.vivoToutiaoVCount = 0;
        this.dailyBeforeFilterVCount = 0;
        this.dailyAfterFilterVCount = 0;
    }

    private Map<String, Double> getKeywords(JsonNode root) {
        List<List<Object>> keywordList = Lists.newArrayList();
        for (int i = 0; i < root.size(); i++) {
            JsonNode one = root.get(i);
            List<Object> lst = Lists.newArrayList();
            if (one.size() != 2) {
                continue;
            }
            try {
                lst.add(one.get(0).asText());
                lst.add(one.get(1).asDouble());
            } catch (Exception e) {
                LogManager.COLLECT.warn("Video keywords extraction exception:", e);
                continue;
            }
            keywordList.add(lst);
        }

        Map<String, Double> keywords = Maps.newHashMap();
        double max = 0d;
        for (List<Object> obj : keywordList) {
            if (obj.size() == 2) {
                Number val = (Number) obj.get(1);
                max = Math.max(max, val.doubleValue());
            }
        }
        if (max > 1e-8) {
            for (List<Object> obj : keywordList) {
                if (obj.size() == 2) {
                    String key = TokenUtil.token((String) obj.get(0));
                    Number val = (Number) obj.get(1);
                    keywords.put(key, val.doubleValue() / max);
                }
            }
        }
        return keywords;
    }

    private List<String> getVideoTags(JsonNode root) {
        List<String> ydTags = new ArrayList<>();
        if (root.isNull() || root.size() == 0) {
            return ydTags;
        }
        for (int i = 0; i < root.size(); i++) {
            JsonNode tag = root.get(i);
            try {
                String videoTag = tag.asText();
                if ("".equals(videoTag) || videoTag.startsWith("评级_") || videoTag.startsWith("时效性_")) {
                    continue;
                }
                ydTags.add(videoTag);
            } catch (Exception e) {
                LogManager.COLLECT.warn("Video tags extraction exception:", e);
            }
        }
        return ydTags;
    }

    private List<String> getVideoCategory(JsonNode root) {
        List<String> videoCategory = new ArrayList<>();
        if (root.isNull() || root.size() == 0) {
            return videoCategory;
        }
        try {
            String vct = getOrDefault(root, "vct", null);
            videoCategory.add(vct);
        } catch (Exception e) {
            LogManager.COLLECT.warn("Video category extraction exception:", e);
        }
        return videoCategory;
    }

    private List<String> getVideoSubcategory(JsonNode root) {
        List<String> videoSubcategory = new ArrayList<>();
        if (root.isNull() || root.size() == 0) {
            return videoSubcategory;
        }
        try {
            String vsct = getOrDefault(root, "vsct", null);
            videoSubcategory.add(vsct);
        } catch (Exception e) {
            LogManager.COLLECT.warn("Video subcategory extraction exception:", e);
        }
        return videoSubcategory;
    }

    private boolean isMicro(JsonNode root) {
        if (root.isNull() || root.size() == 0) {
            return false;
        }
        try {
            String vHeight = getOrDefault(root, "v_height", null);
            String vWidth = getOrDefault(root, "v_width", null);
            return (vHeight != null && vWidth != null) && (Integer.parseInt(vWidth) < Integer.parseInt(vHeight));
        } catch (Exception e) {
            LogManager.COLLECT.warn("Video cover size extraction exception:", e);
        }
        return false;
    }

    private static String getOrDefault(JsonNode root, String field, String def) {
        if (root.has(field)) {
            return root.get(field).getValueAsText();
        }
        return def;
    }

    @Override
    public Optional<DocumentFeature> filter(String data) {
        try {
            JsonNode root = mapper.readTree(data);
            String docid = getOrDefault(root, "_id", "null");
            if (!docid.startsWith("V_")) {
                return Optional.empty();
            }

            this.dailyBeforeFilterVCount++;
            MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.beforeFilter, this.dailyBeforeFilterVCount);

            String segTitle = getOrDefault(root, "seg_title", "null");
            boolean chineseTitle = isChineseTitle(segTitle);
            if (!chineseTitle) {
                this.nonChineseTitleVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.nonChineseTitleVideo, this.nonChineseTitleVCount);
            }

            String source = getOrDefault(root, "source", "null");
            boolean iqiyiSource = ApolloConfigUtil.getInstance().getIqiyiExploreSource().contains(source);
            if (iqiyiSource) {
                this.iqiyiExploreVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.iqiyiExploreVideo, this.iqiyiExploreVCount);
            }

            String date = getOrDefault(root, "date", "null");  // date是原始发文时间
            if (LoadConfigFile.getInstance().getExploreSourceACTrie().contains(source)) {
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "inferior source filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            if (AlreadyRetagVideoCache.contain(docid) || ExploreInsertVideoCache.contain(docid)) {
                this.repeatedInsertVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.repeatedInsertVideo, this.repeatedInsertVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "repeated insert filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            String scope = getOrDefault(root, "scope", "-1");
            if (Integer.parseInt(scope) != -1) {
                this.scopeExceptionVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.scopeExceptionVideo, this.scopeExceptionVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "insert scope filter", docid, segTitle, source, date) + ",scope=" + scope);
                return Optional.empty();
            }

            String scDirty = getOrDefault(root, "sc_dirty", "0");
            if (Double.valueOf(scDirty) >= 0.999) {
                this.scDirtyVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.scDirtyVideo, this.scDirtyVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "sc_dirty filter", docid, segTitle, source, date) + ",sc_dirty=" + scDirty);
                return Optional.empty();
            }

            String sourceTier = getOrDefault(root, "source_tier", "6");
            if (Integer.parseInt(sourceTier) <= ApolloConfigUtil.getInstance().getSourceTierFilter()) {
                this.lowSourceTierVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.lowSourceTierVideo, this.lowSourceTierVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "source tier filter", docid, segTitle, source, date) + ",source_tier=" + sourceTier);
                return Optional.empty();
            }

            String passAudit = getOrDefault(root, "pass_audit", "null");  // 默认pass_audit=null,免审视频pass_audit=true,不存在pass_audit=false
            if ("true".equals(passAudit)) {
                this.passAuditVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.passAuditVideo, this.passAuditVCount);
            }
            boolean apolloExplorePassAudit = ApolloConfigUtil.getInstance().getExplorePassAuditVideo();
            if (passAudit.equals("true") && !apolloExplorePassAudit) {
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "pass_audit filter", docid, segTitle, source, date));
                return Optional.empty();
            }
            if (passAudit.equals("true") && !isChineseTitle(segTitle)) {
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "crawled non-Chinese title filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            String beNative = getOrDefault(root, "b_native", "null");
            if (beNative.equals("true")) {
                this.nativeVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.nativeVideo, this.nativeVCount);
            }
            if ((!beNative.equals("true")) && (!ApolloConfigUtil.getInstance().getIqiyiExploreSource().contains(source))) {
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "b_native filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            String duration = getOrDefault(root, "duration", "0");
            if (Integer.parseInt(duration) < 60) {
                this.minuteDurationVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.minuteDurationVideo, this.minuteDurationVCount);
            }

            String scLocal = getOrDefault(root, "sc_local", "0.0");
            if (Double.parseDouble(scLocal) > 0.9) {
                this.scLocalVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.scLocalVideo, this.scLocalVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "local title filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            String storageTime = getOrDefault(root, "insert_time", "null");  // insert_time是入库时间
            Date now = new Date();
            Date insertTime = str2date(storageTime);
            long deltCPP = now.getTime() - insertTime.getTime();
            Metrics.simple().latency("kafkaVideoCollect_time_delta", deltCPP / 1000);

            Date pubTime = str2date(date);
            long delt = now.getTime() - pubTime.getTime();
            int minutes = (int) (delt / (1000 * 60));
            if (minutes > 4320) {
                this.longTimeVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.longTimeVideo, this.longTimeVCount);
                LogManager.COLLECT.info(MessageFormat.format(VIDEO_DETAIL, "long time filter", docid, segTitle, source, date));
                return Optional.empty();
            }

            String wmTier = getOrDefault(root, "wm_tier", "0");

            Map<String, Double> keywords = Maps.newHashMap();
            if (root.has("keyword_list")) {
                keywords = getKeywords(root.get("keyword_list"));
            }
            if (keywords.isEmpty()) {
                this.emptyKeywordListVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.emptyKeywordListVideo, this.emptyKeywordListVCount);
            }

            List<String> videoTags = new ArrayList<>();
            if (root.has("tags_yd")) {
                videoTags = getVideoTags(root.get("tags_yd"));
            }
            if (videoTags.isEmpty()) {
                this.emptyYdTagsVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.emptyYdTagsVideo, this.emptyYdTagsVCount);
            } else {
                if (videoTags.contains("特殊_低俗") || videoTags.contains("特殊_血腥") || videoTags.contains("特殊_重口味")) {
                    this.specialTagsVCount++;
                    MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.specialTagsVideo, this.specialTagsVCount);
                    return Optional.empty();
                }
            }

            List<String> videoCategory = new ArrayList<>();
            if (root.has("vct")) {
                videoCategory = getVideoCategory(root);
            }

            List<String> videoSubcategory = new ArrayList<>();
            if (root.has("vsct")) {
                videoSubcategory = getVideoSubcategory(root);
            }

            boolean micro = isMicro(root);
            if (micro) {
                this.microVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.microVideo, this.microVCount);
            }

            String from = getOrDefault(root, "from", "yidianzixun");
            String expandFrom = getOrDefault(root, "expand_from", "yidianzixun");
            if ("vivo_toutiao".equals(expandFrom)) {
                this.vivoToutiaoVCount++;
                MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.vivoToutiaoVideo, this.vivoToutiaoVCount);
                from += "_vivo_toutiao";
            }

            VideoFeature videoFeature = new VideoFeature(docid, segTitle, source, storageTime, "pipline");
            videoFeature.setTier(Integer.parseInt(wmTier));
            videoFeature.setDuration(Integer.parseInt(duration));
            videoFeature.setMicro(micro);
            videoFeature.setPassAudit(passAudit.equals("true"));
            videoFeature.setKeywords(keywords);
            videoFeature.setFrom(from);
            videoFeature.setVideoTags(videoTags);
            videoFeature.setVideoCategory(videoCategory);
            videoFeature.setVideoSubcategory(videoSubcategory);

            this.dailyAfterFilterVCount++;
            MonMetricsUtil.mean(MonMetricsUtil.MetricsPrefixEnum.KAFKA_VIDEO_COLLECT, MetricsNameEnum.afterFilter, this.dailyAfterFilterVCount);
            ExploreInsertVideoCache.put(docid, videoFeature);
            return Optional.of(videoFeature);
        } catch (Exception e) {
            LogManager.COLLECT.error("Kafka video collect log parse error:" + data);
        }
        return Optional.empty();
    }

    private Date str2date(String str) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        try {
            date = simpleFormat.parse(str);
        } catch (ParseException e) {
            LogManager.COLLECT.error("Parse date format from String to Date exception:", e);
        }
        return date;
    }

    private static boolean isChineseTitle(String str) {
        Pattern pat = Pattern.compile("[\u4e00-\u9fa5]");
        Matcher mat = pat.matcher(str);
        return mat.find();
    }

    public static void main(String[] args) {
        String title = "【 johnny orlando 】 waste my time mv";
        VideoFilter.isChineseTitle(title);
    }
}
