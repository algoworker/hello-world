package com.yidian.explore.dao;

import com.google.protobuf.InvalidProtocolBufferException;
import com.yidian.cfvectorestore.utils.GZipUtils;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.utils.MorphuesClient;
import yidian.data.usercf.UserVector;

import java.io.IOException;

public class UserVectorDao {
    private static volatile UserVectorDao instance = null;

    public static UserVectorDao getInstance() {
        if (instance == null) {
            synchronized (UserVectorDao.class) {
                if (instance == null) {
                    instance = new UserVectorDao();
                }
            }
        }
        return instance;
    }

    public UserVector getUserVector(String userid, String column) {
        byte[] bytes = MorphuesClient.getInstance(Constants.USERVECTORVIDEO_KNN).read(userid, column);
        UserVector userVector = null;
        try {
            userVector = UserVector.parseFrom(GZipUtils.decompress(bytes));
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return userVector;
    }
}
