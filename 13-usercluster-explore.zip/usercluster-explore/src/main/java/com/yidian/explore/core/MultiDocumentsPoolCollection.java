package com.yidian.explore.core;

import com.yidian.explore.compare_key.CompareKey;

import java.util.List;
import java.util.Map;

public interface MultiDocumentsPoolCollection {
    boolean loadCollections();

    boolean dumpCollections();

    List<DocumentInfo> fetch(String cid, int topn);

    List<DocumentInfo> fetch(String cid, int topn, CompareKey ck);

    boolean addDocument(String poolName, DocumentFeature doc);

    boolean model2newsAddDocument(String poolName, DocumentFeature doc);

    boolean addDocumentInfo(String cid, String poolName, DocumentInfo documentInfo);

    DocumentInfo removeDocumentInfo(String cid, String poolName, String dodid);

    boolean updateStatus(String uid, String cid, String docid, String event);

    boolean model2newsUpdateStatus(String uid, String cid, String docid, String event);

    Map<String, Map<String, List<DocumentInfo>>> expire();

    Map<String, Map<String, List<DocumentInfo>>> model2newsExpire();

    Map<String, Object> getDebugInfo(String cid, String documentsPool, int topn, CompareKey ck);

    boolean fakeCollections();

    boolean embedFrameVector();

    boolean model2newsFakeCollections();

    Map<String, DocumentInfo> getClusterDocumentInfos(String cid, String documentsPool);
}
