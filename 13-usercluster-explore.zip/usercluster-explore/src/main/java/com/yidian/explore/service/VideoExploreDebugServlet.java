package com.yidian.explore.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.explore.dao.MorphiaMongoDao;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class VideoExploreDebugServlet extends HttpServlet {
    private static final Logger log = Logger.getLogger(VideoExploreDebugServlet.class);
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String docid = request.getParameter("docid");
        String source = request.getParameter("source");
        String date = request.getParameter("date");

        Map<String, Object> resultMap = Maps.newLinkedHashMap();
        resultMap.put("status", "success");
        resultMap.put("code", 0);

        List<Object> mongoVideoList = Lists.newArrayList();
        if (docid == null && source == null) {
            HttpUtil.sendFailedWithCode(response, "either parameter docid or parameter source is required", 10);
        }
        if (source != null && date == null) {
            HttpUtil.sendFailedWithCode(response, "both parameter source and parameter date is required", 10);
        }

        try {
            if (docid != null && docid.startsWith("V_")) {
                Optional<DocumentInfo> documentInfo = MorphiaMongoDao.getInstance().readByDocid(docid);
                if (documentInfo.isPresent()) {
                    mongoVideoList.add(documentInfo.get());
                    resultMap.put("docs", mongoVideoList);
                } else {
                    HttpUtil.sendFailedWithCode(response, "read video " + docid + " from mongo exception", 11);
                }
            }
            if (source != null && date != null) {
                if (!date.contains("-")) {
                    HttpUtil.sendFailedWithCode(response, "required date format is yyyy-MM-dd", 10);
                }
                int clicks = 0;
                int views = 0;
                List<DocumentInfo> documentInfos = MorphiaMongoDao.getInstance().readBySource(source, date);
                for (DocumentInfo documentInfo : documentInfos) {
                    clicks += documentInfo.getClicks();
                    views += documentInfo.getViews();
                }
                resultMap.put("clicks", clicks);
                resultMap.put("views", views);
                mongoVideoList.addAll(documentInfos);
                resultMap.put("docs", mongoVideoList);
            }
        } catch (Exception e) {
            log.error("Read data from mongo exception:", e);
            HttpUtil.sendFailedWithCode(response, "Read data from mongo exception", 12);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        HttpUtil.setResponse(response, gson.toJson(resultMap));
    }
}
