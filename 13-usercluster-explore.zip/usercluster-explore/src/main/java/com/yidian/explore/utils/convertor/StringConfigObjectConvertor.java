package com.yidian.explore.utils.convertor;

import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

@Deprecated
public class StringConfigObjectConvertor implements IConfigObjectConvertor<String> {
    @Override
    public String convert(String value) {
        return value;
    }
}
