package com.yidian.explore.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.yidian.explore.core.DocumentFeature;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class ExploreEfficiencyCache {
    private static volatile ExploreEfficiencyCache instance = null;
    private static final SimpleMetrics metrics = Metrics.simple();

    private volatile Cache<String, DocumentFeature> insertVideoCache = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .recordStats()
            .build();

    private volatile Cache<String, DocumentInfo> expireVideoCache = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .recordStats()
            .build();

    public static ExploreEfficiencyCache getInstance() {
        if (instance == null) {
            synchronized (ExploreEfficiencyCache.class) {
                if (instance == null) {
                    instance = new ExploreEfficiencyCache();
                }
            }
        }
        return instance;
    }

    private ExploreEfficiencyCache() {

    }

    public void addInsertVideo(String docid, DocumentFeature video) {
        this.insertVideoCache.put(docid, video);
    }

    public void addExpireVideo(String docid, DocumentInfo video) {
        this.expireVideoCache.put(docid, video);
    }

    public int effectiveExploreVideoCount() {
        Set<String> hourInsertVideoSet = this.insertVideoCache.asMap().keySet();
        Set<String> hourExpireVideoSet = this.expireVideoCache.asMap().keySet();
        Set<String> hourEffectiveExploreSet = new HashSet<>();
        hourEffectiveExploreSet.addAll(hourInsertVideoSet);
        hourEffectiveExploreSet.retainAll(hourExpireVideoSet);
        return hourEffectiveExploreSet.size();
    }

    public void effectiveExploreMetrics() {
        try {
            metrics.count("model2explore_hourly_insert_video_num", this.insertVideoCache.size());
            metrics.count("model2explore_hourly_expire_video_num", this.expireVideoCache.size());
            metrics.count("model2explore_hourly_effective_explore_video_num", effectiveExploreVideoCount());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}