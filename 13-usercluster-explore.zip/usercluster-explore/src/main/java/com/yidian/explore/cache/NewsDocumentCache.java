package com.yidian.explore.cache;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.CacheStats;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import lombok.extern.log4j.Log4j;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

@Log4j
public class NewsDocumentCache {
    private static volatile NewsDocumentCache instance = null;
    private static final int RETRY_MAX_CNT = 3;

    private volatile LoadingCache<String, Optional<NewsDocument>> cache = CacheBuilder.newBuilder()
            .maximumSize(100000)
            .expireAfterAccess(1, TimeUnit.HOURS)
            .recordStats()
            .build(new CacheLoader<String, Optional<NewsDocument>>() {
                @Override
                public Optional<NewsDocument> load(String key) throws Exception {
                    int retryCnt = 0;
                    while (retryCnt < RETRY_MAX_CNT) {
                        try {
                            com.google.common.base.Optional<NewsDocument> ndOpt = DocumentDataDAO.getInstance().getDocumentOpt(key);
                            if (ndOpt.isPresent()) {
                                return Optional.of(ndOpt.get());
                            }
                        } catch (NumberFormatException e) {
                            log.error("Get news document from NewsDocumentDAO exception:" + key, e);
                        }
                        retryCnt++;
                    }
                    return Optional.empty();
                }
            });

    public static NewsDocumentCache defaultInstance() {
        if (instance == null) {
            synchronized (NewsDocumentCache.class) {
                if (instance == null) {
                    instance = new NewsDocumentCache();
                }
            }
        }
        return instance;
    }

    private NewsDocumentCache() {

    }

    public Optional<NewsDocument> get(String docid) {
        try {
            return cache.get(docid);
        } catch (ExecutionException e) {
            log.error("NewsDocumentCache extract news document exception:" + docid, e);
        }
        return Optional.empty();
    }

    public Map<String, NewsDocument> getAll(Collection<String> docids) {
        Map<String, NewsDocument> result = Maps.newHashMap();
        if (docids == null || docids.isEmpty()) {
            return result;
        }
        List<String> docList = Lists.newArrayList(docids);
        List<List<String>> docPartitions = Lists.partition(docList, 1000);

        docPartitions.forEach(list -> {
            try {
                for (Map.Entry<String, Optional<NewsDocument>> entry : cache.getAll(list).entrySet()) {
                    if (entry.getValue().isPresent()) {
                        result.put(entry.getKey(), entry.getValue().get());
                    }
                }
            } catch (ExecutionException e) {
                log.error("NewsDocumentCache extract news document exception:" + list.toString(), e);
            }
        });
        return result;
    }

    public Map<String, Object> getCacheStats() {
        CacheStats stats = cache.stats();
        Map<String, Object> result = Maps.newHashMap();
        result.put("newsDocumentCacheStats", stats.toString());
        result.put("avgLoadPenalty", stats.averageLoadPenalty());
        result.put("hitRate", stats.hitRate());
        result.put("missRate", stats.missRate());
        result.put("size", cache.size());
        return result;
    }
}
