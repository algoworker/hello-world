package com.yidian.explore.service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.cache.ExploreInferiorVideoCache;
import com.yidian.explore.core.DocumentInfo;
import lombok.extern.log4j.Log4j;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Log4j
public class ExploreInferiorVideoServlet extends HttpServlet {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String cacheName = request.getParameter("cacheName");
        if (cacheName == null) {
            HttpUtil.sendFailed(response, "cacheName is required");
            return;
        }
        int count = Integer.parseInt(com.google.common.base.Optional.fromNullable(request.getParameter("count")).or("1000"));

        Map<String, Object> resultMap = Maps.newLinkedHashMap();
        resultMap.put("status", "success");
        resultMap.put("code", 0);

        List<Map<String, Object>> resultList = Lists.newArrayList();
        resultMap.put("docs", resultList);

        try {
            Map<String, DocumentInfo> exploreInferiorVideoMap = ExploreInferiorVideoCache.getInstance().getAllExploreInferiorVideo();
            if (exploreInferiorVideoMap == null || exploreInferiorVideoMap.isEmpty()) {
                HttpUtil.sendFailed(response, "return zero explore inferior video");
                return;
            }
            for (Map.Entry<String, DocumentInfo> video : exploreInferiorVideoMap.entrySet()) {
                Map<String, Object> inferiorVideo = Maps.newHashMap();
                inferiorVideo.put("docid", video.getKey());
                inferiorVideo.put("source", video.getValue().getSource());
                inferiorVideo.put("tier", video.getValue().getTier());
                inferiorVideo.put("title", video.getValue().getTitleWords());
                inferiorVideo.put("insertTime", video.getValue().getDate());
                inferiorVideo.put("expireTime", video.getValue().getExpireTime());
                inferiorVideo.put("exploreScore", video.getValue().getBaseScore());
                inferiorVideo.put("exploreClicks", video.getValue().getClicks());
                inferiorVideo.put("exploreViews", video.getValue().getViews());
                resultList.add(inferiorVideo);
            }

            resultMap.put("docs", resultList.subList(0, Math.min(count, resultList.size())));
        } catch (Exception e) {
            log.error("extract inferior video from inferiorVideoCache exception:", e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        HttpUtil.setResponse(response, gson.toJson(resultMap));
    }
}