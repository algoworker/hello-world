package com.yidian.explore.service;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.core.ExploreExploitVideoPools;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public class VideoClusterCacheServlet extends HttpServlet {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String op = request.getParameter("op");
        String cacheName = request.getParameter("cacheName");

        if (op == null || cacheName == null) {
            HttpUtil.sendFailed(response, "op and cacheName is required!");
            return;
        }

        Map<String, Object> retMap = Maps.newHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);

        if (op.equals("stat")) {
            retMap.put("result", exploreExploitVideoPools.getCacheStat(cacheName));
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        HttpUtil.setResponse(response, gson.toJson(retMap));
    }
}