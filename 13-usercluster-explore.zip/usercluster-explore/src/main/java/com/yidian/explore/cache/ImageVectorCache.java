package com.yidian.explore.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.yidian.explore.utils.VideoVectorMorpheusFetcher;

import java.util.concurrent.TimeUnit;

public class ImageVectorCache {
    private static volatile ImageVectorCache instance = null;

    private volatile Cache<String, float[]> frameVectorCache = CacheBuilder.newBuilder()
            .maximumSize(2000000)
            .expireAfterAccess(3, TimeUnit.HOURS)
            .recordStats()
            .build();

    private volatile Cache<String, float[]> coverVectorCache = CacheBuilder.newBuilder()
            .maximumSize(2000000)
            .expireAfterAccess(3, TimeUnit.HOURS)
            .recordStats()
            .build();

    public static ImageVectorCache getInstance() {
        if (instance == null) {
            synchronized (ImageVectorCache.class) {
                if (instance == null) {
                    instance = new ImageVectorCache();
                }
            }
        }
        return instance;
    }

    private ImageVectorCache() {

    }

    public float[] getFrameVector(String docid) {
        if (frameVectorCache.getIfPresent(docid) != null) {
            return frameVectorCache.getIfPresent(docid);
        }
        String videoConfigName = VideoVectorMorpheusFetcher.CONFIG_PREFIX + VideoVectorMorpheusFetcher.TABLE_NAME_VIDEO_VECTOR;
        float[] frameVector = VideoVectorMorpheusFetcher.getInstance(videoConfigName).getVideoVector(docid);
        if (frameVector != null && frameVector.length != 0) {
            addFrameVector(docid, frameVector);
        }
        return frameVector;
    }

    public void addFrameVector(String docid, float[] imageVec) {
        frameVectorCache.put(docid, imageVec);
    }

    public long size() {
        return Math.max(instance.frameVectorCache.size(), instance.coverVectorCache.size());
    }
}