package com.yidian.explore.utils;

import com.yidian.explore.config.ExploreExploitConfig;
import org.apache.log4j.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

/**
 * Created by fuliangliang on 16/10/26.
 */
public class MailSender {
    private static final Logger Log = Logger.getLogger(MailSender.class);
    private static volatile MailSender instance = null;
    private Session session;
    private String hostname = "c3-a02-136-11-10.yidian.com";

    private MailSender() {
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("mail.smtp.host", ExploreExploitConfig.defaultConfig().getSmtpHost());
        session = Session.getDefaultInstance(properties);
        try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            Log.error("The hostname cannot be resolved", e);
            Log.error(StringTools.LogExceptionStack(e));
        }
    }

    public static MailSender getInstance() {
        if (instance == null) {
            synchronized (MailSender.class) {
                if (instance == null) {
                    instance = new MailSender();
                }
            }
        }
        return instance;
    }

    public void sendMail(String from, String[] toArray, String subject, String content) {
        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            for (String to : toArray) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            }

            // Set Subject: header field
            message.setSubject(subject);

            // Now set the actual message
            message.setText(content);

            // Send message
            Transport.send(message);
        } catch (MessagingException mex) {
            mex.printStackTrace();
            Log.error(StringTools.LogExceptionStack(mex));
        }
    }

    public static void main(String[] args) {
        MailSender mailSender = MailSender.getInstance();
        mailSender.sendMail("clusterExploreExploit@yidian-inc.com", new String[]{"xinfeixiang@yidian-inc.com"}, "test", "test");
    }
}