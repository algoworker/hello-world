package com.yidian.explore.utils;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.CacheStats;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Maps;
import com.yidian.explore.cache.ImageVectorCache;
import com.yidian.explore.cache.NewsDocumentCache;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.VideoFeature;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import lombok.Getter;
import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;

import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;


/**
 * Created by admin on 17/4/12.
 */
public class VideoEmbedding {
    private static final Logger log = Logger.getLogger(VideoEmbedding.class);

    private static String word_blacklist = "爆笑 搞笑 趣图 gif 笑趣图 内涵图 囧 笑话 笑抽 内涵趣 动态图 动图 笑死 内涵图 内涵集锦 无节操 段子 糗事 福利 恶搞 恶作剧 坑爹";
    private static Map<String, Integer> word_blacklist_map = new HashMap<>();

    private static String stopwords = "。。。 ... 「 」 + - — # . ： : 丨 【 】 、 的 了 是 着 在 ， , ! ！ “ ” 《 》 ( ) … ? ？ % \" ' 1 2 3 4 5 6 7 8 9 10 / | … !";
    private static Map<String, Integer> stopwords_map = new HashMap<>();

    @Getter
    private VecInfo word_vec_info = new VecInfo();

    private volatile LoadingCache<String, Optional<float[]>> videoVectorCache = CacheBuilder.newBuilder()
            .maximumSize(100000)
            .expireAfterAccess(3, TimeUnit.HOURS)
            .recordStats()
            .build(new CacheLoader<String, Optional<float[]>>() {
                @Override
                public Optional<float[]> load(String key) throws Exception {
                    Optional<NewsDocument> ndOpt = NewsDocumentCache.defaultInstance().get(key);
                    if (ndOpt.isPresent()) {
                        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String videoConfigName = VideoVectorMorpheusFetcher.CONFIG_PREFIX + VideoVectorMorpheusFetcher.TABLE_NAME_VIDEO_VECTOR;
                        NewsDocument nd = ndOpt.get();
                        VideoFeature videoFeature = new VideoFeature(nd.getDocid(), nd.getSegTitle(), nd.getSource(), simpleFormat.format(nd.getDate()), "pipline");
                        videoFeature.setTier(nd.getDocAuthority().or(0));
                        videoFeature.setSig(nd.getSignature());
                        videoFeature.setKeywords(nd.getKeywords());
                        videoFeature.setVideoCategory(nd.getVideoCategory());
                        videoFeature.setVideoSubcategory(nd.getVideoSubcategory());
                        videoFeature.setVideoTags(nd.getYDTags());
                        float[] frameVec = VideoVectorMorpheusFetcher.getInstance(videoConfigName).getVideoVector(nd.getDocid());

                        float[] videoVec = VideoEmbedding.defaultInstance().getVideoVector(videoFeature, frameVec);
                        if (videoVec != null && videoVec.length != 0) {
                            return Optional.of(videoVec);
                        }
                    }
                    return Optional.empty();
                }
            });

    private static volatile VideoEmbedding instance;
    public static VideoEmbedding defaultInstance() {
        if (instance == null) {
            synchronized (VideoEmbedding.class) {
                if (instance == null) {
                    instance = new VideoEmbedding();
                }
            }
        }
        return instance;
    }

    static class VecInfo {
        int num;
        int size;
        HashMap<String, float[]> vec;
    }

    static {
        for (String str : word_blacklist.split(" ")) {
            if (str.length() > 0) {
                word_blacklist_map.put(str, 1);
            }
        }

        for (String str : stopwords.split(" ")) {
            if (str.length() > 0) {
                stopwords_map.put(str, 1);
            }
        }
    }

    private VideoEmbedding() {
        init(ExploreExploitConfig.defaultConfig().getWordVecFile());
        // init(ExploreExploitConfig.defaultConfig().getDebugWordVecFile());  // local debug
    }

    public static String getSegTitleWords(String segTitle) {
        StringBuilder sb = new StringBuilder();
        for (char ch : segTitle.toCharArray()) {
            if (stopwords_map.containsKey(String.valueOf(ch))) {
                continue;
            }
            if (ch == ' ') {
                continue;
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    private static boolean isNumeric(String str) {
        return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
    }

    private ArrayList<String> getVideoFeature(VideoFeature video) {
        ArrayList<String> feature_list = new ArrayList<>();

        if (video == null) {
            return feature_list;
        }

        String title = video.getSeg_title();
        if (title == null) {
            return feature_list;
        }
        String[] stitle = title.split(" ");

        List<Map.Entry<String, Double>> keywords_list = new ArrayList<Map.Entry<String, Double>>(video.getKeywords().entrySet());
        Collections.sort(keywords_list, new Comparator<Map.Entry<String, Double>>() {
            public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        boolean is_filter = false;
        for (String token : stitle) {
            if (word_blacklist_map.containsKey(token)) {
                is_filter = true;
                break;
            }
            if (stopwords_map.containsKey(token)) {
                continue;
            }
            if (!feature_list.contains(token)) {
                feature_list.add(token);
            }
        }

         feature_list.add("src_" + video.getSource());

        List<String> ydtags = video.getVideoTags();
        if (ydtags != null) {
            ydtags.forEach(tag -> {
                if (tag.length() > 0) {
                    feature_list.add("tg_" + tag);
                }
            });
        }

        int kws_num = 0;
        for (Map.Entry<String, Double> keywords_score : keywords_list) {
            String kws = keywords_score.getKey();
            if (kws.contains("^^")) {
                continue;
            }
            if (kws_num++ >= 10) {
                break;
            }
            if (!feature_list.contains(kws)) {
                feature_list.add(kws);
            }
        }

        try {
            List<String> catList = video.getVideoCategory();
            for (String cat : catList) {
                feature_list.add("ct_" + cat);
            }
        } catch (Exception e) {
            log.warn("Does not to load video category into feature list");
        }

        try {
            List<String> subcatList = video.getVideoSubcategory();
            if (is_filter) {
                feature_list.add("vct_" + subcatList);
            }
        } catch (Exception e) {
            log.warn("Does not to load video subcategory into feature list");
        }

        return feature_list;
    }

    public float[] getVideoVector(VideoFeature video, float[] video_vec) {
        if (video == null) {
            return null;
        }

        ArrayList<String> feature_list = getVideoFeature(video);
        if (feature_list.size() == 0) {
            return null;
        }

        float[] vector = new float[word_vec_info.size];
        for (String feature : feature_list) {
            if (isNumeric(feature)) {
                continue;
            }
            float[] feature_vec = word_vec_info.vec.get(feature);
            if (feature_vec == null) {
                continue;
            }
            for (int i = 0; i < word_vec_info.size; ++i) {
                if (Float.isNaN(feature_vec[i])) {
                    return null;
                }
                vector[i] += feature_vec[i];
            }
        }

        if (video_vec != null) {
            // log.info("Success to load video vector of video: " + video.docid);
            for (int i = 0; i < word_vec_info.size; ++i) {
                vector[i] += video_vec[i];
            }
        }

        double len = 0.0;
        for (int i = 0; i < word_vec_info.size; ++i) {
            len += vector[i] * vector[i];
        }

        if (len <= 0) {
            return null;
        }

        len = Math.sqrt(len);

        for (int i = 0; i < word_vec_info.size; ++i) {
            vector[i] = (float) ((double) vector[i] / len);
        }
        return vector;
    }

    public float[] getVideoVectorFromCacheById(String docid) {
        try {
            Optional<float[]> vecOpt = videoVectorCache.get(docid);
            if (vecOpt.isPresent()) {
                return vecOpt.get();
            }
        } catch (ExecutionException e) {
            log.error("error: " + e + " docid: " + docid);
            e.printStackTrace();
        }
        return null;
    }

    public float[] getVideoVectorFromCacheByVf(VideoFeature videoFeature) {
        if (videoFeature == null) {
            return null;
        }
        String docid = videoFeature.getDocid();
        Optional<float[]> vecOpt = videoVectorCache.getIfPresent(docid);
        if (vecOpt != null && vecOpt.isPresent()) {
            return vecOpt.get();
        }

        try {
            vecOpt = videoVectorCache.get(docid, () -> {
                float[] fvec = ImageVectorCache.getInstance().getFrameVector(docid);
                if (fvec == null) {
                    String videoConfigName = VideoVectorMorpheusFetcher.CONFIG_PREFIX + VideoVectorMorpheusFetcher.TABLE_NAME_VIDEO_VECTOR;
                    fvec = VideoVectorMorpheusFetcher.getInstance(videoConfigName).getVideoVector(docid);
                }

                float[] vvec = getVideoVector(videoFeature, fvec);
                if (vvec != null) {
                    return Optional.of(vvec);
                } else {
                    return Optional.empty();
                }
            });
            if (vecOpt.isPresent()) {
                return vecOpt.get();
            }
        } catch (ExecutionException e) {
            log.error("get video vector error: " + e + " docid: " + videoFeature);
            e.printStackTrace();
        }
        return null;
    }

    public Map<String, Object> getCacheStats() {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        CacheStats stats = videoVectorCache.stats();
        ret.put("videoVectorCacheStats", stats.toString());
        ret.put("avgLoadPenalty", stats.averageLoadPenalty());
        ret.put("hitRate", stats.hitRate());
        ret.put("missRate", stats.missRate());
        ret.put("size", videoVectorCache.size());
        return ret;
    }

    public void init(String word_vec_file) {
        if (word_vec_file == null) {
            System.exit(-1);
        }
        try {
            log.info("load word vec:" + word_vec_file);
            loadVector(word_vec_file, word_vec_info);
            log.info("word vec loaded.");
        } catch (Exception e) {
            log.error(e);
            System.exit(-1);
        }

        if (word_vec_info.size == 0) {
            log.error("model formate error.");
            System.exit(-1);
        }
    }

    public void loadVector(String file_name, VecInfo vec_info) throws IOException {
        if (file_name == null || vec_info == null) {
            return;
        }

        DataInputStream dis = null;
        BufferedInputStream bis = null;

        float value;

        vec_info.num = 0;
        vec_info.size = 0;

        try {
            log.info("load vec from " + file_name);
            bis = new BufferedInputStream(new FileInputStream(file_name));
            dis = new DataInputStream(bis);

            vec_info.num = Integer.parseInt(readString(dis));
            log.info("num:" + vec_info.num);
            vec_info.size = Integer.parseInt(readString(dis));
            log.info("size:" + vec_info.size);

            vec_info.vec = new HashMap<>((int) (vec_info.num / 0.75 + 10));

            for (int i = 0; i < vec_info.num; ++i) {
                String id = readString(dis);
                float[] vec = new float[vec_info.size];

                for (int j = 0; j < vec_info.size; ++j) {
                    value = readFloat(dis);
                    vec[j] = value;
                }

                if (i % 10000 == 0) {
                    log.info("load line " + i + ":" + id);
                }

                vec_info.vec.put(id, vec);
                dis.read();
            }
        } catch (Exception e) {
            log.error(e);
        } finally {
            if (bis != null) {
                bis.close();
            }
            if (dis != null) {
                dis.close();
            }
        }
    }

    public void updateVector(Map<String, float[]> image_vecs) {
        image_vecs.forEach((k, v) -> {
            this.word_vec_info.vec.put(k, v);
            this.word_vec_info.num++;
        });
    }

    public static float readFloat(InputStream is) throws IOException {
        byte[] bytes = new byte[4];
        is.read(bytes);
        return getFloat(bytes);
    }

    public static float getFloat(byte[] b) {
        byte accum = 0;
        int accum1 = accum | (b[0] & 255) << 0;
        accum1 |= (b[1] & 255) << 8;
        accum1 |= (b[2] & 255) << 16;
        accum1 |= (b[3] & 255) << 24;
        return Float.intBitsToFloat(accum1);
    }

    private static String readString(DataInputStream dis) throws IOException {
        byte[] bytes = new byte[50];
        byte b = dis.readByte();
        int i = -1;
        StringBuilder sb = new StringBuilder();

        while (b != 32 && b != 10) {
            ++i;
            bytes[i] = b;
            b = dis.readByte();
            if (i == 49) {
                sb.append(new String(bytes));
                i = -1;
                bytes = new byte[50];
            }
        }

        sb.append(new String(bytes, 0, i + 1));
        return sb.toString();
    }

    public void clear_vec() {
        log.info("clear vec");
        word_vec_info.vec.clear();
        word_vec_info.num = 0;
        word_vec_info.size = 0;
    }

    // 向量归一化
    public float[] getUnitVector(float[] vec) {
        double len = 0;
        int i;
        for (i = 0; i < 256; ++i) {
            len += (double) (vec[i] * vec[i]);
        }
        len = Math.sqrt(len);

        for (i = 0; i < 256; ++i) {
            vec[i] = (float) ((double) vec[i] / len);
        }

        return vec;
    }

    // 计算两个向量的相似度
    public double getSim(float[] vec1, float[] vec2) {
        float sim = 0;
        for (int i = 0; i < 256; ++i) {
            sim += vec1[i] * vec2[i];
        }

        return sim;
    }

    public static void main(String[] args) {
        String testVideoId = "V_0185czF7";
        VideoEmbedding videoEmbedding = new VideoEmbedding();

        String videoIds = "V_0185czF7,V_0181HX70";
        List<String> docids = new ArrayList<>(Arrays.asList(videoIds.split(",")));

        Map<String, float[]> video_vectors = VideoVectorMorpheusFetcher.getInstance("usercf-morpheus-video_avg_feature").getVideoVectors(docids);
        float[] vector = video_vectors.get(testVideoId);

        Map<String, NewsDocument> documentMap = DocumentDataDAO.getInstance().getDocumentsMap(docids);
        NewsDocument newsDocument = documentMap.get(testVideoId);

        String seg_title = newsDocument.getSegTitle();
        String source = newsDocument.getSource();
        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = simpleFormat.format(newsDocument.getDate());
        String refer = "pipline";

        VideoFeature videoFeature = new VideoFeature(testVideoId, seg_title, source, date, refer);
        videoFeature.setTier(newsDocument.getDocAuthority().or(0));
        videoFeature.setSig(newsDocument.getSignature());
        videoFeature.setKeywords(newsDocument.getKeywords());
        videoFeature.setVideoCategory(newsDocument.getVideoCategory());
        videoFeature.setVideoSubcategory(newsDocument.getVideoSubcategory());
        videoFeature.setVideoTags(newsDocument.getYDTags());

        float[] videoVector = VideoEmbedding.defaultInstance().getVideoVector(videoFeature, null);

        System.out.println(vector);
        System.out.println(videoVector);
    }
}
