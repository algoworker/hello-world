package com.yidian.explore.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheStats;
import com.google.common.collect.Maps;
import com.yidian.explore.core.DocumentInfo;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @version 回收explore反馈回来的劣质视频
 * @date 2019-05-06 17:27
 */
public class ExploreInferiorVideoCache {
    private static volatile ExploreInferiorVideoCache instance = null;

    private volatile Cache<String, DocumentInfo> inferiorVideoCache = CacheBuilder.newBuilder()
            .maximumSize(100000)
            .expireAfterWrite(12, TimeUnit.HOURS)
            .recordStats()
            .build();

    public static ExploreInferiorVideoCache getInstance() {
        if (instance == null) {
            synchronized (ExploreInferiorVideoCache.class) {
                if (instance == null) {
                    instance = new ExploreInferiorVideoCache();
                }
            }
        }
        return instance;
    }

    private ExploreInferiorVideoCache() {

    }

    public void addExploreInferiorVideo(String docid, DocumentInfo video) {
        inferiorVideoCache.put(docid, video);
    }

    public Map<String, DocumentInfo> getAllExploreInferiorVideo() {
        return inferiorVideoCache.asMap();
    }

    public Map<String, Object> getCacheStats() {
        CacheStats stats = inferiorVideoCache.stats();
        Map<String, Object> result = Maps.newHashMap();
        result.put("inferiorVideoCache", stats.toString());
        result.put("avgLoadPenalty", stats.averageLoadPenalty());
        result.put("size", inferiorVideoCache.size());
        result.put("doc", inferiorVideoCache.asMap());
        return result;
    }
}
