package com.yidian.explore.utils;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.yidian.cfvectorestore.dao.MorphuesDao;
import lombok.Getter;
import lombok.Setter;
import morpheus.Nebuchadnezzar.Builder.IndexBuilder;
import morpheus.Nebuchadnezzar.Element;
import morpheus.Nebuchadnezzar.Index;
import morpheus.Nebuchadnezzar.Row;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.log4j.Logger;
import yidian.data.morpheus.smartclient.reader.MorpheusReader;
import yidian.data.usercf.UserVector;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by cjn on 17/5/4.
 */
public class VideoVectorMorpheusFetcher {
    private static Logger logger = Logger.getLogger(VideoVectorMorpheusFetcher.class);
    private static volatile Map<String, VideoVectorMorpheusFetcher> instances = new HashMap();
    private MorphuesDao morpheusDao = null;

    public static final String CONFIG_PREFIX = "usercf-morpheus-";
    public final static String TABLE_NAME_VIDEO_VECTOR = "video_avg_feature";

    private String version = null;
    private String tableName = null;
    private String contentType = null;

    @Setter
    @Getter
    private String columnName = null;
    private static MorpheusReader reader = null;

    @Getter
    private int dim = 0;

    private static final int RETRY_NUM = 5;

    private VideoVectorMorpheusFetcher(String configName) {
        try {
            Config usercfConfig = ConfigFactory.load().getConfig("usercluster-explore");

            if (usercfConfig == null || !usercfConfig.hasPath(configName)) {
                logger.error("Doesn't have video-explore config or video-explore config doesn't have " + configName + " configuration");
                throw new RuntimeException("Doesn't have video-explore config or video-explore config doesn't have " + configName + " configuration");
            }

            loadConfig(usercfConfig.getConfig(configName));

            if (tableName.equals("video_avg_feature") || tableName.equals("video_cover_feature")) {
                initMorpheusReader(usercfConfig.getConfig(configName));
            } else {
                morpheusDao = new MorphuesDao(usercfConfig.getConfig(configName), tableName);
            }
        } catch (Exception ex) {
            logger.error("Init MorpheusTools exception: " + ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    public void initMorpheusReader(Config config) throws IOException {
        if (reader != null) {
            return;
        }

        String zkHost = config.getString("zk.addr");
        String servingName = config.getString("serving.name");
        String metricNamePrefix = config.getString("metric.prefix");
        String tsdbHost = config.getString("tsdb.addr");
        if (config.hasPath("version")) {
            this.version = config.getString("version");
        }
        if (config.hasPath("dim")) {
            this.dim = config.getInt("dim");
        }

        reader = MorpheusReader.Builder.newBuilder(zkHost, servingName, metricNamePrefix)
                .allowKeepConnection(true)
                .withBorrowTimeout(1000)
                .withTimeout(10 * 1000)
                .withConnectionTtl(60000)
                .enableOpenTSDB()
                .disableParallel()
                .withOpenTSDBHost(tsdbHost)
                .build();

        reader.start();
    }

    private void loadConfig(Config config) {
        this.tableName = config.getString("table");
        this.columnName = config.getString("column");
        this.contentType = config.getString("type");

    }

    public static VideoVectorMorpheusFetcher getInstance(String table) {
        if (!instances.containsKey(table)) {
            synchronized (VideoVectorMorpheusFetcher.class) {
                if (!instances.containsKey(table)) {
                    instances.put(table, new VideoVectorMorpheusFetcher(table));
                }
            }
        }
        return instances.get(table);
    }

    public Map<String, float[]> getVideoVectors(List<String> keys) {
        List<Index> indexes = new ArrayList<>();
        Map<String, float[]> videoVectors = new HashMap<>();

        if (keys.isEmpty()) {
            return videoVectors;
        }

        // Build Indexes
        for (String key : keys) {
            Index index = IndexBuilder.newBuilder().setKey(key.getBytes()).build();
            List<ByteBuffer> bindexs = new ArrayList<>();
            // add column name
            bindexs.add(ByteBuffer.wrap(this.columnName.getBytes()));
            index.setIndexs(bindexs);
            indexes.add(index);
        }

        try {
            List<Row> result = this.reader.multiGet(tableName, indexes);
            indexes.clear();

            for (Row r : result) {
                if (r.getData() == null || r.getData().size() == 0) {
                    continue;
                }

                String strValues = new String(r.getData().get(0).getValue());

                if (strValues == null || strValues.isEmpty()) {
                    continue;
                }
                videoVectors.put(new String(r.getKey()), FormatUtils.string2floats(strValues));
            }
        } catch (Exception ex) {
            logger.error("Read a set of video content/cover vectors unsuccessfully from morpheus exception:", ex);
        }

        return videoVectors;
    }

    public float[] getVideoVector(String docid) {
        List<Index> indexes = new ArrayList<>();
        float[] vector = null;

        // Build Video Index
        Index index = IndexBuilder.newBuilder().setKey(docid.getBytes()).build();
        List<ByteBuffer> bindexs = new ArrayList<>();
        // add column name
        bindexs.add(ByteBuffer.wrap(this.columnName.getBytes()));
        index.setIndexs(bindexs);
        indexes.add(index);

        try {
            List<Row> result = this.reader.multiGet(tableName, indexes);
            indexes.clear();

            if (result == null || result.isEmpty()) {
                return vector;
            }

            Row r = result.get(0);
            if (r.getData() == null || r.getData().size() == 0) {
                return vector;
            }

            String strValues = new String(r.getData().get(0).getValue());
            if (strValues == null || strValues.isEmpty()) {
                return vector;
            }

            vector = FormatUtils.string2floats(strValues);
        } catch (Exception ex) {
            logger.error("Read video content/cover vector unsuccessfully in getVideoVector exception:", ex);
        }

        return vector;
    }

    public Map<String, float[]> getWordVectors(List<String> keys) {
        Map<String, float[]> ret = new HashMap<>();
        List<Index> indexes = new ArrayList<>();
        try {
            for (String key : keys) {
                if (this.version != null && !this.version.isEmpty()) {
                    key = key + "-v" + this.version;
                }
                Index index = IndexBuilder.newBuilder().setKey(key.getBytes()).build();
                indexes.add(index);
            }
            List<Row> result = this.reader.multiGet(tableName, indexes);
            indexes.clear();

            if (result.size() > 0) {
                for (Row r : result) {
                    String key = new String(r.getKey());
                    if (this.version != null && !this.version.isEmpty()) {
                        key = key.substring(0, key.length() - this.version.length() - 2);
                    }
                    for (Element e : r.getData()) {
                        String col = new String(e.getIndex());
                        if (col.equals(this.columnName)) {
                            float[] vector = FormatUtils.bytes2floats(e.getValue());
                            ret.put(key, vector);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public float[] extractVector(UserVector vector) {
        if (vector == null) {
            return new float[0];
        }
        int size = vector.getVecsCount();
        float[] vec = new float[size];

        int i;
        double len = 0;
        float value;
        for (i = 0; i < size; ++i) {
            value = vector.getVecs(i);
            vec[i] = value;
            len += (double) (value * value);
        }

        len = Math.sqrt(len);

        for (i = 0; i < size; ++i) {
            vec[i] = (float) ((double) vec[i] / len);
        }

        return vec;
    }

    public String write(String key, byte[] value, String column) {
        return morpheusDao.write(key, value, column);
    }

    public byte[] read(String key, String column) {
        byte[] result = null;
        int num = 0;
        while (result == null || result.length == 0) {
            result = morpheusDao.read(key, column);
            num++;
            if (num > RETRY_NUM) {
                break;
            }
        }
        return result;
    }

    public Map<String, byte[]> batchRead(List<Pair<String, String>> keyList) {
        return morpheusDao.batchRead(keyList);
    }

    public void delete(String key, String column) {
        morpheusDao.delete(key, column);
    }

    public static void main(String[] args) {
        String docid = "V_01JmzJMu";  // V_01JmzJMu有图像向量 V_01JBh13W没有图像向量
        float[] videoVector = VideoVectorMorpheusFetcher.getInstance("usercf-morpheus-video_avg_feature").getVideoVector(docid);
        System.out.println(videoVector.toString());
    }
}