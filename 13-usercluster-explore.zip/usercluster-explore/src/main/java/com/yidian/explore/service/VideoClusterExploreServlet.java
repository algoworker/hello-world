package com.yidian.explore.service;

import com.google.common.base.Optional;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.core.*;
import com.yidian.explore.dao.Userid2CidDao;
import com.yidian.explore.ranker.VideoRerankPerUser;
import com.yidian.explore.cache.NewsDocumentCache;
import com.yidian.explore.utils.StringTools;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class VideoClusterExploreServlet extends HttpServlet {
    private static final Logger Log = Logger.getLogger(VideoClusterExploreServlet.class);
    private static final SimpleMetrics metrics = Metrics.simple();
    private static IExplorePools videoExploreExploitPools = ExploreExploitPoolFactory.getExplorePool();
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        Stopwatch watch = Stopwatch.createStarted();

        String userid = request.getParameter("userid");
        int count = Integer.parseInt(Optional.fromNullable(request.getParameter("count")).or("10"));
        String debugInfo = Optional.fromNullable(request.getParameter("debug")).or("");
        String appid = request.getParameter("appid");

        boolean debug;
        if (debugInfo.equals("detail")) {
            debug = true;
        } else {
            debug = false;
        }

        Map<String, Object> resultMap = Maps.newLinkedHashMap();
        resultMap.put("status", "success");
        resultMap.put("code", 0);

        List<Map<String, Object>> resultList = Lists.newArrayList();
        resultMap.put("docs", resultList);
        if (userid == null) {
            HttpUtil.setResponse(response, gson.toJson(resultMap));
            return;
        }

        int resultCount = 0;
        try {
            List<DocumentInfo> exploreResult = videoExploreExploitPools.explore(userid, count, appid);
            if (exploreResult == null || exploreResult.isEmpty()) {
                Log.error(String.format("RETURN:userid=%s get empty explore result", userid));
            }

            List<String> docids = Lists.newArrayList();
            Map<String, NewsDocument> newsDocumentMap = Maps.newHashMap();
            if (debug) {
                List<String> cids = Userid2CidDao.defaultDAO().getCidLst(userid);
                resultMap.put("cids", cids);
                for (DocumentInfo documentInfo : exploreResult) {
                    docids.add(documentInfo.getDocid());
                }
                newsDocumentMap = NewsDocumentCache.defaultInstance().getAll(docids);
            }

            for (DocumentInfo documentInfo : exploreResult) {
                Map<String, Object> docInfo = Maps.newHashMap();
                docInfo.put("docid", documentInfo.getDocid());
                docInfo.put("score", documentInfo.getRankScore());

                if (debug) {
                    if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                        NewsDocument doc = newsDocumentMap.get(documentInfo.getDocid());
                        double dwell = doc.getDwellClickRate();
                        docInfo.put("title", doc.getTitle());
                        docInfo.put("source", doc.getSource());
                        docInfo.put("duration", doc.getDuration());
                        docInfo.put("dwell", dwell);
                        docInfo.put("date", documentInfo.getDate());
                        docInfo.put("refer", documentInfo.getRefer());
                        docInfo.put("baseScore", documentInfo.getBaseScore());
                        docInfo.put("clicks", documentInfo.getClicks());
                        docInfo.put("views", documentInfo.getViews());
                        docInfo.put("titleSimilarityScore", VideoRerankPerUser.getUserVideoSimScore(userid, documentInfo));
                    }
                }
                resultList.add(docInfo);
            }
            resultMap.put("docs", resultList);
            resultCount = resultList.size();
        } catch (Exception e) {
            Log.error("Error: " + e + " req: " + request.getQueryString() + " trace: " + StringTools.LogExceptionStack(e));
            e.printStackTrace();
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        HttpUtil.setResponse(response, gson.toJson(resultMap));

        String metricPrefix = "userclusterVideoExplore";
        metrics.qps(metricPrefix + "_access");
        metrics.latency(metricPrefix + "_process", System.currentTimeMillis() - startTime);
        metrics.ratio(metricPrefix + "_empty_result", resultCount == 0);
        metrics.count(metricPrefix + "_result_size", resultCount);
        Log.info("ACCESS:" + request.getQueryString() + " time elapse: " + watch.toString() + " video count: " + resultCount);
    }
}
