package com.yidian.explore.compare_key;

import com.yidian.explore.core.DocumentInfo;

public interface CompareKey {
    Number getCompareKey(DocumentInfo doc);
}
