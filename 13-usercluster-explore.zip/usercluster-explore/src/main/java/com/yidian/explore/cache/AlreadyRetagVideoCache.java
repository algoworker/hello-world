package com.yidian.explore.cache;

import com.google.common.cache.*;
import com.google.common.collect.Maps;
import lombok.extern.log4j.Log4j;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 暂存已经返回重新打标签的所有视频
 */
@Log4j
public class AlreadyRetagVideoCache {
    private static volatile Cache<String, Object> cache = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .expireAfterWrite(24, TimeUnit.HOURS)
            .recordStats()
            .build();

    private AlreadyRetagVideoCache() {

    }

    public static Object get(String docid) {
        return cache.getIfPresent(docid);
    }

    public static boolean contain(String docid) {
        return (cache.getIfPresent(docid) != null);
    }

    public static void putIfNotContain(String docid, Object object) {
        try {
            if (cache.getIfPresent(docid) == null) {
                cache.put(docid, object);
            }
        } catch (Exception e) {
            log.error("AlreadyRetagVideoCache put if not contain video exception: ", e);
        }
    }

    public static Map<String, Object> getCacheStats() {
        CacheStats stats = cache.stats();
        Map<String, Object> result = Maps.newHashMap();
        result.put("retagCache", stats.toString());
        result.put("avgLoadPenalty", stats.averageLoadPenalty());
        result.put("size", cache.size());
        result.put("video", cache.asMap());
        return result;
    }
}
