package com.yidian.explore.filter;

import com.yidian.explore.core.DocumentFeature;

import java.util.Optional;

public interface DocumentFilter {
    Optional<DocumentFeature> filter(String data);
}
