package com.yidian.explore.userstore;

import com.yidian.userstore.conf.UserConstants;
import com.yidian.userstore.data.UserRawData;
import com.yidian.userstore.util.DataTransFormer;
import lombok.extern.log4j.Log4j;
import yidian.data.profile.ChannelInfo;
import yidian.data.profile.TFeature;
import yidian.data.profile.TL2Entry;

import java.util.*;

@Log4j
public class UserProfileDao {
    private static volatile UserProfileDao instance = null;

    private static final String APP = "app";
    private static final String S3RD = "s3rd";
    private static final String THIRD_PARTY = "third-party";
    private static final String OPPOBROWSER = "oppobrowser";
    private static final String MIBROWSER = "mibrowser";
    private static final String VIVOBROWSER = "vivobrowser";
    private static final String HWBROWSER = "hwbrowser";

    private List<String> columns = new ArrayList<>();

    public static UserProfileDao getInstance() {
        if (instance == null) {
            synchronized (UserProfileDao.class) {
                if (instance == null) {
                    instance = new UserProfileDao();
                }
            }
        }
        return instance;
    }

    private UserProfileDao() {
        columns.add(UserConstants.PINNED_CHANNEL_COLUMN);  // pinnedChn
        columns.add(UserConstants.EXP_DLK_COLUMN); // expDislike
    }

    /**
     * 不同appid画像独立存储
     * app环境:yidian、xiaomi、oppo、yidianX等,以及sdk对接方式的app,例如leshi
     * browser环境:仅包含mibrowser和oppobrowser
     * s3rd环境:以api方式对接的app,包含vivobrowser、hwbrowser、s3rd_ysdaquan、s3rd_lecalendar等
     */
    private String getEnv(String appid) {
        if (appid == null) {
            return APP;
        }
        String env;
        if (OPPOBROWSER.equals(appid) || MIBROWSER.equals(appid)) {
            env = THIRD_PARTY;
        } else if (VIVOBROWSER.equals(appid) || HWBROWSER.equals(appid) || appid.startsWith(S3RD)) {
            env = S3RD;
        } else {
            env = APP;
        }
        return env;
    }

    public UserRawData getUserRawData(String userid, String appid) {
        String env = getEnv(appid);
        Map<String, TFeature> tFeatureMap = UserMorpheusDao4MultiEnv.getUserMorpheus(env).getTFeatureMap(userid, columns);
        UserRawData rawData = null;
        try {
            rawData = DataTransFormer.getUserRawData(tFeatureMap);
        } catch (Exception e) {
            log.error("Get appid=" + appid + ",userid=" + userid + " raw data exception:", e);
        }
        return rawData;
    }

    /**
     * get user pinned channels
     * createStatus=-1:预置
     * createStatus=0:主动创建
     * createStatus=2:订阅意愿一般的频道(如经天气卡片切换过的本地频道)
     * createStatus=9:强制预制的频(如双11、两会等临时上线一段时间的频道)
     * createStatus=10:用户批量导入的频道(如一点号的批量关注等)
     */
    public Set<String> getUserPinnedChannel(UserRawData rawData) {
        Set<String> pinnedChannel = new HashSet<>();
        if (rawData == null) {
            return pinnedChannel;
        }
        if (rawData.getPinnedChannel() != null) {
            List<ChannelInfo> channels = rawData.getPinnedChannel().getChannels();
            if (channels != null && !channels.isEmpty()) {
                for (int i = 0; i < channels.size(); i++) {
                    ChannelInfo channelInfo = channels.get(i);
                    if (channelInfo.getCreateStatus() == 0 && channelInfo.getType().equals("media")) {
                        pinnedChannel.add(channelInfo.getName());
                    }
                }
            }
        }
        return pinnedChannel;
    }

    /**
     * get user dislike sources
     */
    public Set<String> getUserDislikeSource(UserRawData rawData) {
        Set<String> dislikeSrc = new HashSet<>();
        if (rawData == null) {
            return dislikeSrc;
        }
        Map<String, TL2Entry> featuresMap = rawData.getTL2EntryMap();
        if (featuresMap.containsKey("dlk_exp_src")) {
            TL2Entry tl2Entry = rawData.getTL2EntryMap().get("dlk_exp_src");
            dislikeSrc.addAll(tl2Entry.getKey());
        }
        return dislikeSrc;
    }

    public static void main(String[] args) {
        String userid = "280688691";
        String appid = "yidian";
        UserRawData rawData = UserProfileDao.getInstance().getUserRawData(userid, appid);
        System.out.println(rawData);
    }
}
