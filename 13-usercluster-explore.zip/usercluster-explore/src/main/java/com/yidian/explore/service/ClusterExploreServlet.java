package com.yidian.explore.service;

import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.explore.core.ExploreExploitPoolFactory;
import com.yidian.explore.core.IExplorePools;
import com.yidian.explore.dao.Userid2CidDao;
import com.google.gson.Gson;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.serving.index.metrics.Metrics;
import lombok.extern.log4j.Log4j;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Log4j
@Deprecated
public class ClusterExploreServlet extends HttpServlet {
    private static IExplorePools exploreExploitPools = ExploreExploitPoolFactory.getExplorePool();
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        Stopwatch watch = Stopwatch.createStarted();

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");

        String metricPrefix = "usercluster_ee_clusterExploreServlet";
        String userid = request.getParameter("userid");
        String numStr = request.getParameter("num");
        String debugStr = request.getParameter("debug");

        int num = 5;
        if (numStr != null) {
            num = Integer.valueOf(numStr);
        }
        boolean debug = false;
        if (debugStr != null) {
            debug = Boolean.valueOf(debugStr);
        }

        Map<String, Object> retMap = Maps.newLinkedHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);

        List<DocumentInfo> exploreResult = exploreExploitPools.explore(userid, num, null);

        List<String> docids = Lists.newArrayList();
        Map<String, NewsDocument> newsDocumentMap = Maps.newHashMap();
        if (debug) {
            List<String> cids = Userid2CidDao.defaultDAO().getCidLst(userid);
            retMap.put("cids", cids);
            for (DocumentInfo documentInfo : exploreResult) {
                docids.add(documentInfo.getDocid());
            }
            newsDocumentMap = DocumentDataDAO.getInstance().getDocumentsMap(docids);
        }

        List<Map<String, Object>> retLst = Lists.newArrayList();
        for (DocumentInfo documentInfo : exploreResult) {
            Map<String, Object> tmp = Maps.newHashMap();
            tmp.put("docId", documentInfo.getDocid());
            tmp.put("score", documentInfo.getRankScore());
            if (debug) {
                if (newsDocumentMap.containsKey(documentInfo.getDocid())) {
                    NewsDocument nd = newsDocumentMap.get(documentInfo.getDocid());
                    tmp.put("title", nd.getTitle());
                    tmp.put("source", nd.getSource());
                }
            }
            retLst.add(tmp);
        }

        retMap.put("docs", retLst);
        HttpUtil.setResponse(response, gson.toJson(retMap));
        Metrics.simple().qps(metricPrefix + "_process");
        long latency = System.currentTimeMillis() - startTime;
        Metrics.simple().latency(metricPrefix + "_process", latency);
        log.info("ACCESS:" + request.getQueryString() + " time elapse: " + watch.toString());
    }
}
