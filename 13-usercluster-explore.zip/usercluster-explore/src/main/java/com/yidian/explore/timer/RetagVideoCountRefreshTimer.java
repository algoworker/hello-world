package com.yidian.explore.timer;

import com.yidian.explore.cache.RetagVideoCounterCache;
import com.yidian.explore.filter.VideoFilter;
import com.yidian.explore.utils.VideoRetagUtil;
import lombok.extern.log4j.Log4j;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Xin
 * @version 控制需要重新打标签的视频数, 每天00:10:00清零
 * @date 2019/07/27 10:50
 */
@Log4j
public class RetagVideoCountRefreshTimer {
    private static volatile RetagVideoCountRefreshTimer instance = null;
    private static final long ONE_DAY = 1000L * 60 * 60 * 24;

    public static RetagVideoCountRefreshTimer getInstance() {
        if (instance == null) {
            synchronized (RetagVideoCountRefreshTimer.class) {
                if (instance == null) {
                    instance = new RetagVideoCountRefreshTimer();
                }
            }
        }
        return instance;
    }

    private RetagVideoCountRefreshTimer() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 10);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        Date date = calendar.getTime(); // 每天0:01:00执行
        /** 如果第一次执行定时任务的时间小于当前的时间,此时要在第一次执行定时任务的时间加一天,以便此任务在下个时间点执行;
         *  如果不加一天,任务会立即执行
         */
        if (date.before(new Date())) {
            date = this.addDay(date, 1);
        }
        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                log.warn("Start to execute RetagVideoCountRefreshTimer timer task at " + new Date());
                RetagVideoCounterCache.getInstance().reset();
                log.warn("Start to execute VideoRetagUtil reset task at " + new Date());
                VideoRetagUtil.reset();
                log.warn("Start to execute VideoFilter counter reset task at " + new Date());
                VideoFilter.getInstance().filterCounterReset();
            }
        }, date, ONE_DAY);
    }

    // 增加或减少天数
    private Date addDay(Date date, int num) {
        Calendar startDT = Calendar.getInstance();
        startDT.setTime(date);
        startDT.add(Calendar.DAY_OF_MONTH, num);
        return startDT.getTime();
    }
}

