package com.yidian.explore.timer;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.explore.utils.VideoVectorMorpheusFetcher;
import lombok.extern.log4j.Log4j;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * 服务启动后获取一次explore pool中DocumentInfo对应的frameVector
 * Created by xin on 18/04/16 14:34.
 */
@Log4j
public class FrameVectorEmbedTimer {
    private static volatile FrameVectorEmbedTimer instance = null;

    public static volatile LoadingCache<String, Optional<float[]>> documentInfoFrameVectorCache = CacheBuilder.newBuilder()
            .maximumSize(50000)
            .expireAfterAccess(3, TimeUnit.MINUTES)
            .recordStats()
            .build(new CacheLoader<String, Optional<float[]>>() {
                @Override
                public java.util.Optional<float[]> load(String key) throws Exception {
                    try {
                        String videoConfigName = VideoVectorMorpheusFetcher.CONFIG_PREFIX + VideoVectorMorpheusFetcher.TABLE_NAME_VIDEO_VECTOR;
                        float[] frameVec = VideoVectorMorpheusFetcher.getInstance(videoConfigName).getVideoVector(key);
                        return java.util.Optional.ofNullable(frameVec);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return java.util.Optional.empty();
                }
            });

    private FrameVectorEmbedTimer() {
        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
                exploreExploitVideoPools.getVideoExplorePool().embedFrameVector();
                this.cancel();
                log.info(String.format("Embed %s documentInfoFrameVector for all clusters in total", documentInfoFrameVectorCache.size()));
                documentInfoFrameVectorCache.cleanUp();
            }
        }, 2000);
    }

    public static FrameVectorEmbedTimer getInstance() {
        if (instance == null) {
            synchronized (FrameVectorEmbedTimer.class) {
                if (instance == null) {
                    instance = new FrameVectorEmbedTimer();
                }
            }
        }
        return instance;
    }
}