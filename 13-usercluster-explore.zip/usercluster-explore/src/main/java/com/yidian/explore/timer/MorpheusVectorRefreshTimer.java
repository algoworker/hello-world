package com.yidian.explore.timer;

import com.yidian.explore.cache.CacheVideoFeature;
import com.yidian.explore.cache.ImageVectorCache;
import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.explore.utils.VideoVectorMorpheusFetcher;
import lombok.Getter;
import lombok.extern.log4j.Log4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 定期从morpheus中读取新计算完成的vectors
 * Created by xin on 17/12/02 10:54.
 */
@Log4j
public class MorpheusVectorRefreshTimer {
    private static final Logger logger = LoggerFactory.getLogger(MorpheusVectorRefreshTimer.class);
    // private volatile ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private static volatile MorpheusVectorRefreshTimer instance = null;

    @Getter
    private Map<String, CacheVideoFeature> morpheusVectors;

    public MorpheusVectorRefreshTimer() {
        morpheusVectors = new HashMap<>();

        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Map<String, CacheVideoFeature> result = LoadVectorsFromMorpheus();
                if (!result.isEmpty()) {
                    morpheusVectors = result;
                    ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
                    exploreExploitVideoPools.addVideo(morpheusVectors);
                    Date next = new Date(System.currentTimeMillis() + 1000 * 60 * 10);
                    logger.info("Next video vectors refresh task will be executed at " + next.toString());
                }
            }
        }, 1000 * 60 * 3, 1000 * 60 * 10);
    }

    public static MorpheusVectorRefreshTimer getInstance() {
        if (instance == null) {
            synchronized (MorpheusVectorRefreshTimer.class) {
                if (instance == null) {
                    instance = new MorpheusVectorRefreshTimer();
                }
            }
        }
        return instance;
    }

    private Map<String, CacheVideoFeature> LoadVectorsFromMorpheus() {
        Map<String, CacheVideoFeature> morpheusResult = new HashMap<>();
        Date now = new Date(System.currentTimeMillis());
        logger.info("Start to read video vectors from Morpheus at " + now.toString());

        try {
            if (ExploreExploitVideoPools.videoFeatureCache.isEmpty() || ExploreExploitVideoPools.videoFeatureCache == null) {
                return morpheusResult;
            }

            Set<String> keys = ExploreExploitVideoPools.videoFeatureCache.keySet();
            List<String> docids = new ArrayList<>();
            docids.addAll(keys);

            // 从morpheus中读取视频的前30帧向量
            String videoConfigName = VideoVectorMorpheusFetcher.CONFIG_PREFIX + VideoVectorMorpheusFetcher.TABLE_NAME_VIDEO_VECTOR;
            Map<String, float[]> frame_vectors = VideoVectorMorpheusFetcher.getInstance(videoConfigName).getVideoVectors(docids);
            if (frame_vectors != null && !frame_vectors.isEmpty()) {
                for (Map.Entry<String, float[]> video_vector : frame_vectors.entrySet()) {
                    String docid = video_vector.getKey();
                    float[] vector = video_vector.getValue();
                    ExploreExploitVideoPools.videoFeatureCache.get(docid).videoVector = vector;
                    ImageVectorCache.getInstance().addFrameVector(docid, vector);
                }
            }

            // 遍历更新结果 将找到video_vector或者cover_vector的元素使用 将survival_time超过3小时的元素使用
            Iterator<Map.Entry<String, CacheVideoFeature>> iterator = ExploreExploitVideoPools.videoFeatureCache.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, CacheVideoFeature> entry = iterator.next();
                String docid = entry.getKey();
                CacheVideoFeature cacheVideoFeature = entry.getValue();

                if (!docids.contains(docid)) {
                    continue;
                }
                if (cacheVideoFeature.videoVector == null && cacheVideoFeature.survivalTime < 180) {
                    ExploreExploitVideoPools.videoFeatureCache.get(docid).survivalTime += 10;
                } else {
                    morpheusResult.put(docid, cacheVideoFeature);
                    // iterator.remove();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Timed load video frame vectors from Morpheus unsuccessfully");
        }

        return morpheusResult;
    }

    public Map<String, CacheVideoFeature> get() {
        return this.morpheusVectors;
    }

    public static void main(String[] args) {
        Map<String, CacheVideoFeature> morpheusVectors = MorpheusVectorRefreshTimer.getInstance().getMorpheusVectors();
        ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
        exploreExploitVideoPools.addVideo(morpheusVectors);
        System.out.println("Done.");
    }
}