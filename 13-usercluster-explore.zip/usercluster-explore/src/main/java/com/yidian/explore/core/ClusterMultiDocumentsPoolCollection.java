package com.yidian.explore.core;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yidian.explore.cache.KeyValueCache;
import com.yidian.explore.compare_key.CompareKey;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.constant.LogManager;
import com.yidian.explore.dao.CentroidsDao;
import com.yidian.explore.marker.Marker;
import com.yidian.explore.marker.VectorDistanceMarker;
import com.yidian.explore.marker.VideoVectorDistanceMarker;
import com.yidian.explore.merger.DocumentsMerger;
import com.yidian.explore.merger.PriorityMerger;
import com.yidian.explore.utils.*;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Log4j
public class ClusterMultiDocumentsPoolCollection implements MultiDocumentsPoolCollection {
    private volatile ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
    private volatile Map<String, MultiDocumentsPool> poolMap = Maps.newHashMap();
    private Marker marker = new VectorDistanceMarker();
    private volatile MorphuesClient mc = MorphuesClient.getInstance("usercluster_explore_datastore");
    private String persistKey = "null";
    private DocumentsMerger merger = null;
    private ObjectMapper mapper = new ObjectMapper();

    public ClusterMultiDocumentsPoolCollection(String persistKey, DocumentsMerger merger) {
        this.persistKey = persistKey;
        this.merger = merger;
        if (ExploreExploitConfig.defaultConfig().getEnv().equals("video")) {
            marker = new VideoVectorDistanceMarker();
        }
    }

    @Override
    public boolean loadCollections() {
        readWriteLock.writeLock().lock();
        try {
            log.info("begin to load collections");
            byte[] data = mc.read(persistKey + "_cluster_ids", "a");
            String val = new String(data);
            String[] parts = val.split(",");
            for (String cid : parts) {
                if (CentroidsDao.defaultDAO().getVecByCid(cid) == null && (!Constants.MODEL2NEWS.equals(cid) && !Constants.FEEDBACK_RECOVERY.equals(cid))) {
                    continue;
                }
                log.info("now load " + persistKey + "_cluster_" + cid + "_pool");
                ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, merger);
                byte[] poolData = mc.read(persistKey + "_cluster_" + cid + "_pool", "a");
                String poolString = new String(poolData);
                try {
                    JsonNode root = mapper.readTree(poolString);
                    clusterMultiDocumentsPool.deserialize(root);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                poolMap.put(cid, clusterMultiDocumentsPool);
            }
            log.info("load collections finished");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return true;
    }

    @Override
    public boolean dumpCollections() {
        readWriteLock.writeLock().lock();
        try {
            LogManager.DUMP.info("begin to dump collections");
            mc.write(persistKey + "_cluster_ids", Joiner.on(",").join(poolMap.keySet()).getBytes(), "a");
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                LogManager.DUMP.info("now dump " + persistKey + "_cluster_" + entry.getKey() + "_pool");
                try {
                    String data = mapper.writeValueAsString(entry.getValue().serialize());
                    mc.write(persistKey + "_cluster_" + entry.getKey() + "_pool", data.getBytes(), "a");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            LogManager.DUMP.info("dump collections finished");
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            readWriteLock.writeLock().unlock();
        }
        return true;
    }

    @Override
    public List<DocumentInfo> fetch(String cid, int topn) {
        if (!poolMap.containsKey(cid)) {
            poolMap.put(cid, new ClusterMultiDocumentsPool(cid, merger));
        }
        MultiDocumentsPool pool = poolMap.get(cid);
        return pool.fetch(topn);
    }

    @Override
    public List<DocumentInfo> fetch(String cid, int topn, CompareKey ck) {
        if (!poolMap.containsKey(cid)) {
            poolMap.put(cid, new ClusterMultiDocumentsPool(cid, merger));
        }
        MultiDocumentsPool pool = poolMap.get(cid);
        return pool.fetch(topn, ck);
    }

    @Override
    public boolean addDocument(String poolName, DocumentFeature doc) {
        readWriteLock.readLock().lock();
        try {
            List<String> filteredCids = Lists.newArrayList();
            List<Future<?>> lst = Lists.newArrayList();
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                float baseScore = marker.score(entry.getKey(), doc);
                if (Math.abs(baseScore) < 1e-9) {
                    filteredCids.add(entry.getKey());
                    continue;
                }
                DocumentFeature ndoc = (DocumentFeature) doc.clone();
                ndoc.setScore(baseScore);
                lst.add(TaskPoolFactory.userclusterAddDocumentTaskPool.submit(() -> {
                    entry.getValue().addDocument(poolName, ndoc);
                }));
            }
            if (!filteredCids.isEmpty()) {
                log.info("cids: " + Joiner.on(",").join(filteredCids) + " filtered " + doc.toString() + " by DocEmbedding");
            }
            for (Future<?> future : lst) {
                try {
                    future.get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                    log.info(StringTools.LogExceptionStack(e));
                }
            }
            KeyValueCache.defaultCache().invalidateAll();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public boolean model2newsAddDocument(String poolName, DocumentFeature doc) {
        readWriteLock.readLock().lock();
        try {
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                if (Constants.MODEL2NEWS.equals(entry.getKey())) {
                    DocumentFeature ndoc = (DocumentFeature) doc.clone();
                    ndoc.setScore(0);
                    entry.getValue().addDocument(poolName, ndoc);
                }
            }
            KeyValueCache.defaultCache().invalidateAll();
            return true;
        } catch (Exception e) {
            log.error("model2news video explore add " + doc.toString() + " exception:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public boolean addDocumentInfo(String cid, String poolName, DocumentInfo documentInfo) {
        readWriteLock.readLock().lock();
        try {
            return poolMap.containsKey(cid) && poolMap.get(cid).addDocumentInfo(poolName, documentInfo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public DocumentInfo removeDocumentInfo(String cid, String poolName, String docid) {
        readWriteLock.readLock().lock();
        try {
            if (poolMap.containsKey(cid)) {
                return poolMap.get(cid).removeDocumentInfo(poolName, docid);
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return null;
    }

    @Override
    public boolean updateStatus(String uid, String cid, String docid, String event) {
        readWriteLock.readLock().lock();
        try {
            if (!poolMap.containsKey(cid)) {
                poolMap.put(cid, new ClusterMultiDocumentsPool(cid, new PriorityMerger()));
            }
            MultiDocumentsPool pool = poolMap.get(cid);
            pool.updateStatus(uid, docid, event);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public boolean model2newsUpdateStatus(String uid, String cid, String docid, String event) {
        readWriteLock.readLock().lock();
        try {
            if (poolMap.containsKey(cid)) {
                MultiDocumentsPool pool = poolMap.get(cid);
                return pool.model2newsUpdateStatus(uid, docid, event);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public Map<String, Map<String, List<DocumentInfo>>> expire() {
        readWriteLock.readLock().lock();
        Map<String, Map<String, List<DocumentInfo>>> ret = Maps.newHashMap();
        try {
            Map<String, Future<Map<String, List<DocumentInfo>>>> map = Maps.newHashMap();
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                // ret.put(entry.getKey(), entry.getValue().expire());
                map.put(entry.getKey(), TaskPoolFactory.userclusterExpireTaskPool.submit(() -> entry.getValue().expire()));
            }
            for (Map.Entry<String, Future<Map<String, List<DocumentInfo>>>> entry : map.entrySet()) {
                try {
                    Map<String, List<DocumentInfo>> val = entry.getValue().get();
                    ret.put(entry.getKey(), val);
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                    log.info(StringTools.LogExceptionStack(e));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.info(StringTools.LogExceptionStack(e));
        } finally {
            readWriteLock.readLock().unlock();
        }
        return ret;
    }

    @Override
    public Map<String, Map<String, List<DocumentInfo>>> model2newsExpire() {
        readWriteLock.readLock().lock();
        Map<String, Map<String, List<DocumentInfo>>> ret = Maps.newHashMap();
        try {
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                ret.put(entry.getKey(), entry.getValue().model2newsExpire());
            }
        } catch (Exception e) {
            log.error("model2news video explore pools expire exception:", e);
        } finally {
            readWriteLock.readLock().unlock();
        }
        return ret;
    }

    @Override
    public Map<String, Object> getDebugInfo(String cid, String documentsPool, int topn, CompareKey ck) {
        Map<String, Object> ret = Maps.newLinkedHashMap();
        MultiDocumentsPool pool = poolMap.get(cid);
        if (pool == null) {
            return ret;
        }
        return pool.getDebugInfo(documentsPool, topn, ck);
    }

    @Override
    public Map<String, DocumentInfo> getClusterDocumentInfos(String cid, String documentsPool) {
        Map<String, DocumentInfo> ret = Maps.newLinkedHashMap();
        MultiDocumentsPool pool = poolMap.get(cid);
        if (pool == null) {
            return ret;
        }
        return pool.getClusterDocumentInfos(documentsPool);
    }

    @Override
    public boolean fakeCollections() {
        if (persistKey.startsWith("fuzz")) {
            for (int i = 0; i < 512; i++) {
                String cid = "c0_" + i;
                ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, new PriorityMerger());
                Map<String, DocumentsPool> documentsPoolMap = clusterMultiDocumentsPool.getDocumentsPoolMap();
                ClusterDocumentsPool clusterDocumentsPool1 = new ClusterDocumentsPool(cid);
                ClusterDocumentsPool clusterDocumentsPool2 = new ClusterDocumentsPool(cid);
                documentsPoolMap.put("highPriorityPool", clusterDocumentsPool1);
                documentsPoolMap.put("lowPriorityPool", clusterDocumentsPool2);
                poolMap.put(cid, clusterMultiDocumentsPool);
            }
            dumpCollections();
        } else if (persistKey.startsWith("subtle")) {
            for (int i = 0; i < 5000; i++) {
                String cid = "c1_" + i;
                ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, new PriorityMerger());
                Map<String, DocumentsPool> documentsPoolMap = clusterMultiDocumentsPool.getDocumentsPoolMap();
                ClusterDocumentsPool clusterDocumentsPool1 = new ClusterDocumentsPool(cid);
                ClusterDocumentsPool clusterDocumentsPool2 = new ClusterDocumentsPool(cid);
                documentsPoolMap.put("highPriorityPool", clusterDocumentsPool1);
                documentsPoolMap.put("lowPriorityPool", clusterDocumentsPool2);
                poolMap.put(cid, clusterMultiDocumentsPool);
            }
            dumpCollections();
        } else if (persistKey.startsWith("video")) {
            log.info("begin to fakeCollections for " + persistKey);
            for (int i = 0; i < 200; i++) {
                String cid = "c" + i;
                ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, new PriorityMerger());
                Map<String, DocumentsPool> documentsPoolMap = clusterMultiDocumentsPool.getDocumentsPoolMap();
                ClusterDocumentsPool clusterDocumentsPool1 = new ClusterDocumentsPool(cid);
                ClusterDocumentsPool clusterDocumentsPool2 = new ClusterDocumentsPool(cid);
                documentsPoolMap.put("highPriorityPool", clusterDocumentsPool1);
                documentsPoolMap.put("lowPriorityPool", clusterDocumentsPool2);
                poolMap.put(cid, clusterMultiDocumentsPool);
            }
            dumpCollections();
            log.info("fakeCollections for " + persistKey + " have done");
        }
        return true;
    }

    @Override
    public boolean embedFrameVector() {
        readWriteLock.readLock().lock();
        try {
            for (Map.Entry<String, MultiDocumentsPool> entry : poolMap.entrySet()) {
                entry.getValue().embedFrameVector();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readWriteLock.readLock().unlock();
        }
        return false;
    }

    @Override
    public boolean model2newsFakeCollections() {
        if ("model2newsVideoExplore".equals(persistKey)) {
            log.info("begin to fake model2news collections for " + persistKey);
            String[] cids = {Constants.MODEL2NEWS, Constants.FEEDBACK_RECOVERY};
            for (String cid : cids) {
                ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, new PriorityMerger());
                Map<String, DocumentsPool> documentsPoolMap = clusterMultiDocumentsPool.getDocumentsPoolMap();
                ClusterDocumentsPool clusterDocumentsPool = new ClusterDocumentsPool(cid);
                documentsPoolMap.put(Constants.MODEL2NEWS_VIDEO_POOL, clusterDocumentsPool);
                poolMap.put(cid, clusterMultiDocumentsPool);
            }
            dumpCollections();
            log.info("fakeCollections for " + persistKey + " have done");
        } else if ("model2newsVideoExploit".equals(persistKey)) {
            log.info("begin to fake model2news collections for " + persistKey);
            String cid = Constants.MODEL2NEWS;
            ClusterMultiDocumentsPool clusterMultiDocumentsPool = new ClusterMultiDocumentsPool(cid, new PriorityMerger());
            Map<String, DocumentsPool> documentsPoolMap = clusterMultiDocumentsPool.getDocumentsPoolMap();
            ClusterDocumentsPool clusterDocumentsPool = new ClusterDocumentsPool(cid);
            documentsPoolMap.put(Constants.MODEL2NEWS_VIDEO_POOL, clusterDocumentsPool);
            poolMap.put(cid, clusterMultiDocumentsPool);
            dumpCollections();
            log.info("fakeCollections for " + persistKey + " have done");
        }
        return true;
    }
}