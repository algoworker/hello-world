package com.yidian.explore.utils;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.hipu.util.*;
import com.mongodb.*;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.constant.LogManager;
import com.yidian.explore.core.ClusterDocumentsPool;
import com.yidian.explore.dao.MongoDao;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.net.InetAddress;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Mongo Utilities
 * @author senliu
 */
public class MongoUtil {
    private static final Logger logger = Logger.getLogger(MongoUtil.class);

    private static String getHost(String address) {
        return address.indexOf(':') == -1 ? address : Iterables.getFirst(StringUtil.split(address, ':'), "");
    }

    private static int getPort(String address) {
        return address.indexOf(':') == -1 ? 27017 : Integer.parseInt(Iterables.getLast(StringUtil.split(address, ':'), "27017"));
    }

    public static Mongo getMongoConnection(String addresses) {
        Mongo mongo = null;
        assert addresses != null && addresses.length() > 0 : addresses + " is null or empty";
        logger.info("Initialize Mongo with addresses:" + addresses);

        MongoOptions options = new MongoOptions();
        options.setConnectionsPerHost(10);
        options.setConnectTimeout(1000);
        options.setSocketTimeout(20000);
        options.setReadPreference(ReadPreference.secondaryPreferred());

        try {
            List<ServerAddress> replicaSetSeeds = Lists.newLinkedList();
            for (String server : StringUtil.split(addresses, ',')) {
                replicaSetSeeds.add(new ServerAddress(getHost(server), getPort(server)));
            }
            mongo = new Mongo(replicaSetSeeds, options);
        } catch (MongoException e) {
            logger.error("MongoException with address:" + addresses, e);
        }

        return mongo;
    }

    public static boolean isMongoWriter() {
        try {
            String defaultHosts = ExploreExploitConfig.defaultConfig().getExploreMongoWriterHost();
            List<String> defaultHostList = Arrays.asList(defaultHosts.split(","));
            String currentHost = InetAddress.getLocalHost().getHostName();
            if (!defaultHostList.isEmpty() && !defaultHostList.contains(currentHost)) {
                return false;
            }
        } catch (Exception e) {
            logger.error("Get mongo writer hosts exception:", e);
        }
        return true;
    }

    public static DBObject read(DBCollection dbCollection, String id) {
        return dbCollection.findOne(new BasicDBObject("_id", id));
    }

    /**
     * 程序启动时,将mongo中的ClusterDocumentsPool加载到内存
     * 与加载morpheus的原理一致,解决morpheus引发的timeout问题
     */
    public static void loadClusterDocumentsPoolFromMongo(ClusterDocumentsPool clusterDocumentsPool) {
        String loadMongoInfoLog = "Load {0} videos for {1} from mongo successfully";
        String loadMongoErrorLog = "Load {0} from mongo exception:";
        DBCollection dbCollection = MongoDao.getInstance().getClusterDocumentsPoolMongo();
        if (dbCollection != null) {
            DBObject dbObject = MongoUtil.read(dbCollection, clusterDocumentsPool.getCid());
            if (dbObject != null) {
                ObjectMapper mapper = new ObjectMapper();
                try {
                    JsonNode root = mapper.readTree(dbObject.toString());
                    clusterDocumentsPool.deserialize(root);
                    logger.info(MessageFormat.format(loadMongoInfoLog, clusterDocumentsPool.getDocumentInfoMap().size(), clusterDocumentsPool.getCid()));
                } catch (IOException e) {
                    logger.error(MessageFormat.format(loadMongoErrorLog, clusterDocumentsPool.getCid()), e);
                }
            } else {
                logger.error(MessageFormat.format(loadMongoErrorLog, clusterDocumentsPool.getCid()) + "no this key in mongo");
            }
        }
    }

    /**
     * 程序更新前,将内存中的ClusterDocumentsPool备份到mongo
     */
    public static void dumpClusterDocumentsPoolIntoMongo(ClusterDocumentsPool clusterDocumentsPool) {
        String dumpMongoInfoLog = "Dump {0} videos from ClusterDocumentsPool {1} into mongo successfully";
        String dumpMongoErrorLog = "Dump clusterDocumentsPool {0} into mongo exception:";
        DBCollection dbCollection = MongoDao.getInstance().getClusterDocumentsPoolMongo();
        if (dbCollection != null) {
            try {
                Map<String, Object> mongoData = clusterDocumentsPool.serialize();
                mongoData.put("_id", clusterDocumentsPool.getCid());
                MongoDao.getInstance().write(mongoData, dbCollection);
                LogManager.DUMP.info(MessageFormat.format(dumpMongoInfoLog, clusterDocumentsPool.getDocumentInfoMap().size(), clusterDocumentsPool.getCid()));
            } catch (Exception e) {
                logger.error(MessageFormat.format(dumpMongoErrorLog, clusterDocumentsPool.getCid()), e);
            }
        }
    }

    public static void main(String[] args) {
        DBCollection dbCollection = MongoDao.getInstance().getClusterDocumentsPoolMongo();
        DBObject dbObject = MongoUtil.read(dbCollection, "mcnVideoExplore");
        ObjectMapper mapper = new ObjectMapper();
        ClusterDocumentsPool clusterDocumentsPool = new ClusterDocumentsPool("test");
        try {
            JsonNode root = mapper.readTree(dbObject.toString());
            clusterDocumentsPool.deserialize(root);
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }
}