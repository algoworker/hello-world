package com.yidian.explore.core;

import com.google.common.collect.Maps;
import lombok.Data;
import lombok.ToString;

import java.util.Map;

@Data
@ToString(exclude = {"sig"})
public class DocumentFeature implements Cloneable{
    public String docid;
    public String seg_title;
    public String source;
    public String date;
    public String refer = "pipline";
    public String sig = "null";
    public int tier = 0;
    public float score;
    public Map<String, Double> keywords = Maps.newHashMap();

    public DocumentFeature(String docid, String title, String source, String date, String refer){
        this.docid = docid;
        this.seg_title = title;
        this.source = source;
        this.date = date;
        this.refer = refer;
    }

    @Override
    public Object clone(){
        DocumentFeature documentFeature = null;
        try {
            documentFeature = (DocumentFeature)super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return documentFeature;
    }

    public static void main(String [] args){
        DocumentFeature a = new DocumentFeature("a", "as", "asrc", "12312", "pip");
        a.setScore(0.1f);
        DocumentFeature b = (DocumentFeature) a.clone();
        b.setDocid("b");
        b.setScore(0.2f);
        System.out.println(a.toString());
        System.out.println(b.toString());
    }
}
