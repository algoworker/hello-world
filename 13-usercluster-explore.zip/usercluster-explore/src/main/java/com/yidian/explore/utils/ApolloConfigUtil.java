package com.yidian.explore.utils;

import com.alibaba.fastjson.JSONObject;
import com.yidian.explore.utils.convertor.*;
import com.yidian.recommender.commons.apollo.CommonConfigService;
import com.yidian.recommender.commons.apollo.convertor.impl.StringSetConfigObjectConvertor;

import lombok.extern.log4j.Log4j;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * @author xin
 * @version 视频试探&视频保量服务apollo配置中心
 * @date 2019/05/13 11:25
 **/
@Log4j
public class ApolloConfigUtil {
    private static volatile ApolloConfigUtil instance = null;

    /**
     * apollo Namespace list for usercluster-explore-video
     */
    private static final class ApolloNameSpace {
        private static final String APPLICATION = "application";  // default Namespace and no use
        private static final String VIDEO_EXPLORE = "video_explore";
        private static final String VIDEO_VIEWS_ASSURANCE = "video_views_assurance";

        private ApolloNameSpace() {

        }
    }

    /**
     * apollo config list for usercluster-explore-video
     * contain video_explore and video_views_assurance namespaces
     */
    private static final String EXPLORE_CONFIG = "explore_config";
    private static final String EXPLORE_PASS_AUDIT_VIDEO = "explore_pass_audit_video";
    private static final String EXPLORE_MICRO_VIDEO = "explore_micro_video";
    private static final String EXPLORE_DEFAULT_VIEWS = "explore_default_views";
    private static final String MODEL2EXPLORE_POOL_CAPACITY = "model2explore_pool_capacity";
    private static final String EXPLORE_FEEDBACK_TERRIBLE_CTR = "explore_feedback_terrible_ctr";
    private static final String EXPLORE_SOURCE_BLACKLIST = "explore_source_blacklist";
    private static final String EXPLORE_FEEDBACK_RECOVERY_DELAY = "explore_feedback_recovery_delay";
    private static final String EXPLORE_VIDEO_LIFETIME = "explore_video_lifetime";
    private static final String IQIYI_EXPLORE_SOURCE = "iqiyi_explore_source_whitelist";
    private static final String RETAG_EXPLORE_VIDEO = "retag_explore_video";
    private static final String RETAG_EXPLORE_VIDEO_CNT = "retag_explore_video_count";
    private static final String RETAG_EXPLORE_MICROVIDEO_CNT = "retag_explore_microvideo_count";
    private static final String RETAG_DAILY_WATCH_COUNT = "retag_daily_watch_count";
    private static final String SOURCE_TIER_FILTER = "source_tier_filter";

    private static final String VIEWS_ASSURANCE_CONFIG = "views_assurance_config";
    private static final String DOUYIN_TOP_SOURCE = "douyin_top_source";
    private static final String MCN_INVITATION_SOURCE = "mcn_invitation_source";
    private static final String BOOST_VIEW_VCT = "boost_view_category";

    private Set<String> exploreSourceBlacklist = new HashSet<>();
    private Set<String> iqiyiExploreSource = new HashSet<>();

    private Set<String> douyinTopSource = new HashSet<>();
    private Set<String> mcnInvitationSource = new HashSet<>();
    private JSONObject defaultViewAssuranceThreshold;
    private Set<String> boostViewVideoCategory = new HashSet<>();

    public static ApolloConfigUtil getInstance() {
        if (instance == null) {
            synchronized (ApolloConfigUtil.class) {
                if (instance == null) {
                    instance = new ApolloConfigUtil();
                }
            }
        }
        return instance;
    }

    private ApolloConfigUtil() {
        try {
            // namespace video_explore
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new JsonConfigObjectConvertor(), EXPLORE_CONFIG);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new BooleanConfigObjectConvertor(), EXPLORE_PASS_AUDIT_VIDEO);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new BooleanConfigObjectConvertor(), EXPLORE_MICRO_VIDEO);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), EXPLORE_DEFAULT_VIEWS);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), MODEL2EXPLORE_POOL_CAPACITY);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new DoubleConfigObjectConvertor(), EXPLORE_FEEDBACK_TERRIBLE_CTR);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new StringSetConfigObjectConvertor(), EXPLORE_SOURCE_BLACKLIST);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), EXPLORE_FEEDBACK_RECOVERY_DELAY);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), EXPLORE_VIDEO_LIFETIME);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new StringSetConfigObjectConvertor(), IQIYI_EXPLORE_SOURCE);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new BooleanConfigObjectConvertor(), RETAG_EXPLORE_VIDEO);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), RETAG_EXPLORE_VIDEO_CNT);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), RETAG_EXPLORE_MICROVIDEO_CNT);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), RETAG_DAILY_WATCH_COUNT);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_EXPLORE, new IntegerConfigObjectConvertor(), SOURCE_TIER_FILTER);
            // namespace video_views_assurance
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, new JsonConfigObjectConvertor(), VIEWS_ASSURANCE_CONFIG);
            CommonConfigService.addConvertorMapping(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, new StringSetConfigObjectConvertor(), DOUYIN_TOP_SOURCE, MCN_INVITATION_SOURCE, BOOST_VIEW_VCT);
            CommonConfigService.init(Arrays.asList(ApolloNameSpace.VIDEO_EXPLORE, ApolloNameSpace.VIDEO_VIEWS_ASSURANCE));
        } catch (Exception e) {
            log.error("ApolloConfigUtil init exception:", e);
        }
    }

    public boolean getExplorePassAuditVideo() {
        return CommonConfigService.getValueAsBoolean(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_PASS_AUDIT_VIDEO, true);
    }

    public boolean getExploreMicroVideo() {
        return CommonConfigService.getValueAsBoolean(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_MICRO_VIDEO, false);
    }

    public int getModel2explorePoolCapacity() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, MODEL2EXPLORE_POOL_CAPACITY, 20000);
    }

    public Set<String> getDouyinTopSource() {
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, DOUYIN_TOP_SOURCE, Set.class, douyinTopSource);
    }

    public Set<String> getMcnInvitationSource() {
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, MCN_INVITATION_SOURCE, Set.class, mcnInvitationSource);
    }

    public Set<String> getBoostViewVideoCategory() {
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, BOOST_VIEW_VCT, Set.class, boostViewVideoCategory);
    }

    public double getExploreFeedbackTerribleCtr() {
        return CommonConfigService.getValueAsDouble(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_FEEDBACK_TERRIBLE_CTR, 0.005D);
    }

    public Set<String> getExploreSourceBlacklist() {
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_SOURCE_BLACKLIST, Set.class, exploreSourceBlacklist);
    }

    public int getExploreFeedbackRecoveryDelay() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_FEEDBACK_RECOVERY_DELAY, 60);  // value以min为单位
    }

    public int getExploreVideoLifetime() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, EXPLORE_VIDEO_LIFETIME, 720);  // value以min为单位,默认12h
    }

    public Set<String> getIqiyiExploreSource() {
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_EXPLORE, IQIYI_EXPLORE_SOURCE, Set.class, iqiyiExploreSource);
    }

    public boolean getRetagExploreVideo() {
        return CommonConfigService.getValueAsBoolean(ApolloNameSpace.VIDEO_EXPLORE, RETAG_EXPLORE_VIDEO, true);
    }

    public int getRetagExploreVideoCount() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, RETAG_EXPLORE_VIDEO_CNT, 25000);
    }

    public int getRetagExploreMicroVideoCount() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, RETAG_EXPLORE_MICROVIDEO_CNT, 15000);
    }

    public JSONObject getViewsAssuranceConfig(){
        return CommonConfigService.getObjectValue(ApolloNameSpace.VIDEO_VIEWS_ASSURANCE, VIEWS_ASSURANCE_CONFIG, JSONObject.class, defaultViewAssuranceThreshold);
    }

    public int getRetagDailyWatchCount() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, RETAG_DAILY_WATCH_COUNT, 5000);
    }

    public int getSourceTierFilter() {
        return CommonConfigService.getValueAsInt(ApolloNameSpace.VIDEO_EXPLORE, SOURCE_TIER_FILTER, 0);
    }

    public static void main(String args[]) {
        Set<String> douyinTopSource = ApolloConfigUtil.getInstance().getDouyinTopSource();
        System.out.println(douyinTopSource.toString());
        JSONObject config = ApolloConfigUtil.getInstance().getViewsAssuranceConfig();
        System.out.println(config.toString());
    }
}
