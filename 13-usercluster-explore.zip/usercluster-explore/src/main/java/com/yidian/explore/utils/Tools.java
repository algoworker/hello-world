package com.yidian.explore.utils;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.yidian.explore.core.DocumentInfo;
import lombok.extern.log4j.Log4j;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Log4j
@Deprecated
public class Tools {
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();

    @Deprecated
    private static void dumpSelectedVideoToFile(Map<String, Long> map) {
        try {
            log.info("begin to dump videoSelectedPoolMonthly to text file");
            FileOutputStream outputStream = new FileOutputStream("../data/selected_video_set.txt");
            OutputStreamWriter ostream = new OutputStreamWriter(outputStream);
            BufferedWriter buffer = new BufferedWriter(ostream);
            buffer.write(gson.toJson(map));
            buffer.close();
            ostream.close();
            outputStream.close();
            log.info("dump videoSelectedPoolMonthly finished");
        } catch (IOException e) {
            e.printStackTrace();
            log.error("dump videoSelectedPoolMonthly to text file error");
        }
    }

    @Deprecated
    private static Map<String, Long> loadSelectedVideoFromFile() {
        Map<String, Long> ret = Maps.newLinkedHashMap();
        try {
            File file = new File("../data/selected_video_set.txt");
            if (!file.exists()) {
                log.error("selected video set file doesn't exist");
                return ret;
            }
            log.info("begin to load videoSelectedPoolMonthly from text file");
            FileInputStream inputStream = new FileInputStream("../data/selected_video_set.txt");
            InputStreamReader istream = new InputStreamReader(inputStream);
            BufferedReader buffer = new BufferedReader(istream);
            String data = buffer.readLine();
            Type type = new TypeToken<Map<String, Long>>() {
            }.getType();
            ret = gson.fromJson(data, type);
            buffer.close();
            istream.close();
            inputStream.close();
            log.info("load videoSelectedPoolMonthly finished");
        } catch (IOException e) {
            e.printStackTrace();
            log.error("load videoSelectedPoolMonthly from text file error");
        }
        return ret;
    }

    /**
     * list->map
     */
    @Deprecated
    public Map<String, DocumentInfo> list2map(List<DocumentInfo> list) {
        Map<String, DocumentInfo> map = Maps.newHashMap();
        try {
            map = list.stream().collect(Collectors.toMap(DocumentInfo::getDocid, Function.identity(), (k1, k2) -> k1));
        } catch (Exception e) {
            log.error("Expire video list transform to map exception:", e);
        }
        return map;
    }
}
