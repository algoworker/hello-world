package com.yidian.explore.core;

import com.yidian.explore.constant.Constants;
import com.yidian.explore.utils.VideoEmbedding;
import lombok.Data;
import lombok.ToString;
import lombok.extern.log4j.Log4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Data
@ToString(callSuper = true)
@Log4j
public class VideoFeature extends DocumentFeature {
    private int duration;
    private boolean micro = false;
    private boolean passAudit = false;
    private String from = "yidianzixun";
    private List<String> videoCategory = new ArrayList<>();
    private List<String> videoSubcategory = new ArrayList<>();
    private List<String> videoTags = new ArrayList<>();

    public VideoFeature(String docid, String title, String source, String date, String refer) {
        super(docid, title, source, date, refer);
    }

    public static DocumentInfo videoFeature2videoInfo(DocumentFeature doc) {
        int tier = doc.getTier();
        String docid = doc.getDocid();
        String source = doc.getSource();
        String titleWords = VideoEmbedding.getSegTitleWords(doc.getSeg_title());
        String refer = doc.getRefer();
        float baseScore = doc.getScore();
        Date date = new Date();
        if (doc.getDate() != null) {
            try {
                date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(doc.getDate());
            } catch (ParseException e) {
                log.error("Transform doc date for adding document exception:", e);
            }
        }
        VideoInfo video = new VideoInfo(docid, titleWords, source, tier, baseScore, date, refer);
        video.setMicro(((VideoFeature) doc).isMicro());
        video.setPassAudit(((VideoFeature) doc).isPassAudit());
        video.setRefer(String.format("%s_%s_%s_exploit", "vivoToutiao", Constants.MODEL2NEWS, Constants.MODEL2NEWS_VIDEO_POOL));
        video.setExploitFeature("vivo_toutiao_explosive");
        return video;
    }
}