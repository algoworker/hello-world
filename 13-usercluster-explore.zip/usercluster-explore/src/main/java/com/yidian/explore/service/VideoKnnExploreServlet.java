package com.yidian.explore.service;

import com.google.common.base.Optional;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hipu.util.HttpUtil;
import com.hipu.util.helper.UserBucketGetter2;
import com.yidian.explore.constant.Constants;
import com.yidian.explore.core.*;
import com.yidian.serving.index.metrics.Metrics;
import com.yidian.serving.index.metrics.api.SimpleMetrics;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class VideoKnnExploreServlet extends HttpServlet {
    private static Logger logger = Logger.getLogger(VideoKnnExploreServlet.class);
    private static final SimpleMetrics metrics = Metrics.simple();
    private static Gson gson = new GsonBuilder().disableHtmlEscaping().create();
    private static ExploreExploitVideoPools exploreExploitVideoPools = ExploreExploitVideoPools.getInstance();
    private KnnExplore knnExplore = new KnnExplore();
    private String metricPrefix = "knnVideoExplore";
    private static SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        Stopwatch watch = Stopwatch.createStarted();

        resp.setContentType("application/json");
        resp.setCharacterEncoding("utf-8");
        req.setCharacterEncoding("utf-8");

        Map<String, Object> retMap = Maps.newLinkedHashMap();
        retMap.put("status", "success");
        retMap.put("code", 0);

        String userid = req.getParameter("userid");
        String debug = req.getParameter("debug");
        int count = Integer.parseInt(Optional.fromNullable(req.getParameter("count")).or("50"));

        Set<String> buckets = UserBucketGetter2.fetch(userid);
        List<MIPSEntry> ret = knnExplore.retrieve(userid, 10); // 移出对点击次数的实验,已经验证点击率可以提升大约0.2个百分点

        // since getKnnVideoExplorePool is removed
        Map<String, DocumentInfo> documentInfoMap = exploreExploitVideoPools.getMomoVideoExplorePool().getDocumentInfoMap();
        if (ret == null) {
            HttpUtil.setResponse(resp, gson.toJson(retMap));
            Metrics.simple().ratio(metricPrefix + "_empty_result", true);
            return;
        }

        Date date = new Date();
        List<DocItem> retLst = Lists.newArrayList();
        for (MIPSEntry mipsEntry : ret) {
            DocumentInfo documentInfo = documentInfoMap.getOrDefault(mipsEntry.externId, null);
            if (documentInfo != null && documentInfo.getViews() < 300) { // 过滤300次以下的
                DocItem docItem = new DocItem();
                docItem.setDocid(documentInfo.getDocid());

                // 增加对时间的惩罚实验
                Double weight = 1.0;
                if (buckets.contains("user2explorevideo-exp")) {
                    Double delta_min = (date.getTime() - documentInfo.getDate().getTime()) / 1000 / 60.;
                    if (delta_min <= 30) { //半小时加权
                        weight = Constants.PUNISHBIN.get(0.5);
                    } else if (delta_min <= 3.0 * 60) { //3小时加权
                        weight = Constants.PUNISHBIN.get(3.0);
                    } else if (delta_min < 6.0 * 60) { //6小时加权
                        weight = Constants.PUNISHBIN.get(6.0);
                    }
                }
                docItem.setScore((float) (mipsEntry.distance * weight));

                if (debug != null) {
                    docItem.setDistance(mipsEntry.distance);
                    docItem.setTitle(documentInfo.getTitleWords());
                    docItem.setDate(simpleFormat.format(documentInfo.getDate()));
                    docItem.setSrc(documentInfo.getSource());
                    docItem.setTier(documentInfo.getTier());
                }
                retLst.add(docItem);
            }
        }
        retLst.sort(Comparator.comparing(DocItem::getScore).reversed());

        retMap.put("docs", retLst.subList(0, Math.min(count, retLst.size())));
        HttpUtil.setResponse(resp, gson.toJson(retMap));

        int resultCount = retLst.size();
        metrics.qps(metricPrefix + "_access");
        metrics.latency(metricPrefix + "_process", System.currentTimeMillis() - startTime);
        metrics.ratio(metricPrefix + "_empty_result", resultCount == 0);
        metrics.count(metricPrefix + "_result_size", resultCount);
        logger.info("ACCESS:" + req.getQueryString() + " time elapse: " + watch.toString() + " video count: " + resultCount);
    }
}
