package com.yidian.explore.utils.convertor;

import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

public class IntegerConfigObjectConvertor implements IConfigObjectConvertor<Integer> {
    @Override
    public Integer convert(String value) {
        return Integer.parseInt(value);
    }
}
