package com.yidian.explore.userstore;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigValueFactory;
import com.yidian.featurestore.common.Constants;
import com.yidian.featurestore.dao.MorpheusReader;
import com.yidian.userstore.conf.UserConstants;
import com.yidian.userstore.data.UserRawData;
import com.yidian.userstore.util.DataTransFormer;
import org.apache.log4j.Logger;
import yidian.data.profile.ChannelInfo;
import yidian.data.profile.TFeature;

import java.util.*;

/**
 * Created by gaozidong on 18/4/24.
 */
public class UserMorpheusDao4MultiEnv {
    private Logger logger = Logger.getLogger(UserMorpheusDao4MultiEnv.class);
    private MorpheusReader reader;
    private UserStoreEnvConfig conf;
    private String idTable = UserConstants.USERID_STORE_TABLE;
    private static final String CONFIG_NAME = "userstore";
    private static Map<String, UserMorpheusDao4MultiEnv> instanceMap = new HashMap<>();

    private UserMorpheusDao4MultiEnv(String env) {
        conf = new UserStoreEnvConfig(env);
        reader = init(env);
    }

    public static UserMorpheusDao4MultiEnv getUserMorpheus(String env) {
        if (!instanceMap.containsKey(env)) {
            synchronized (UserMorpheusDao4MultiEnv.class) {
                if (!instanceMap.containsKey(env)) {
                    instanceMap.put(env, new UserMorpheusDao4MultiEnv(env));
                }
            }
        }
        return instanceMap.get(env);
    }

    private MorpheusReader init(String env) {
        if (conf == null) {
            logger.error("Init userMorpheusDao failed, reader config is null");
            throw new RuntimeException("Init userMorpheusDao failed, reader config is null");
        }
        Config reporterConfig = conf.getSegmentConfig(UserConstants.USER_REPORTER_CONF_SEGMENT, null);
        if (reporterConfig == null) {
            logger.error("Init user morpheusReader reporter failed, reporter config is null");
        }

        try {
            Config idReaderConfig = conf.getSegmentConfig(CONFIG_NAME, env);
            if (idReaderConfig == null) {
                logger.error("Init user id morpheusReader failed, reader config is null");
                throw new RuntimeException("Init user id morpheusReader failed, reader config is null");
            }
            if (idReaderConfig.getString(UserConstants.USERID_STORE_TABLE_KEY) != null) {
                idTable = idReaderConfig.getString(UserConstants.USERID_STORE_TABLE_KEY);
            }
            idReaderConfig = idReaderConfig.withFallback(reporterConfig).withValue(Constants.MORPHEUS_READER_TABLE_KEY, ConfigValueFactory.fromAnyRef(idTable));
            MorpheusReader morpheusReader = new MorpheusReader(idReaderConfig);
            return morpheusReader;
        } catch (Exception e) {
            logger.error("Init userstore morpheus reader exception:", e);
        }
        return null;
    }

    public Map<String, TFeature> getTFeatureMap(String id, List<String> columns) {
        Map<String, TFeature> tFeatureMap = Collections.emptyMap();
        try {
            tFeatureMap = reader.getTFeatureMap(id, columns);
        } catch (Exception e) {
            logger.error("UserMorpheusDao get " + id + " columns from morpheus exception:" + e);
        }
        return tFeatureMap;
    }

    public static void main(String[] args) {
        String env = "app";
        String userid = "280688691";
        List<String> columns = new ArrayList<>();
        columns.add(UserConstants.PINNED_CHANNEL_COLUMN);
        columns.add(UserConstants.EXP_DLK_COLUMN);
        Map<String, TFeature> tFeatureMap = UserMorpheusDao4MultiEnv.getUserMorpheus(env).getTFeatureMap(userid, columns);
        try {
            UserRawData rawData = DataTransFormer.getUserRawData(tFeatureMap);
            List<ChannelInfo> channels = rawData.getPinnedChannel().getChannels();
            for (int i = 0; i < channels.size(); i++) {
                ChannelInfo channelInfo = channels.get(i);
                if (channelInfo.getCreateStatus() == 0 && channelInfo.getType().equals("media")) {
                    System.out.println(channelInfo.getName());
                }
            }
            System.out.println(channels);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(tFeatureMap);
    }
}
