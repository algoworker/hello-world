package com.yidian.explore.ranker;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.yidian.explore.cache.NewsDocumentCache;
import com.yidian.explore.config.ExploreExploitConfig;
import com.yidian.explore.core.DocumentInfo;
import com.yidian.explore.core.VideoFeature;
import com.yidian.explore.userstore.UserProfileDao;
import com.yidian.explore.utils.*;
import com.yidian.media.core.Type;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import com.yidian.userstore.data.UserRawData;
import org.apache.log4j.Logger;
import lombok.extern.log4j.Log4j;
import yidian.data.usercf.UserVector;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by xiaobo on 2017/8/25.
 */
@Log4j
public class VideoRerankPerUser {
    public static Logger logger = Logger.getLogger(VideoRerankPerUser.class);

    public static float[] extractNormVector(UserVector userVector) {
        if (userVector == null) {
            return null;
        }
        int size = userVector.getVecsCount();
        float[] vec = new float[size];

        int i;
        double len = 0;
        float value;
        for (i = 0; i < size; ++i) {
            value = userVector.getVecs(i);
            vec[i] = value;
            len += (double) (value * value);
        }

        len = Math.sqrt(len);
        if (Math.abs(len) < 1e-8 || !Double.isFinite(len)) {
            return null;
        }

        for (i = 0; i < size; ++i) {
            vec[i] = (float) ((double) vec[i] / len);
        }

        return vec;
    }

    public static float simScore(float[] userVec, float[] videoVec) {
        float score = 0;
        if (userVec == null || videoVec == null || userVec.length != videoVec.length) {
            return score;
        }
        for (int i = 0; i < userVec.length; i++) {
            score += userVec[i] * videoVec[i];
        }
        if(!Double.isFinite(score)){
            return 0;
        }
        return score;  // another score (float) (1 / (1 + Math.exp(-score)))
    }

    public static float getUserVideoSimScore(String userId, DocumentInfo documentInfo) {
        if (userId == null || documentInfo == null) {
            logger.error("parameter error");
            return 0;
        }
        try {
            UserVector userVectorInfo = UserVectorMorphuesFetcher.getInstance(UserVectorMorphuesFetcher.TABLE_NAME_USER_VIDEO_VECTOR).getUserRankVector(userId, ExploreExploitConfig.defaultConfig().getVideoUserVectorColumn(), 0, ExploreExploitConfig.defaultConfig().getVideoUserVectorVersion());
            if (userVectorInfo == null) {
                logger.info("userid:" + userId + " does not have vec.");
                return 0;
            }
            float[] userVec = extractNormVector(userVectorInfo);
            SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Optional<NewsDocument> ndOpt = NewsDocumentCache.defaultInstance().get(documentInfo.getDocid());
            if (ndOpt.isPresent()) {
                NewsDocument nd = ndOpt.get();
                VideoFeature videoFeature = new VideoFeature(nd.getDocid(), nd.getSegTitle(), nd.getSource(), simpleFormat.format(nd.getDate()), "pipline");
                videoFeature.setTier(nd.getDocAuthority().or(0));
                videoFeature.setSig(nd.getSignature());
                videoFeature.setKeywords(nd.getKeywords());
                videoFeature.setVideoCategory(nd.getVideoCategory());
                videoFeature.setVideoSubcategory(nd.getVideoSubcategory());
                videoFeature.setVideoTags(nd.getYDTags());

                float[] videoVec = VideoEmbedding.defaultInstance().getVideoVector(videoFeature, null);  // title similarity only
                return simScore(userVec, videoVec);
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return 0;
    }

    private static boolean needPenalize(NewsDocument newsDocument){
//        if(newsDocument.getDocAuthority().or(3) >= 3)
//            return false;

        Type type = newsDocument.getMediaType();
        return ((type == Type.AUTHORIZE || type == Type.WAP || type == Type.CUSTOMIZE));
    }

    /**
     * @param userId
     * @param clusterRes
     * @param num
     * @param op
     * @param appid:user2video透传参数
     */
    public static List<DocumentInfo> rerank(String userId, List<DocumentInfo> clusterRes, int num, String op, String appid) {
        List<DocumentInfo> ret = Lists.newArrayList();
        if (clusterRes == null || num <= 0) {
            logger.error("rerank parameter error of " + userId);
            return ret;
        }
        try {
            if (num >= clusterRes.size()) {
                num = clusterRes.size();
            }
            List<DocumentInfo> rerankRes = clusterRes.subList(0, num);

            UserVector userVectorInfo = UserVectorMorphuesFetcher.getInstance(UserVectorMorphuesFetcher.TABLE_NAME_USER_VIDEO_VECTOR).getUserRankVector(userId, ExploreExploitConfig.defaultConfig().getVideoUserVectorColumn(), 0, ExploreExploitConfig.defaultConfig().getVideoUserVectorVersion());
            if (userVectorInfo == null) {
                logger.info("userid:" + userId + " does not have vec.");
                return Lists.newArrayList();
            }
            float[] userVec = extractNormVector(userVectorInfo);

            for (DocumentInfo documentInfo : rerankRes) {
                ret.add((DocumentInfo) documentInfo.clone());
            }

            List<String> abnormal = Lists.newArrayList();
            UserRawData rawData = UserProfileDao.getInstance().getUserRawData(userId, appid);
            Set<String> pinnedChannel = UserProfileDao.getInstance().getUserPinnedChannel(rawData);
            Set<String> dislikeSource = UserProfileDao.getInstance().getUserDislikeSource(rawData);

            for (DocumentInfo doc : ret) {
                float[] videoVec = VideoEmbedding.defaultInstance().getVideoVectorFromCacheById(doc.getDocid());
                if (videoVec == null || videoVec.length == 0) {
                    doc.setRankScore(-10);
                    continue;
                }

                double simScore = simScore(userVec, videoVec);
                if (Math.abs(simScore) < 1e-9) {
                    abnormal.add(doc.getDocid());
                    logger.warn("uid: " + userId + " simScore abnormal with doc: " + doc.getDocid() + " when rank per user");
                }

                if (op.equals("override")) {
                    if (pinnedChannel != null && pinnedChannel.contains(doc.getSource())) {
                        simScore += 100;
                    }
                    if (dislikeSource != null && dislikeSource.contains(doc.getSource())) {
                        simScore -= 100;
                    }
                    doc.setRankScore(simScore);
                } else if (op.equals("multiply")) {
                    double baseScore = doc.getBaseScore();
                    if (baseScore > 1) {
                        logger.error("video: " + doc.getDocid() + " refer: " + doc.getRefer() + " baseScore: " + doc.getBaseScore() + " explore baseScore error");
                        doc.setRankScore(-10);
                        continue;
                    }
                    double dwell = 1.0;
                    double duration = 1.0;
                    Optional<NewsDocument> ndOpt = NewsDocumentCache.defaultInstance().get(doc.getDocid());
                    if (ndOpt.isPresent()) {
                        dwell = ndOpt.get().getDwellClickRate();
                        duration = ndOpt.get().getDuration();
                    }

//                    double dw_punish = 1.0;
//                    if (dwell < 100) {
//                        dw_punish = -0.05 * ndOpt.get().getDwellClickRate() + 6;
//                    }
//                    if (dw_punish == 0 || dwell > duration) {
//                        doc.setRankScore(-10);
//                        continue;
//                    }
//
//                    double score;
//                    if (simScore >= 0) {
//                        score = simScore / dw_punish;
//                    } else {
//                        score = simScore * dw_punish;
//                    }
//                    if (Double.isNaN(score)) {
//                        doc.setRankScore(-10);
//                        continue;
//                    }
                    double dw_punish = 1 / (1 + Math.exp((dwell - 100) * 0.01)) + 0.73;
                    if (dw_punish == 0 || dwell > duration) {
                        doc.setRankScore(-10);
                        continue;
                    }
                    doc.setRankScore(Math.tan(simScore) * Math.pow(100 * doc.getBaseScore(), 0.1) / dw_punish);
//                    doc.setRankScore(Math.tan(score) * Math.pow(100 * doc.getBaseScore(), 0.1));
                } else {
                    doc.setRankScore(simScore);
                }
            }
            if (abnormal.size() > 0) {
                logger.warn("uid: " + userId + " abnormal doc: " + Joiner.on(",").join(abnormal));
            }
            ret.sort((o1, o2) -> -Double.compare(o1.getRankScore(), o2.getRankScore()));
        } catch (Exception e) {
            logger.error(e + " uid: " + userId + " trace: " + StringTools.LogExceptionStack(e));
        }
        return ret;
    }

    public static void main(String[] args) {
        String testUserId = "280688691";
        UserVector userVector = UserVectorMorphuesFetcher.getInstance(UserVectorMorphuesFetcher.TABLE_NAME_USER_VIDEO_VECTOR).getUserRankVector(testUserId, ExploreExploitConfig.defaultConfig().getVideoUserVectorColumn(), 0, ExploreExploitConfig.defaultConfig().getVideoUserVectorVersion());
        System.out.println(userVector);
    }
}
