package com.yidian.explore.utils.convertor;

import com.yidian.recommender.commons.apollo.convertor.IConfigObjectConvertor;

public class BooleanConfigObjectConvertor implements IConfigObjectConvertor<Boolean> {
    @Override
    public Boolean convert(String value) {
        return Boolean.parseBoolean(value);
    }
}
