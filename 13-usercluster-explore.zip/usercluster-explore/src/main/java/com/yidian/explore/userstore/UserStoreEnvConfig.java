package com.yidian.explore.userstore;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.yidian.featurestore.common.ItemDaoConfig;
import org.apache.log4j.Logger;

/**
 * Created by gaozidong on 18/4/24.
 */
public class UserStoreEnvConfig extends ItemDaoConfig {
    private static Logger logger = Logger.getLogger(UserStoreEnvConfig.class);
    private Config config = null;
    private boolean needUserRawData = true;
    private boolean needUserSegments = true;
    private boolean needUserRecentClick = true;
    private boolean isDataFromNewStore = false;
    private String userStoreServingName = "userprofile_new";
    private String metricPrefix = "usercluster_explore_video";

    public UserStoreEnvConfig(String env) {
        super();
        config = ConfigFactory.load(UserStoreEnvConfig.class.getClassLoader());
        if (config == null || config.isEmpty()) {
            logger.error("Load user store config error");
            return;
        }
        loadUserStoreConfig(env);
    }

    private void loadUserStoreConfig(String env) {
        if (config == null) {
            logger.error("User config is null");
            return;
        }
        Boolean flag;
        Config appidConfig = config.getConfig("userstore").getConfig(env);
        if (!appidConfig.hasPath("serving.name")) {
            throw new RuntimeException("Userstore config does not have serving.name path");
        }
        userStoreServingName = appidConfig.getString("serving.name");
        logger.info("override userStoreServingName to: " + userStoreServingName);

        if (appidConfig.hasPath("enable.rawdata")) {
            flag = appidConfig.getBoolean("enable.rawdata");
            needUserRawData = flag;
            logger.info("override needUserRawData to: " + needUserRawData);
        }
        if (appidConfig.hasPath("enable.usersegments")) {
            flag = appidConfig.getBoolean("enable.usersegments");
            needUserSegments = flag;
            logger.info("override needUserSegments to: " + needUserSegments);
        }
        if (appidConfig.hasPath("enable.recentclicks")) {
            flag = appidConfig.getBoolean("enable.recentclicks");
            needUserRecentClick = flag;
            logger.info("override needUserRecentClick to: " + needUserRecentClick);
        }
        if (appidConfig.hasPath("enable.fromnewstore")) {
            flag = appidConfig.getBoolean("enable.fromnewstore");
            isDataFromNewStore = flag;
            logger.info("override isDataFromNewStore to: " + isDataFromNewStore);
        }
        if (appidConfig.hasPath("metric.prefix")) {
            if (!(appidConfig.getString("metric.prefix").isEmpty())) {
                metricPrefix = appidConfig.getString("metric.prefix");
            }
        }
    }

    public Config getSegmentConfig(String segment, String appid) {
        try {
            if (config != null && config.hasPath(segment)) {
                if (appid == null) {
                    return config.getConfig(segment);
                } else {
                    return config.getConfig(segment).getConfig(appid);
                }
            }
        } catch (Exception e) {
            logger.error("Load user store config exception:", e);
        }
        return null;
    }

    public String getMetricPrefix() {
        return metricPrefix;
    }
}
