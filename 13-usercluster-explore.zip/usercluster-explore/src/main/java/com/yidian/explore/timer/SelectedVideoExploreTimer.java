package com.yidian.explore.timer;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Future;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.hipu.util.helper.JacksonUtil;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClientConfig;
import com.ning.http.client.Response;
import com.yidian.explore.cache.CacheVideoFeature;
import com.yidian.explore.core.ExploreExploitVideoPools;
import com.yidian.explore.core.VideoFeature;
import com.yidian.explore.constant.LogManager;
import com.yidian.serving.index.docfeature.client.dao.DocumentDataDAO;
import com.yidian.serving.index.docfeature.client.data.NewsDocument;
import lombok.Getter;
import lombok.extern.log4j.Log4j;
import org.codehaus.jackson.JsonNode;

/**
 * Created by Xin on 18/01/05 17:30
 * 优先试探一些精选视频
 */
@Log4j
@Deprecated
public class SelectedVideoExploreTimer {
    private static final String SERVICE_URL = "http://video2video-recommender.ha.in.yidian.com:8100";
    private volatile static SelectedVideoExploreTimer instance;

    public volatile static Map<String, Long> videoSelectedPoolMonthly = new HashMap<>();

    @Getter
    private volatile Set<String> selectedVideos = new HashSet<>();

    private static final AsyncHttpClient asyncHttpClient = new AsyncHttpClient(
            new AsyncHttpClientConfig.Builder()
                    .setFollowRedirect(true)
                    .setRequestTimeout(5000)
                    .build());

    private SelectedVideoExploreTimer() {
        selectedVideos = loadSelectedVideo();

        Timer timer = new Timer(true);
        timer.schedule(new TimerTask() {  // 每隔24h从接口取一次精选视频
            @Override
            public void run() {
                Set<String> result = loadSelectedVideo();
                if (!result.isEmpty()) {
                    selectedVideos = result;
                }
            }
        }, 1000 * 60 * 3, 1000 * 60 * 60 * 8);

        timer.schedule(new TimerTask() {  // 每隔1h从精选视频池投放500篇视频到explore-pool
            @Override
            public void run() {
                if (!selectedVideos.isEmpty()) {
                    distributeSelectedVideo();
                }
                selectedVideoPoolExpire();
            }
        }, 1000 * 60 * 5, 1000 * 60 * 60);
    }

    public static SelectedVideoExploreTimer getInstance() {
        if (instance == null) {
            synchronized (SelectedVideoExploreTimer.class) {
                if (instance == null) {
                    instance = new SelectedVideoExploreTimer();
                }
            }
        }
        return instance;
    }

    private Set<String> loadSelectedVideo() {
        Date now = new Date(System.currentTimeMillis());
        LogManager.COLLECT.info("Start to load selected videos at " + now.toString());

        Set<String> selections = new HashSet<>();
        String url = String.format("%s/video2video/retrieve?type=popular", SERVICE_URL);

        try {
            Future<Response> responseFuture = asyncHttpClient.prepareGet(url).execute();
            Response response = responseFuture.get();
            String responseStr = response.getResponseBody();
            if (Strings.isNullOrEmpty(responseStr)) {
                LogManager.COLLECT.error("Selected video service returns empty response from url: " + url);
            }

            JsonNode jsonResult = JacksonUtil.getJsonObject(responseStr);
            String status = jsonResult.get("status").asText();
            if (!"success".equalsIgnoreCase(status)) {
                LogManager.COLLECT.error("Selected video service response status error: " + status);
            }

            Iterator<JsonNode> iter = jsonResult.get("result").getElements();
            while (iter.hasNext()) {
                JsonNode node = iter.next();
                String docid = node.asText();
                selections.add(docid);
            }
        } catch (Exception e) {
            log.error("Collect selected video from interface exception at " + new Date(System.currentTimeMillis()).toString() + ":", e);
        }

        LogManager.COLLECT.info("Successfully fetch " + selections.size() + " selected videos at " + new Date(System.currentTimeMillis()).toString());
        return selections;
    }

    private void distributeSelectedVideo() {
        if (selectedVideos == null || selectedVideos.isEmpty()) {
            LogManager.COLLECT.error("Empty selected video set");
            return;
        }
        LogManager.COLLECT.info("Current total selected video number is " + selectedVideos.size() + " at " + new Date(System.currentTimeMillis()).toString());

        int newCount = 0;
        List<String> selectedVideoBatch = new ArrayList<>();
        for (String docid : selectedVideos) {
            if (videoSelectedPoolMonthly.keySet().contains(docid)) {
                LogManager.COLLECT.info("Duplicate video in monthly video selected pool: " + docid);
                continue;
            }

            if (newCount < 500) { // 一次投放500篇去试探
                selectedVideoBatch.add(docid);
                newCount += 1;
            } else {
                break;
            }
        }

        Map<String, NewsDocument> newsDocumentMap = DocumentDataDAO.getInstance().getDocumentsMap(selectedVideoBatch);

        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for (NewsDocument newsDocument : newsDocumentMap.values()) {
            String docid = newsDocument.getDocid();
            String date = simpleFormat.format(newsDocument.getDate());

            VideoFeature videoFeature = new VideoFeature(docid, newsDocument.getSegTitle(), newsDocument.getSource(), date, "selected");
            videoFeature.setTier(newsDocument.getWemediaTier());
            videoFeature.setDuration((int) newsDocument.getDuration());
            videoFeature.setKeywords(newsDocument.getKeywords());
            videoFeature.setVideoTags(newsDocument.getYDTags());
            videoFeature.setVideoCategory(newsDocument.getVideoCategory());
            videoFeature.setVideoSubcategory(newsDocument.getVideoSubcategory());

            CacheVideoFeature cacheVideoFeature = new CacheVideoFeature(docid, 0, null, videoFeature);
            ExploreExploitVideoPools.videoFeatureCache.put(docid, cacheVideoFeature);

            videoSelectedPoolMonthly.put(docid, newsDocument.getDate().getTime());
            if (!selectedVideos.isEmpty() && selectedVideos.contains(docid)) {
                selectedVideos.remove(docid);
            }
        }

        LogManager.COLLECT.info("Distribute " + selectedVideoBatch.size() + " selected video to explore and remain " + selectedVideos.size() + " selected video in daily selected video pool");
    }

    private void selectedVideoPoolExpire() {
        if (videoSelectedPoolMonthly == null || videoSelectedPoolMonthly.isEmpty()) {
            LogManager.COLLECT.error("Selected video pool is empty and appear expire error");
        }

        synchronized (SelectedVideoExploreTimer.class) {
            Iterator<Map.Entry<String, Long>> iterator = videoSelectedPoolMonthly.entrySet().iterator();
            try {
                int expireCnt = 0;
                Date now = new Date();
                while (iterator.hasNext()) {
                    Map.Entry<String, Long> video = iterator.next();
                    long delt = now.getTime() - video.getValue();
                    long minutes = (int) (delt / (1000 * 60));
                    if (videoSelectedPoolMonthly.containsKey(video.getKey()) && minutes > 1440 * 15) {
                        iterator.remove();
                        expireCnt += 1;
                    }
                }
                LogManager.EXPIRE.info("Expire " + expireCnt + " selected video at " + now.toString());
            } catch (Exception e) {
                log.error("Selected video pool expire exception:", e);
            }
        }
    }

    public Map<String, Object> serialize(){
        Map<String, Object> ret = Maps.newHashMap();
        ret.put("videoSelectedPool", videoSelectedPoolMonthly);
        return ret;
    }

    public void deserialize(JsonNode root) {
        if (root.has("videoSelectedPool")) {
            JsonNode mapNode = root.get("videoSelectedPool");
            Iterator<String> fieldNames = mapNode.getFieldNames();
            while (fieldNames.hasNext()) {
                String docid = fieldNames.next();
                JsonNode valueNode = mapNode.get(docid);
                videoSelectedPoolMonthly.put(docid, valueNode.asLong());
            }
        }
    }

    public static void main(String[] args) {
        Set<String> selections = SelectedVideoExploreTimer.getInstance().loadSelectedVideo();
        System.out.println(selections.size());
        System.out.println("Done.");
    }
}