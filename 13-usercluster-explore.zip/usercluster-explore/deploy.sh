echo "mvn build"
mvn clean package
echo "rysnc jar"
scp -o ProxyCommand='ssh -q swan -W %h:%p' \
./target/usercluster-explore-1.0-SNAPSHOT.jar worker@10.103.34.100:/home/worker/maogeng-test/bin
